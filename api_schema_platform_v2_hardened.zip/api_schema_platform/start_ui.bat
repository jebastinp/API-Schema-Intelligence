@echo off
cd /d "%~dp0"
if exist env.bat call env.bat
python run.py ui %*
