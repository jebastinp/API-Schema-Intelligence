"""
Stdlib HTTP server exposing a JSON API plus the single-page console.
http.server + ThreadingHTTPServer only - no Flask, no external dependency.
"""
import hmac, http.cookies, json, mimetypes, os, posixpath, re, threading, urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import config
from core import db, security
from agents import orchestrator as orc_mod
from agents.auth_agent import AuthAgent

STATIC_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static")
AUDIT = security.Audit(getattr(config, "AUDIT_LOG", "audit.jsonl"))

# refuse to start with an unsafe production configuration
STARTUP_WARNINGS = config.validate(for_server=True)


class Ctx:
    orchestrator = None
    scheduler = None
    db_path = None
    mock = False


def _json(obj):
    return json.dumps(obj, default=str).encode("utf-8")


class Handler(BaseHTTPRequestHandler):
    server_version = "SchemaAgent/1.0"
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):
        pass  # console stays clean; scans log to the database

    # ------------------------------------------------------------------ util
    def _send(self, code, body=b"", ctype="application/json; charset=utf-8", extra=None):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Content-Security-Policy",
                         "default-src 'self'; style-src 'self' 'unsafe-inline'; "
                         "img-src 'self' data:; object-src 'none'; frame-ancestors 'none'")
        for k, v in (extra.items() if isinstance(extra, dict) else (extra or [])):
            self.send_header(k, v)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def ok(self, obj):
        self._send(200, _json(obj))

    def err(self, code, msg):
        self._send(code, _json({"error": msg}))

    def body_json(self):
        n = int(self.headers.get("Content-Length") or 0)
        if not n:
            return {}
        try:
            return json.loads(self.rfile.read(n).decode("utf-8"))
        except Exception:
            return {}

    @property
    def conn(self):
        return db.connect(Ctx.db_path)

    # ------------------------------------------------------------------ auth
    user = None

    def _cookies(self):
        try:
            ck = http.cookies.SimpleCookie(self.headers.get("Cookie") or "")
            return {k: v.value for k, v in ck.items()}
        except Exception:
            return {}

    def _client_ip(self):
        fwd = self.headers.get("X-Forwarded-For")
        if fwd:
            return fwd.split(",")[0].strip()
        return self.client_address[0] if self.client_address else "?"

    def _session(self):
        return security.get_session(self._cookies().get("ss_sid"))

    def _cookie_flags(self, readable=False):
        f = "; Path=/; SameSite=Strict"
        if not readable:
            f += "; HttpOnly"
        if getattr(config, "COOKIE_SECURE", False):
            f += "; Secure"
        return f

    def _do_login(self):
        ip = self._client_ip()
        wait = security.throttled(ip)
        if wait:
            return self.err(429, "too many failed attempts - retry in %ss" % wait)
        body = self.body_json()
        user = (body.get("user") or "").strip()
        pw = body.get("password") or ""
        role = None
        if user and user == config.ADMIN_USER:
            if config.ADMIN_PASSWORD_HASH:
                if security.verify_password(pw, config.ADMIN_PASSWORD_HASH):
                    role = "admin"
            elif config.ADMIN_PASSWORD:
                if hmac.compare_digest(pw, config.ADMIN_PASSWORD):
                    role = "admin"
        if not role and config.VIEWER_USER and user == config.VIEWER_USER \
                and config.VIEWER_PASSWORD_HASH:
            if security.verify_password(pw, config.VIEWER_PASSWORD_HASH):
                role = "viewer"
        if not role:
            security.record_fail(ip)
            AUDIT.write(user or "?", "login.failed", outcome="error", detail=ip)
            return self.err(401, "invalid credentials")
        security.clear_fails(ip)
        sid, csrf = security.new_session(user, role, ip)
        AUDIT.write(user, "login.success", detail=ip)
        return self._send(200, _json({"ok": True, "user": user, "role": role, "csrf": csrf}),
                          extra=[("Set-Cookie", "ss_sid=%s%s" % (sid, self._cookie_flags())),
                                 ("Set-Cookie", "ss_csrf=%s%s" % (csrf, self._cookie_flags(True)))])

    def _do_logout(self):
        sid = self._cookies().get("ss_sid")
        s = security.get_session(sid)
        security.drop_session(sid)
        if s:
            AUDIT.write(s["user"], "logout")
        return self._send(200, _json({"ok": True}),
                          extra=[("Set-Cookie", "ss_sid=%s; Max-Age=0" % self._cookie_flags()),
                                 ("Set-Cookie", "ss_csrf=%s; Max-Age=0" % self._cookie_flags(True))])

    def _gate(self):
        """Returns True when the request has already been answered."""
        p = urllib.parse.urlparse(self.path).path
        if p == "/healthz":
            self.ok({"status": "ok", "env": config.ENVIRONMENT, "mock": Ctx.mock,
                     "warnings": STARTUP_WARNINGS})
            return True
        if p == "/login" and self.command in ("GET", "HEAD"):
            self._static("login.html")
            return True
        if p == "/api/login" and self.command == "POST":
            self._do_login()
            return True
        if p == "/api/logout" and self.command == "POST":
            self._do_logout()
            return True
        if p.startswith("/static/"):
            return None
        if getattr(config, "AUTH_DISABLED", False) and not config.is_prod():
            return None
        sess = self._session()
        if not sess:
            if p.startswith("/api/"):
                self.err(401, "authentication required")
            else:
                self._send(302, b"", "text/plain", {"Location": "/login"})
            return True
        if self.command in ("POST", "PUT", "PATCH", "DELETE"):
            if not security.check_csrf(self._cookies().get("ss_sid"),
                                       self.headers.get("X-CSRF-Token")):
                self.err(403, "CSRF token missing or invalid")
                return True
            if sess.get("role") != "admin":
                AUDIT.write(sess["user"], "denied", target=p, outcome="error", detail="read-only")
                self.err(403, "this account is read-only")
                return True
            AUDIT.write(sess["user"], "mutate", target="%s %s" % (self.command, p))
        self.user = sess
        return None

    # ------------------------------------------------------------------ GET
    def do_GET(self):
        _g = self._gate()
        if _g is not None:
            return _g
        u = urllib.parse.urlparse(self.path)
        p, qs = u.path, urllib.parse.parse_qs(u.query)
        try:
            if p in ("/", "/index.html"):
                return self._static("index.html")
            if p.startswith("/static/"):
                return self._static(p[len("/static/"):])
            if p.startswith("/api/"):
                return self._api_get(p, qs)
            return self.err(404, "not found")
        except BrokenPipeError:
            pass
        except Exception as e:
            return self.err(500, str(e))

    def _static(self, rel):
        rel = posixpath.normpath(rel).lstrip("/")
        if ".." in rel:
            return self.err(400, "bad path")
        fp = os.path.join(STATIC_DIR, rel)
        if not os.path.isfile(fp):
            return self.err(404, "not found")
        ctype = mimetypes.guess_type(fp)[0] or "application/octet-stream"
        with open(fp, "rb") as f:
            data = f.read()
        if ctype.startswith("text") or "javascript" in ctype or "json" in ctype:
            ctype += "; charset=utf-8"
        self._send(200, data, ctype)

    # ------------------------------------------------------------------ API GET
    def _api_get(self, p, qs):
        c = self.conn
        one = lambda k, d=None: qs.get(k, [d])[0]

        if p == "/api/bootstrap":
            counts = {
                "apis": db.q1(c, "SELECT COUNT(*) n FROM apis")["n"],
                "enabled": db.q1(c, "SELECT COUNT(*) n FROM apis WHERE enabled=1")["n"],
                "scans": db.q1(c, "SELECT COUNT(*) n FROM scans")["n"],
                "columns": db.q1(c, "SELECT COUNT(*) n FROM scan_columns")["n"],
            }
            return self.ok({"config": config.redacted(), "settings": db.get_settings(c),
                            "counts": counts, "mock": Ctx.mock,
                            "next_run": getattr(Ctx.scheduler, "next_run", None),
                            "environments": ["dev", "qa", "prod"]})

        if p == "/api/dashboard":
            latest = db.q(c, "SELECT a.id api_id, a.name, a.environment, a.enabled, a.table_name, "
                             "s.id scan_id, s.status, s.finished_at, s.records, s.pages, "
                             "s.columns_total, s.added_count, s.removed_count, s.changed_count, "
                             "s.duration_sec FROM apis a LEFT JOIN scans s ON s.id = "
                             "(SELECT id FROM scans WHERE api_id=a.id ORDER BY id DESC LIMIT 1) "
                             "ORDER BY a.environment, a.name")
            trend = db.q(c, "SELECT substr(started_at,1,10) d, COUNT(*) scans, "
                            "SUM(added_count) added, SUM(removed_count) removed FROM scans "
                            "WHERE status='success' GROUP BY d ORDER BY d DESC LIMIT 14")
            events = db.q(c, "SELECT e.*, a.name api_name, a.environment FROM schema_events e "
                             "JOIN apis a ON a.id=e.api_id WHERE e.event_type<>'BASELINE' "
                             "ORDER BY e.id DESC LIMIT 40")
            return self.ok({"latest": latest, "trend": list(reversed(trend)), "events": events,
                            "active": orc_mod.active_snapshot()})

        if p == "/api/apis":
            return self.ok(db.q(c, "SELECT * FROM apis ORDER BY environment, name"))

        m = re.match(r"^/api/apis/(\d+)$", p)
        if m:
            a = db.q1(c, "SELECT * FROM apis WHERE id=?", (int(m.group(1)),))
            return self.ok(a) if a else self.err(404, "no such api")

        if p == "/api/scans":
            where, args = [], []
            if one("api_id"):
                where.append("s.api_id=?")
                args.append(int(one("api_id")))
            if one("environment"):
                where.append("s.environment=?")
                args.append(one("environment"))
            w = (" WHERE " + " AND ".join(where)) if where else ""
            return self.ok(db.q(c, "SELECT s.*, a.name api_name FROM scans s "
                                   "JOIN apis a ON a.id=s.api_id" + w +
                                " ORDER BY s.id DESC LIMIT " + str(int(one("limit", "200"))),
                                tuple(args)))

        m = re.match(r"^/api/scans/(\d+)$", p)
        if m:
            sid = int(m.group(1))
            s = db.q1(c, "SELECT s.*, a.name api_name, a.table_name, a.table_schema, a.array_nodes "
                         "FROM scans s JOIN apis a ON a.id=s.api_id WHERE s.id=?", (sid,))
            if not s:
                return self.err(404, "no such scan")
            s["artifacts"] = db.q(c, "SELECT id,kind,filename,bytes,created_at FROM artifacts "
                                     "WHERE scan_id=? ORDER BY id", (sid,))
            s["event_counts"] = db.q(c, "SELECT event_type, COUNT(*) n FROM schema_events "
                                        "WHERE scan_id=? GROUP BY event_type", (sid,))
            return self.ok(s)

        m = re.match(r"^/api/scans/(\d+)/columns$", p)
        if m:
            sid = int(m.group(1))
            term = (one("q") or "").strip()
            sql = "SELECT * FROM scan_columns WHERE scan_id=?"
            args = [sid]
            if term:
                sql += " AND (column_name LIKE ? OR json_path LIKE ?)"
                args += ["%" + term + "%", "%" + term + "%"]
            only = one("only")
            if only == "null":
                sql += " AND non_null_count=0"
            elif only == "late":
                sql += " AND first_seen_record>10000"
            elif only == "dynamic":
                sql += " AND is_dynamic=1"
            return self.ok(db.q(c, sql + " ORDER BY column_name", tuple(args)))

        m = re.match(r"^/api/scans/(\d+)/events$", p)
        if m:
            return self.ok(db.q(c, "SELECT * FROM schema_events WHERE scan_id=? "
                                   "ORDER BY event_type, column_name", (int(m.group(1)),)))

        m = re.match(r"^/api/scans/(\d+)/logs$", p)
        if m:
            return self.ok(db.q(c, "SELECT * FROM logs WHERE scan_id=? ORDER BY id DESC LIMIT 500",
                                (int(m.group(1)),)))

        m = re.match(r"^/api/scans/(\d+)/pages$", p)
        if m:
            return self.ok(db.q(c, "SELECT * FROM raw_pages WHERE scan_id=? ORDER BY page_no",
                                (int(m.group(1)),)))

        m = re.match(r"^/api/artifacts/(\d+)$", p)
        if m:
            a = db.q1(c, "SELECT * FROM artifacts WHERE id=?", (int(m.group(1)),))
            if not a:
                return self.err(404, "no such artifact")
            if one("download"):
                return self._send(200, a["content"].encode("utf-8"), "text/plain; charset=utf-8",
                                  {"Content-Disposition": 'attachment; filename="%s"' % a["filename"]})
            return self.ok(a)

        if p == "/api/settings":
            return self.ok(db.get_settings(c))

        if p == "/api/progress":
            return self.ok({"active": orc_mod.active_snapshot(),
                            "next_run": getattr(Ctx.scheduler, "next_run", None)})

        if p == "/api/drift":
            return self.ok(db.q(c, "SELECT e.*, a.name api_name, a.environment FROM schema_events e "
                                   "JOIN apis a ON a.id=e.api_id WHERE e.event_type<>'BASELINE' "
                                   "ORDER BY e.id DESC LIMIT ?", (int(one("limit", "300")),)))

        if p == "/api/catalogue":
            aid = one("api_id")
            if not aid:
                return self.err(400, "api_id required")
            s = db.q1(c, "SELECT id FROM scans WHERE api_id=? AND status='success' "
                         "ORDER BY id DESC LIMIT 1", (int(aid),))
            if not s:
                return self.ok([])
            return self.ok(db.q(c, "SELECT * FROM scan_columns WHERE scan_id=? ORDER BY column_name",
                                (s["id"],)))

        if p == "/api/logs":
            return self.ok(db.q(c, "SELECT * FROM logs ORDER BY id DESC LIMIT ?",
                                (int(one("limit", "300")),)))

        return self.err(404, "unknown endpoint")

    # ------------------------------------------------------------------ POST
    def do_POST(self):
        _g = self._gate()
        if _g is not None:
            return _g
        p = urllib.parse.urlparse(self.path).path
        c = self.conn
        try:
            body = self.body_json()

            if p == "/api/apis":
                if not (body.get("name") or "").strip():
                    return self.err(400, "name is required")
                body.setdefault("environment", "dev")
                if not body.get("table_name"):
                    body["table_name"] = "stg_" + re.sub(r"[^0-9a-z]+", "_", body["name"].lower())
                try:
                    aid = db.upsert_api(c, body)
                except Exception as e:
                    return self.err(409, "could not save (name must be unique per environment): %s" % e)
                return self.ok(db.q1(c, "SELECT * FROM apis WHERE id=?", (aid,)))

            m = re.match(r"^/api/apis/(\d+)/delete$", p)
            if m:
                aid = int(m.group(1))
                db.ex(c, "DELETE FROM scan_columns WHERE scan_id IN "
                         "(SELECT id FROM scans WHERE api_id=?)", (aid,))
                db.ex(c, "DELETE FROM raw_pages WHERE scan_id IN "
                         "(SELECT id FROM scans WHERE api_id=?)", (aid,))
                db.ex(c, "DELETE FROM artifacts WHERE api_id=?", (aid,))
                db.ex(c, "DELETE FROM schema_events WHERE api_id=?", (aid,))
                db.ex(c, "DELETE FROM logs WHERE api_id=?", (aid,))
                db.ex(c, "DELETE FROM scans WHERE api_id=?", (aid,))
                db.ex(c, "DELETE FROM apis WHERE id=?", (aid,))
                return self.ok({"deleted": aid})

            m = re.match(r"^/api/apis/(\d+)/clone$", p)
            if m:
                a = db.q1(c, "SELECT * FROM apis WHERE id=?", (int(m.group(1)),))
                if not a:
                    return self.err(404, "no such api")
                a.pop("id", None)
                a["environment"] = body.get("environment") or a["environment"]
                try:
                    aid = db.upsert_api(c, a)
                except Exception:
                    return self.err(409, "that name already exists in the target environment")
                return self.ok(db.q1(c, "SELECT * FROM apis WHERE id=?", (aid,)))

            m = re.match(r"^/api/apis/(\d+)/scan$", p)
            if m:
                aid = int(m.group(1))
                mp, mr = body.get("max_pages"), body.get("max_records")
                threading.Thread(target=Ctx.orchestrator.run_scan,
                                 kwargs={"api_id": aid, "trigger": body.get("trigger", "manual"),
                                         "max_pages": int(mp) if mp else None,
                                         "max_records": int(mr) if mr else None},
                                 daemon=True).start()
                return self.ok({"queued": True, "api_id": aid})

            if p == "/api/scan_all":
                mp = body.get("max_pages")
                threading.Thread(target=Ctx.orchestrator.run_all,
                                 kwargs={"environment": body.get("environment") or None,
                                         "trigger": "manual-all",
                                         "max_pages": int(mp) if mp else None},
                                 daemon=True).start()
                return self.ok({"queued": True, "environment": body.get("environment")})

            m = re.match(r"^/api/scans/(\d+)/cancel$", p)
            if m:
                return self.ok({"cancelled": orc_mod.cancel(int(m.group(1)))})

            if p == "/api/settings":
                for k, v in body.items():
                    db.set_setting(c, k, v)
                return self.ok(db.get_settings(c))

            if p == "/api/probe":
                return self.ok(AuthAgent(config).probe())

            if p == "/api/seed":
                prefix = body.get("prefix", "API")
                envs = body.get("environments") or ["dev"]
                created = 0
                for i in range(1, 14):
                    nm = "%s_%02d" % (prefix, i)
                    for env in envs:
                        try:
                            db.upsert_api(c, {
                                "name": nm, "environment": env,
                                "base_url": config.API_BASE_URL,
                                "endpoint": config.EMPLOYEE_ENDPOINT,
                                "records_key": "updateSequence", "root_element": "root",
                                "table_name": "stg_" + nm.lower(),
                                "notes": "seeded placeholder - fill in the real endpoint",
                            })
                            created += 1
                        except Exception:
                            pass
                return self.ok({"created": created})

            return self.err(404, "unknown endpoint")
        except Exception as e:
            return self.err(500, str(e))


def serve(orchestrator, scheduler, db_path, mock=False, host=None, port=None):
    Ctx.orchestrator = orchestrator
    Ctx.scheduler = scheduler
    Ctx.db_path = db_path
    Ctx.mock = mock
    srv = ThreadingHTTPServer((host or config.UI_HOST, port or config.UI_PORT), Handler)
    srv.daemon_threads = True
    return srv
