/* --- CSRF + session shim (hardening pass) ---------------------------------
   Attaches the double-submit token to every mutating fetch and bounces the
   operator to /login once the session has expired. */
(function () {
  function csrf() {
    var m = document.cookie.match(/(?:^|; )ss_csrf=([^;]*)/);
    return m ? decodeURIComponent(m[1]) : "";
  }
  var orig = window.fetch.bind(window);
  window.fetch = function (input, init) {
    init = init || {};
    var method = (init.method || "GET").toUpperCase();
    if (method !== "GET" && method !== "HEAD") {
      var h = new Headers(init.headers || {});
      h.set("X-CSRF-Token", csrf());
      init.headers = h;
    }
    init.credentials = init.credentials || "same-origin";
    return orig(input, init).then(function (r) {
      if (r.status === 401) { window.location.href = "/login"; }
      return r;
    });
  };
})();

/* ==========================================================================
   API Schema Intelligence Console - vanilla ES6, zero dependencies
   ========================================================================== */
const $  = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
const esc = s => String(s == null ? "" : s).replace(/[&<>"']/g, c => (
  { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const num = n => (n == null ? "-" : Number(n).toLocaleString());
const ago = t => {
  if (!t) return "never";
  const d = (Date.now() - new Date(t).getTime()) / 1000;
  if (d < 60) return "just now";
  if (d < 3600) return Math.floor(d / 60) + "m ago";
  if (d < 86400) return Math.floor(d / 3600) + "h ago";
  return Math.floor(d / 86400) + "d ago";
};
const dur = s => (s == null ? "-" : s < 60 ? s.toFixed(1) + "s"
  : Math.floor(s / 60) + "m " + Math.round(s % 60) + "s");

const State = { boot: null, route: "dashboard", param: null, cache: {} };

/* ------------------------------------------------------------------ http */
async function api(path, opts) {
  const r = await fetch(path, Object.assign({ headers: { "Content-Type": "application/json" } }, opts));
  const txt = await r.text();
  let data;
  try { data = txt ? JSON.parse(txt) : null; } catch (e) { data = { error: txt }; }
  if (!r.ok) throw new Error((data && data.error) || ("HTTP " + r.status));
  return data;
}
const GET  = p => api(p);
const POST = (p, b) => api(p, { method: "POST", body: JSON.stringify(b || {}) });

/* ------------------------------------------------------------------ toast */
function toast(title, detail, kind) {
  const el = document.createElement("div");
  el.className = "toast " + (kind || "");
  el.innerHTML = '<div class="tt">' + esc(title) + "</div>" +
                 (detail ? '<div class="td">' + esc(detail) + "</div>" : "");
  $("#toasts").appendChild(el);
  setTimeout(() => {
    el.style.opacity = 0; el.style.transform = "translateX(24px)"; el.style.transition = ".25s";
    setTimeout(() => el.remove(), 260);
  }, kind === "bad" ? 7000 : 3800);
}

/* ------------------------------------------------------------------ modal */
function modal(title, bodyHtml, footHtml) {
  $("#modal").innerHTML =
    '<div class="modal-h"><h3>' + esc(title) + '</h3><button class="x" data-close>&times;</button></div>' +
    '<div class="modal-b">' + bodyHtml + "</div>" +
    (footHtml ? '<div class="modal-f">' + footHtml + "</div>" : "");
  $("#modalBackdrop").hidden = false;
  $$("[data-close]").forEach(b => b.onclick = closeModal);
}
function closeModal() { $("#modalBackdrop").hidden = true; $("#modal").innerHTML = ""; }
$("#modalBackdrop").addEventListener("click", e => { if (e.target.id === "modalBackdrop") closeModal(); });
document.addEventListener("keydown", e => { if (e.key === "Escape") closeModal(); });

/* ------------------------------------------------------------------ bits */
function card(title, sub, body, actions) {
  return '<div class="card"><div class="card-h"><div><h3>' + esc(title) + "</h3>" +
    (sub ? '<div class="sub">' + esc(sub) + "</div>" : "") + "</div>" +
    (actions ? "<div>" + actions + "</div>" : "") + "</div>" + body + "</div>";
}
function kpi(lbl, val, foot, tone) {
  return '<div class="card kpi ' + (tone || "") + '"><div class="lbl">' + esc(lbl) +
    '</div><div class="val">' + val + '</div><div class="foot">' + esc(foot || "") + "</div></div>";
}
function empty(strong, msg) {
  return '<div class="empty"><strong>' + esc(strong) + "</strong>" + esc(msg || "") + "</div>";
}
function statusBadge(s) {
  const m = { success: "ok", failed: "bad", running: "acc", cancelled: "warn" };
  return '<span class="b ' + (m[s] || "mut") + '">' + esc(s || "-") + "</span>";
}
function envBadge(e) {
  const m = { dev: "ok", qa: "warn", prod: "bad" };
  return '<span class="b ' + (m[e] || "mut") + '">' + esc(e) + "</span>";
}
function eventBadge(t) {
  const m = { NEW_COLUMN: "ok", REMOVED_COLUMN: "bad", TYPE_CHANGED: "warn", WIDENED: "info",
              NOW_ALWAYS_NULL: "warn", NOW_POPULATED: "acc", BASELINE: "mut" };
  return '<span class="b ' + (m[t] || "mut") + '">' + esc(String(t).replace(/_/g, " ").toLowerCase()) + "</span>";
}
function sparkline(vals, w, h, color) {
  w = w || 240; h = h || 40;
  if (!vals.length) return "";
  const max = Math.max.apply(null, vals.concat([1]));
  const step = vals.length > 1 ? w / (vals.length - 1) : w;
  const pts = vals.map((v, i) => [i * step, h - (v / max) * (h - 4) - 2]);
  const line = pts.map(p => p[0].toFixed(1) + "," + p[1].toFixed(1)).join(" ");
  const area = line + " " + w + "," + h + " 0," + h;
  return '<svg class="spark" width="' + w + '" height="' + h + '" viewBox="0 0 ' + w + " " + h + '">' +
    '<polygon points="' + area + '" fill="' + (color || "#3b82f6") + '" opacity=".13"/>' +
    '<polyline points="' + line + '" fill="none" stroke="' + (color || "#3b82f6") +
    '" stroke-width="1.8" stroke-linejoin="round" stroke-linecap="round"/></svg>';
}
function table(cols, rows, rowFn, opts) {
  opts = opts || {};
  if (!rows.length) return empty(opts.emptyTitle || "Nothing to show", opts.emptyMsg || "");
  return '<div class="tbl-wrap"><table><thead><tr>' +
    cols.map(c => "<th" + (c.cls ? ' class="' + c.cls + '"' : "") + ">" + esc(c.t) + "</th>").join("") +
    "</tr></thead><tbody>" + rows.map(rowFn).join("") + "</tbody></table></div>";
}
function driftCell(r) {
  const parts = [];
  if (r.added_count) parts.push('<span class="b ok">+' + r.added_count + "</span>");
  if (r.removed_count) parts.push('<span class="b bad">-' + r.removed_count + "</span>");
  if (r.changed_count) parts.push('<span class="b warn">~' + r.changed_count + "</span>");
  return parts.length ? parts.join(" ") : '<span class="b mut">stable</span>';
}

/* ==========================================================================
   VIEWS
   ========================================================================== */
const Views = {};

/* ---------------------------------------------------------- dashboard */
Views.dashboard = async () => {
  const d = await GET("/api/dashboard");
  State.cache.dashboard = d;
  const rows = d.latest;
  const scanned = rows.filter(r => r.scan_id);
  const totCols = scanned.reduce((a, r) => a + (r.columns_total || 0), 0);
  const totRecs = scanned.reduce((a, r) => a + (r.records || 0), 0);
  const added = scanned.reduce((a, r) => a + (r.added_count || 0), 0);
  const removed = scanned.reduce((a, r) => a + (r.removed_count || 0), 0);
  const failed = scanned.filter(r => r.status === "failed").length;
  const never = rows.length - scanned.length;

  let html = "";
  if (!rows.length) {
    html += '<div class="banner info"><div><strong>No APIs registered yet.</strong><br>' +
      "Open the API Registry and add your endpoints, or seed 13 placeholders to fill in later." +
      '<br><br><button class="btn primary" data-act="seed">Seed 13 API placeholders</button></div></div>';
  }
  if (State.boot.mock) {
    html += '<div class="banner warn"><div><strong>Demo mode is active.</strong> ' +
      "Crawls are served by the offline mock provider, so no network, proxy or credentials are used. " +
      "Restart without the --demo flag to hit the real APIs.</div></div>";
  }

  html += '<div class="grid kpis">' +
    kpi("Registered APIs", num(rows.length), State.boot.counts.enabled + " enabled for scheduling", "accent") +
    kpi("Columns tracked", num(totCols), "across latest successful scans") +
    kpi("Records profiled", num(totRecs), "in the most recent scan per API") +
    kpi("New columns", num(added), "detected in latest scans", added ? "ok" : "") +
    kpi("Removed columns", num(removed), "needs human review", removed ? "bad" : "") +
    kpi("Failed / never run", failed + " / " + never, "scan health", failed ? "bad" : "") +
    "</div>";

  const trend = d.trend || [];
  html += '<div class="grid cols2" style="margin-top:16px">';
  html += card("Fleet status", "latest scan per API and environment",
    '<div class="card-b flush">' + table(
      [{ t: "API" }, { t: "Env" }, { t: "Status" }, { t: "Last run" }, { t: "Records", cls: "num" },
       { t: "Columns", cls: "num" }, { t: "Drift" }, { t: "Duration", cls: "num" }, { t: "" }],
      rows, r => "<tr>" +
        "<td><b>" + esc(r.name) + '</b><div class="path">' + esc(r.table_name || "") + "</div></td>" +
        "<td>" + envBadge(r.environment) + "</td>" +
        "<td>" + (r.scan_id ? statusBadge(r.status) : '<span class="b mut">never run</span>') + "</td>" +
        '<td class="mono">' + esc(ago(r.finished_at)) + "</td>" +
        '<td class="num">' + num(r.records) + "</td>" +
        '<td class="num">' + num(r.columns_total) + "</td>" +
        "<td>" + (r.scan_id ? driftCell(r) : "-") + "</td>" +
        '<td class="num">' + dur(r.duration_sec) + "</td>" +
        '<td style="text-align:right;white-space:nowrap">' +
          '<button class="btn sm" data-act="scan" data-id="' + r.api_id + '">Scan</button> ' +
          (r.scan_id ? '<button class="btn sm ghost" data-act="open-scan" data-id="' + r.scan_id + '">View</button>' : "") +
        "</td></tr>",
      { emptyTitle: "No APIs registered", emptyMsg: "Add one in the API Registry." }) + "</div>");

  html += "<div>" + card("Drift volume", "last 14 scan days",
    '<div class="card-b">' + (trend.length
      ? sparkline(trend.map(t => t.added || 0), 300, 56, "#22c55e") +
        sparkline(trend.map(t => t.removed || 0), 300, 56, "#ef4444") +
        '<div style="display:flex;gap:14px;margin-top:8px;font-size:11.5px;color:var(--mut)">' +
        '<span class="b ok">added</span><span class="b bad">removed</span></div>'
      : empty("No history yet", "Run a scan to start the trend.")) + "</div>") + "</div></div>";

  html += '<div class="section-title">Recent drift events</div>';
  html += card("Change feed", "newest 40 structural changes",
    '<div class="card-b flush">' + table(
      [{ t: "When" }, { t: "API" }, { t: "Env" }, { t: "Event" }, { t: "Column" }, { t: "Detail" }],
      d.events, e => "<tr>" +
        '<td class="mono">' + esc(ago(e.detected_at)) + "</td>" +
        "<td>" + esc(e.api_name) + "</td><td>" + envBadge(e.environment) + "</td>" +
        "<td>" + eventBadge(e.event_type) + "</td>" +
        '<td class="mono">' + esc(e.column_name) + "</td>" +
        '<td class="path">' + esc(e.details) + "</td></tr>",
      { emptyTitle: "No drift recorded", emptyMsg: "Baseline events are excluded from this feed." }) + "</div>");
  return html;
};

/* ---------------------------------------------------------- api registry */
const API_DEFAULTS = {
  environment: "dev", http_method: "GET", records_key: "updateSequence", root_element: "root",
  cursor_response_key: "nextCursor", cursor_query_param: "cursor", cursor_pre_encoded: 1,
  page_size_param: "pageSize", page_size: 1000, table_schema: "dbo", enabled: 1,
  force_depth: "{}", extra_query: "", array_nodes: "", notes: "", base_url: "", endpoint: "",
  name: "", table_name: ""
};

Views.apis = async () => {
  const list = await GET("/api/apis");
  State.cache.apis = list;
  let html = '<div class="toolbar">' +
    '<div class="search"><input id="apiSearch" placeholder="Filter by name, table or endpoint"></div>' +
    '<select id="apiEnv" style="width:150px"><option value="">All environments</option>' +
      ["dev", "qa", "prod"].map(e => '<option value="' + e + '">' + e + "</option>").join("") + "</select>" +
    '<div class="grow"></div>' +
    '<button class="btn" data-act="seed">Seed 13 placeholders</button>' +
    '<button class="btn primary" data-act="new-api">Add API</button></div>';
  html += card("Registered APIs", list.length + " configured across environments",
    '<div class="card-b flush" id="apiTable">' + apiTable(list) + "</div>");
  setTimeout(() => {
    const refilter = () => {
      const q = $("#apiSearch").value.trim().toLowerCase();
      const env = $("#apiEnv").value;
      const f = list.filter(a =>
        (!env || a.environment === env) &&
        (!q || (a.name + " " + a.table_name + " " + a.endpoint + " " + a.notes).toLowerCase().includes(q)));
      $("#apiTable").innerHTML = apiTable(f);
    };
    $("#apiSearch").oninput = refilter;
    $("#apiEnv").onchange = refilter;
  }, 0);
  return html;
};

function apiTable(list) {
  return table(
    [{ t: "Name" }, { t: "Env" }, { t: "Endpoint" }, { t: "Staging table" }, { t: "Records key" },
     { t: "Page size", cls: "num" }, { t: "State" }, { t: "" }],
    list, a => "<tr>" +
      "<td><b>" + esc(a.name) + "</b>" + (a.notes ? '<div class="path">' + esc(a.notes) + "</div>" : "") + "</td>" +
      "<td>" + envBadge(a.environment) + "</td>" +
      '<td class="path">' + esc(((a.base_url || "") + "/" + (a.endpoint || "")).replace(/([^:])\/\/+/g, "$1/")) + "</td>" +
      '<td class="mono">' + esc((a.table_schema || "dbo") + "." + (a.table_name || "")) + "</td>" +
      '<td class="mono">' + esc(a.records_key) + "</td>" +
      '<td class="num">' + num(a.page_size) + "</td>" +
      "<td>" + (a.enabled ? '<span class="b ok">enabled</span>' : '<span class="b mut">disabled</span>') + "</td>" +
      '<td style="text-align:right;white-space:nowrap">' +
        '<button class="btn sm primary" data-act="scan" data-id="' + a.id + '">Scan</button> ' +
        '<button class="btn sm" data-act="edit-api" data-id="' + a.id + '">Edit</button> ' +
        '<button class="btn sm ghost" data-act="clone-api" data-id="' + a.id + '">Clone</button> ' +
        '<button class="btn sm danger" data-act="del-api" data-id="' + a.id + '">Delete</button>' +
      "</td></tr>",
    { emptyTitle: "No APIs yet", emptyMsg: "Add your first endpoint to begin." });
}

function apiForm(a) {
  a = Object.assign({}, API_DEFAULTS, a || {});
  const f = (id, label, hint, val, type) =>
    '<div class="field"><label>' + label + (hint ? ' <span class="hint">' + hint + "</span>" : "") +
    '</label><input id="f_' + id + '" type="' + (type || "text") + '" value="' + esc(val) + '"></div>';
  return '<div class="frow">' +
      f("name", "Name", "unique per environment", a.name) +
      '<div class="field"><label>Environment</label><select id="f_environment">' +
        ["dev", "qa", "prod"].map(e => '<option value="' + e + '"' +
          (a.environment === e ? " selected" : "") + ">" + e + "</option>").join("") +
      "</select></div></div>" +
    f("base_url", "Base URL", "blank falls back to SS_API_BASE_URL", a.base_url) +
    f("endpoint", "Endpoint path", "for example /v1/employees/updates", a.endpoint) +
    '<div class="section-title">Response shape</div>' +
    '<div class="frow">' + f("records_key", "Records array key", "", a.records_key) +
      f("root_element", "XQuery root element", "", a.root_element) + "</div>" +
    '<div class="section-title">Pagination</div>' +
    '<div class="frow3">' + f("cursor_response_key", "Cursor field in response", "", a.cursor_response_key) +
      f("cursor_query_param", "Cursor query parameter", "", a.cursor_query_param) +
      f("page_size", "Page size", "", a.page_size, "number") + "</div>" +
    '<div class="frow">' + f("page_size_param", "Page size parameter", "", a.page_size_param) +
      f("extra_query", "Extra query string", "for example sinceSequence=0", a.extra_query) + "</div>" +
    '<label class="check"><input type="checkbox" id="f_cursor_pre_encoded"' +
      (Number(a.cursor_pre_encoded) ? " checked" : "") +
      "> Cursor is already percent-encoded by the server, do not re-encode it</label>" +
    '<div class="section-title">Target table and naming</div>' +
    '<div class="frow">' + f("table_schema", "Schema", "", a.table_schema) +
      f("table_name", "Table name", "blank auto-derives from the API name", a.table_name) + "</div>" +
    '<div class="field"><label>force_depth <span class="hint">JSON. Pins a leaf to N path segments. ' +
      '{"hrStatus": 3} yields jobs_effectiveDatedJobInfo_hrStatus</span></label>' +
      '<textarea id="f_force_depth">' + esc(a.force_depth || "{}") + "</textarea></div>" +
    '<div class="field"><label>Repeating groups <span class="hint">comma separated; auto-detected on the first scan</span></label>' +
      '<input id="f_array_nodes" value="' + esc(a.array_nodes) + '"></div>' +
    '<div class="field"><label>Notes</label><textarea id="f_notes">' + esc(a.notes) + "</textarea></div>" +
    '<label class="check"><input type="checkbox" id="f_enabled"' + (Number(a.enabled) ? " checked" : "") +
      "> Include in the scheduled daily scan</label>" +
    (a.id ? '<input type="hidden" id="f_id" value="' + a.id + '">' : "");
}

function readApiForm() {
  const g = id => { const el = $("#f_" + id); return el ? el.value : undefined; };
  const b = id => ($("#f_" + id) && $("#f_" + id).checked ? 1 : 0);
  const o = {
    name: g("name"), environment: g("environment"), base_url: g("base_url"), endpoint: g("endpoint"),
    records_key: g("records_key"), root_element: g("root_element"),
    cursor_response_key: g("cursor_response_key"), cursor_query_param: g("cursor_query_param"),
    cursor_pre_encoded: b("cursor_pre_encoded"), page_size_param: g("page_size_param"),
    page_size: Number(g("page_size") || 1000), extra_query: g("extra_query"),
    array_nodes: g("array_nodes"), force_depth: g("force_depth") || "{}",
    table_schema: g("table_schema"), table_name: g("table_name"), notes: g("notes"), enabled: b("enabled")
  };
  if ($("#f_id")) o.id = Number($("#f_id").value);
  if (!o.name || !o.name.trim()) throw new Error("Name is required");
  try { JSON.parse(o.force_depth); } catch (e) { throw new Error("force_depth is not valid JSON"); }
  return o;
}

/* ---------------------------------------------------------- scans */
Views.scans = async () => {
  const list = await GET("/api/scans?limit=200");
  let h = '<div class="toolbar"><div class="search">' +
    '<input id="scanSearch" placeholder="Filter by API name or status"></div>' +
    '<div class="grow"></div><button class="btn primary" id="btnScanAll2">Scan all</button></div>' +
    card("Scan history", "most recent 200 runs",
      '<div class="card-b flush" id="scanTable">' + scanTable(list) + "</div>");
  setTimeout(() => {
    $("#scanSearch").oninput = () => {
      const q = $("#scanSearch").value.trim().toLowerCase();
      $("#scanTable").innerHTML = scanTable(list.filter(s =>
        !q || (s.api_name + " " + s.status + " " + s.environment).toLowerCase().includes(q)));
    };
  }, 0);
  return h;
};

function scanTable(list) {
  return table(
    [{ t: "#" }, { t: "API" }, { t: "Env" }, { t: "Status" }, { t: "Trigger" }, { t: "Started" },
     { t: "Duration", cls: "num" }, { t: "Pages", cls: "num" }, { t: "Records", cls: "num" },
     { t: "Columns", cls: "num" }, { t: "Drift" }, { t: "" }],
    list, s => "<tr>" +
      '<td class="mono">' + s.id + "</td><td><b>" + esc(s.api_name) + "</b></td>" +
      "<td>" + envBadge(s.environment) + "</td><td>" + statusBadge(s.status) + "</td>" +
      '<td><span class="b mut">' + esc(s.trigger) + "</span></td>" +
      '<td class="mono">' + esc(String(s.started_at || "").replace("T", " ")) + "</td>" +
      '<td class="num">' + dur(s.duration_sec) + "</td>" +
      '<td class="num">' + num(s.pages) + '</td><td class="num">' + num(s.records) + "</td>" +
      '<td class="num">' + num(s.columns_total) + "</td>" +
      "<td>" + driftCell(s) + "</td>" +
      '<td style="text-align:right"><button class="btn sm" data-act="open-scan" data-id="' +
        s.id + '">Open</button></td></tr>',
    { emptyTitle: "No scans yet", emptyMsg: "Trigger one from the dashboard." });
}

/* ---------------------------------------------------------- scan detail */
Views.scan = async (id) => {
  const s = await GET("/api/scans/" + id);
  const [cols, events, logs, pages] = await Promise.all([
    GET("/api/scans/" + id + "/columns"),
    GET("/api/scans/" + id + "/events"),
    GET("/api/scans/" + id + "/logs"),
    GET("/api/scans/" + id + "/pages")
  ]);
  State.cache.scan = { s, cols, events, logs, pages };
  const late = cols.filter(c => c.first_seen_record > 10000).length;
  const nulls = cols.filter(c => !c.non_null_count).length;
  const dyn = cols.filter(c => c.is_dynamic).length;

  let h = '<div class="toolbar"><button class="btn ghost" data-act="back-scans">&larr; Scan history</button>' +
    '<div class="grow"></div><button class="btn" data-act="scan" data-id="' + s.api_id +
    '">Re-scan ' + esc(s.api_name) + "</button></div>";

  h += '<div class="grid kpis">' +
    kpi("Columns discovered", num(cols.length), s.api_name + " / " + s.environment, "accent") +
    kpi("Records profiled", num(s.records), num(s.pages) + " pages in " + dur(s.duration_sec)) +
    kpi("New", num(s.added_count), "versus previous scan", s.added_count ? "ok" : "") +
    kpi("Removed", num(s.removed_count), "review before dropping", s.removed_count ? "bad" : "") +
    kpi("Late-appearing", num(late), "first seen after record 10,000", late ? "warn" : "") +
    kpi("Always null", num(nulls), dyn + " dynamic custom fields") +
    "</div>";

  h += '<div class="tabs" id="scanTabs" style="margin-top:20px">' +
    '<a class="on" data-tab="cols">Columns (' + cols.length + ")</a>" +
    '<a data-tab="events">Drift events (' + events.length + ")</a>" +
    '<a data-tab="arts">Artifacts (' + ((s.artifacts || []).length) + ")</a>" +
    '<a data-tab="pages">Pages (' + pages.length + ")</a>" +
    '<a data-tab="logs">Logs (' + logs.length + ")</a>" +
    '<a data-tab="meta">Metadata</a></div><div id="scanTab"></div>';
  setTimeout(() => renderScanTab("cols"), 0);
  return h;
};

function colsTable(cols) {
  return table(
    [{ t: "Column" }, { t: "JSON path" }, { t: "Types" }, { t: "Fill rate" },
     { t: "Max len", cls: "num" }, { t: "First seen", cls: "num" }, { t: "" }],
    cols, c => {
      const rate = c.seen_count ? (c.non_null_count / c.seen_count) : 0;
      const colr = rate === 0 ? "#5f6b7a" : rate < .1 ? "#f59e0b" : "#22c55e";
      return "<tr>" +
        '<td class="mono"><b>' + esc(c.column_name) + "</b></td>" +
        '<td class="path">' + esc(c.json_path) + "</td>" +
        "<td>" + String(c.types || "null").split(",").map(t => '<span class="b ' +
          (t === "null" ? "mut" : t === "string" ? "info" : t === "boolean" ? "pur" : "acc") +
          '">' + esc(t) + "</span>").join(" ") + "</td>" +
        '<td><div style="display:flex;align-items:center;gap:8px"><div class="bar"><i style="width:' +
          (rate * 100).toFixed(1) + "%;background:" + colr + '"></i></div>' +
          '<span class="mono" style="font-size:11px;color:var(--mut)">' + (rate * 100).toFixed(0) +
          "%</span></div></td>" +
        '<td class="num">' + (c.max_len || 0) + "</td>" +
        '<td class="num">' + (c.first_seen_record > 10000
          ? '<span class="b warn">#' + num(c.first_seen_record) + "</span>"
          : "#" + num(c.first_seen_record)) + "</td>" +
        "<td>" + (c.is_dynamic ? '<span class="b pur">dynamic</span>' : "") + "</td></tr>";
    }, { emptyTitle: "No columns", emptyMsg: "" });
}

async function renderScanTab(tab) {
  $$("#scanTabs a").forEach(a => a.classList.toggle("on", a.dataset.tab === tab));
  const st = State.cache.scan;
  const s = st.s, cols = st.cols, events = st.events, logs = st.logs, pages = st.pages;
  const box = $("#scanTab");

  if (tab === "cols") {
    box.innerHTML = '<div class="toolbar"><div class="search">' +
      '<input id="colSearch" placeholder="Filter columns or JSON paths"></div>' +
      '<select id="colOnly" style="width:210px"><option value="">All columns</option>' +
      '<option value="late">Late-appearing only</option><option value="null">Always null only</option>' +
      '<option value="dynamic">Dynamic custom fields</option></select><div class="grow"></div>' +
      '<span class="mono" style="color:var(--mut2);font-size:12px" id="colCount">' +
      cols.length + " columns</span></div>" +
      card("Column catalogue", "union of every leaf path seen across " + num(s.records) + " records",
        '<div class="card-b flush" id="colBox">' + colsTable(cols) + "</div>");
    const refilter = async () => {
      const q = $("#colSearch").value.trim(), only = $("#colOnly").value;
      const r = await GET("/api/scans/" + s.id + "/columns?q=" + encodeURIComponent(q) + "&only=" + only);
      $("#colBox").innerHTML = colsTable(r);
      $("#colCount").textContent = r.length + " columns";
    };
    let t;
    $("#colSearch").oninput = () => { clearTimeout(t); t = setTimeout(refilter, 220); };
    $("#colOnly").onchange = refilter;

  } else if (tab === "events") {
    box.innerHTML = card("Drift events", "structural changes recorded for this scan",
      '<div class="card-b flush">' + table(
        [{ t: "Event" }, { t: "Column" }, { t: "JSON path" }, { t: "Detail" }],
        events, e => "<tr><td>" + eventBadge(e.event_type) + '</td><td class="mono">' +
          esc(e.column_name) + '</td><td class="path">' + esc(e.json_path) +
          '</td><td class="path">' + esc(e.details) + "</td></tr>",
        { emptyTitle: "No events", emptyMsg: "The schema was identical to the previous scan." }) + "</div>");

  } else if (tab === "arts") {
    const arts = s.artifacts || [];
    if (!arts.length) { box.innerHTML = empty("No artifacts", ""); return; }
    box.innerHTML = '<div class="tabs" id="artTabs">' + arts.map((a, i) =>
      '<a class="' + (i === 0 ? "on" : "") + '" data-art="' + a.id + '">' + esc(a.filename) + "</a>").join("") +
      '</div><div id="artBox"></div>';
    $$("#artTabs a").forEach(a => a.onclick = () => {
      $$("#artTabs a").forEach(x => x.classList.remove("on"));
      a.classList.add("on");
      showArtifact(a.dataset.art);
    });
    showArtifact(arts[0].id);

  } else if (tab === "pages") {
    const maxMs = Math.max.apply(null, pages.map(p => p.elapsed_ms || 0).concat([1]));
    box.innerHTML = card("Page-by-page crawl metrics", pages.length + " requests",
      '<div class="card-b">' + sparkline(pages.map(p => p.elapsed_ms || 0), 700, 60, "#06b6d4") + "</div>" +
      '<div class="card-b flush">' + table(
        [{ t: "Page", cls: "num" }, { t: "HTTP" }, { t: "Records", cls: "num" },
         { t: "Latency", cls: "num" }, { t: "Relative" }, { t: "Next cursor" }],
        pages, p => '<tr><td class="num">' + p.page_no + "</td><td>" +
          '<span class="b ' + (p.http_status === 200 ? "ok" : "bad") + '">' + p.http_status + "</span></td>" +
          '<td class="num">' + num(p.record_count) + '</td><td class="num">' + num(p.elapsed_ms) + "ms</td>" +
          '<td><div class="bar"><i style="width:' + ((p.elapsed_ms / maxMs) * 100).toFixed(1) +
          '%;background:#06b6d4"></i></div></td>' +
          '<td class="path">' + esc(String(p.next_cursor || "-").slice(0, 40)) + "</td></tr>",
        { emptyTitle: "No page metrics", emptyMsg: "Disabled in Settings." }) + "</div>");

  } else if (tab === "logs") {
    box.innerHTML = card("Execution log", "newest first",
      '<div class="card-b">' + (logs.length ? logs.map(l =>
        '<div class="logline"><span class="t">' + esc(String(l.ts || "").replace("T", " ")) + "</span>" +
        '<span class="l ' + esc(l.level) + '">' + esc(l.level) + '</span><span class="m">' +
        esc(l.message) + "</span></div>").join("") : empty("No log lines", "")) + "</div>");

  } else {
    const meta = {
      "Scan id": s.id, "API": s.api_name, "Environment": s.environment, "Status": s.status,
      "Trigger": s.trigger, "Started": s.started_at, "Finished": s.finished_at,
      "Duration": dur(s.duration_sec), "Pages": num(s.pages), "Records": num(s.records),
      "Columns total": num(s.columns_total),
      "Target table": (s.table_schema || "dbo") + "." + (s.table_name || ""),
      "Repeating groups": s.array_nodes || "-", "Message": s.message || "-"
    };
    box.innerHTML = card("Scan metadata", "",
      '<div class="card-b"><dl class="kv">' + Object.keys(meta).map(k =>
        "<dt>" + esc(k) + "</dt><dd>" + esc(meta[k]) + "</dd>").join("") + "</dl></div>");
  }
}

async function showArtifact(artId) {
  const a = await GET("/api/artifacts/" + artId);
  $("#artBox").innerHTML = card(a.filename, (a.bytes / 1024).toFixed(1) + " KB / " + a.kind,
    '<div class="card-b"><div class="code-h"><span class="fn">' + esc(a.filename) + "</span><span>" +
    '<button class="btn sm" id="btnCopyArt">Copy</button> ' +
    '<a class="btn sm ghost" href="/api/artifacts/' + a.id + '?download=1">Download</a></span></div>' +
    '<div class="code">' + esc(a.content) + "</div></div>");
  const btn = $("#btnCopyArt");
  if (btn) btn.onclick = () => {
    navigator.clipboard.writeText(a.content).then(
      () => toast("Copied", a.filename + " is on your clipboard", "ok"),
      () => toast("Copy blocked by the browser", "Use Download instead", "warn"));
  };
}

/* ---------------------------------------------------------- catalogue */
Views.catalogue = async () => {
  const apis = await GET("/api/apis");
  let h = '<div class="toolbar"><select id="catApi" style="width:300px">' +
    (apis.length ? apis.map(a => '<option value="' + a.id + '">' + esc(a.name) + " / " +
      a.environment + "</option>").join("") : '<option value="">no APIs registered</option>') +
    '</select><div class="search"><input id="catSearch" placeholder="Filter columns"></div>' +
    '<div class="grow"></div><span class="mono" id="catCount" style="color:var(--mut2);font-size:12px"></span>' +
    '</div><div id="catBox"></div>';
  setTimeout(() => {
    const load = async () => {
      const sel = $("#catApi");
      if (!sel || !sel.value) { $("#catBox").innerHTML = empty("No API selected", ""); return; }
      $("#catBox").innerHTML = '<div class="card"><div class="card-b"><span class="spinner"></span> loading</div></div>';
      const cols = await GET("/api/catalogue?api_id=" + sel.value);
      const q = $("#catSearch").value.trim().toLowerCase();
      const f = q ? cols.filter(c => (c.column_name + " " + c.json_path).toLowerCase().includes(q)) : cols;
      $("#catCount").textContent = f.length + " / " + cols.length + " columns";
      $("#catBox").innerHTML = cols.length
        ? card("Current column catalogue", "from the latest successful scan",
            '<div class="card-b flush">' + colsTable(f) + "</div>")
        : empty("No successful scan for this API", "Run a scan first.");
    };
    if ($("#catApi")) $("#catApi").onchange = load;
    let t;
    if ($("#catSearch")) $("#catSearch").oninput = () => { clearTimeout(t); t = setTimeout(load, 220); };
    load();
  }, 0);
  return h;
};

/* ---------------------------------------------------------- drift */
Views.drift = async () => {
  const ev = await GET("/api/drift?limit=400");
  const byType = {};
  ev.forEach(e => byType[e.event_type] = (byType[e.event_type] || 0) + 1);
  let h = '<div class="grid kpis">' +
    kpi("New columns", num(byType.NEW_COLUMN || 0), "recent history", "ok") +
    kpi("Removed columns", num(byType.REMOVED_COLUMN || 0), "recent history", "bad") +
    kpi("Type changes", num(byType.TYPE_CHANGED || 0), "recent history", "warn") +
    kpi("Widened", num(byType.WIDENED || 0), "max length grew") +
    kpi("Now always null", num(byType.NOW_ALWAYS_NULL || 0), "source stopped populating", "warn") +
    kpi("Now populated", num(byType.NOW_POPULATED || 0), "source started populating", "accent") +
    '</div><div style="margin-top:16px"></div>';
  h += card("Drift log", "newest 400 events across all APIs",
    '<div class="card-b flush">' + table(
      [{ t: "When" }, { t: "API" }, { t: "Env" }, { t: "Event" }, { t: "Column" },
       { t: "JSON path" }, { t: "Detail" }, { t: "Scan" }],
      ev, e => "<tr>" +
        '<td class="mono">' + esc(String(e.detected_at || "").replace("T", " ")) + "</td>" +
        "<td>" + esc(e.api_name) + "</td><td>" + envBadge(e.environment) + "</td>" +
        "<td>" + eventBadge(e.event_type) + '</td><td class="mono">' + esc(e.column_name) + "</td>" +
        '<td class="path">' + esc(e.json_path) + '</td><td class="path">' + esc(e.details) + "</td>" +
        '<td><button class="btn sm ghost" data-act="open-scan" data-id="' + e.scan_id + '">#' +
        e.scan_id + "</button></td></tr>",
      { emptyTitle: "No drift yet", emptyMsg: "Baseline events are hidden here." }) + "</div>");
  return h;
};

/* ---------------------------------------------------------- artifacts */
Views.artifacts = async () => {
  const scans = await GET("/api/scans?limit=100");
  const ok = scans.filter(s => s.status === "success");
  let h = '<div class="toolbar"><select id="artScan" style="width:460px">' +
    (ok.length ? ok.map(s => '<option value="' + s.id + '">#' + s.id + " / " + esc(s.api_name) +
      " / " + s.environment + " / " + esc(String(s.started_at || "").replace("T", " ")) +
      " / " + s.columns_total + " cols</option>").join("")
      : '<option value="">no successful scans</option>') +
    '</select></div><div id="artHost"></div>';
  setTimeout(() => {
    const load = async () => {
      const sel = $("#artScan");
      if (!sel || !sel.value) {
        $("#artHost").innerHTML = empty("Nothing generated yet", "Run a scan to produce artifacts.");
        return;
      }
      const s = await GET("/api/scans/" + sel.value);
      const arts = s.artifacts || [];
      $("#artHost").innerHTML = '<div class="tabs" id="artTabs">' + arts.map((a, i) =>
        '<a class="' + (i === 0 ? "on" : "") + '" data-art="' + a.id + '">' + esc(a.filename) +
        "</a>").join("") + '</div><div id="artBox"></div>';
      $$("#artTabs a").forEach(a => a.onclick = () => {
        $$("#artTabs a").forEach(x => x.classList.remove("on"));
        a.classList.add("on");
        showArtifact(a.dataset.art);
      });
      if (arts.length) showArtifact(arts[0].id);
    };
    if ($("#artScan")) $("#artScan").onchange = load;
    load();
  }, 0);
  return h;
};

/* ---------------------------------------------------------- settings */
Views.settings = async () => {
  const st = await GET("/api/settings");
  const c = State.boot.config;
  const row = (k, v) => "<dt>" + esc(k) + "</dt><dd>" + esc(v) + "</dd>";
  let h = '<div class="grid cols2"><div>' + card("Scan behaviour", "applies to every API",
    '<div class="card-b">' +
      '<div class="frow"><div class="field"><label>Daily schedule (HH:MM, server local time)</label>' +
        '<input id="s_daily_schedule_time" value="' + esc(st.daily_schedule_time || "02:00") + '"></div>' +
        '<div class="field"><label>VARCHAR size for generated DDL</label>' +
        '<input id="s_varchar_size" type="number" value="' + esc(st.varchar_size || "255") + '"></div></div>' +
      '<div class="field"><label>Record cap per scan <span class="hint">0 means crawl to exhaustion</span></label>' +
        '<input id="s_sample_limit" type="number" value="' + esc(st.sample_limit || "0") + '"></div>' +
      '<div class="field"><label>Mock record count <span class="hint">demo mode only</span></label>' +
        '<input id="s_mock_records" type="number" value="' + esc(st.mock_records || "15000") + '"></div>' +
      '<label class="check"><input type="checkbox" id="s_add_run_datetime"' +
        (st.add_run_datetime === "1" ? " checked" : "") +
        "> Append a run_datetime column to generated DDL</label>" +
      '<label class="check" style="margin-top:8px"><input type="checkbox" id="s_keep_removed_columns"' +
        (st.keep_removed_columns === "1" ? " checked" : "") +
        "> Never emit DROP COLUMN, only commented suggestions</label>" +
      '<label class="check" style="margin-top:8px"><input type="checkbox" id="s_store_page_metrics"' +
        (st.store_page_metrics === "1" ? " checked" : "") + "> Store per-page crawl metrics</label>" +
      '<label class="check" style="margin-top:8px"><input type="checkbox" id="s_alert_on_drift"' +
        (st.alert_on_drift === "1" ? " checked" : "") +
        "> Exit with code 3 from the CLI when drift is detected</label>" +
      '<div style="margin-top:16px"><button class="btn primary" id="btnSaveSettings">Save settings</button></div>' +
    "</div>") + "</div>";
  h += "<div>" + card("Runtime configuration", "read-only, set via environment variables",
    '<div class="card-b"><dl class="kv">' +
      row("Token URL", c.token_url) + row("Client id", c.client_id) + row("Client secret", c.client_secret) +
      row("Token auth style", c.token_auth_style) + row("API base URL", c.api_base_url) +
      row("Employee endpoint", c.employee_endpoint) + row("HTTP proxy", c.http_proxy) +
      row("HTTPS proxy", c.https_proxy) + row("Environment", c.environment) +
      row("Verify TLS", c.verify_tls) + row("Database", c.db_path) +
      row("Next scheduled run", State.boot.next_run || "scheduler off") +
    '</dl><div style="margin-top:14px"><button class="btn" id="btnProbe2">Test OAuth and proxy</button></div>' +
    '<div class="banner info" style="margin-top:14px"><div>Secrets are never written to the database or ' +
    "into any generated file. Only masked values are shown here.</div></div></div>") + "</div></div>";
  setTimeout(() => {
    $("#btnSaveSettings").onclick = async () => {
      const body = {
        daily_schedule_time: $("#s_daily_schedule_time").value,
        varchar_size: $("#s_varchar_size").value,
        sample_limit: $("#s_sample_limit").value,
        mock_records: $("#s_mock_records").value,
        add_run_datetime: $("#s_add_run_datetime").checked ? "1" : "0",
        keep_removed_columns: $("#s_keep_removed_columns").checked ? "1" : "0",
        store_page_metrics: $("#s_store_page_metrics").checked ? "1" : "0",
        alert_on_drift: $("#s_alert_on_drift").checked ? "1" : "0"
      };
      try { await POST("/api/settings", body); toast("Settings saved", "", "ok"); }
      catch (e) { toast("Save failed", e.message, "bad"); }
    };
    $("#btnProbe2").onclick = probe;
  }, 0);
  return h;
};

/* ==========================================================================
   ROUTER
   ========================================================================== */
const TITLES = { dashboard: "Dashboard", apis: "API Registry", scans: "Scan History",
                 catalogue: "Column Catalogue", drift: "Drift Log", artifacts: "Artifacts",
                 settings: "Settings", scan: "Scan Detail" };

async function render() {
  const v = $("#view");
  v.innerHTML = '<div class="card"><div class="card-b"><span class="spinner"></span> loading</div></div>';
  $("#crumb").textContent = TITLES[State.route] || State.route;
  $$("#nav a").forEach(a => a.classList.toggle("active", a.dataset.route === State.route));
  try {
    v.innerHTML = await Views[State.route](State.param);
  } catch (e) {
    v.innerHTML = '<div class="banner warn"><div><strong>Could not render this view.</strong><br>' +
      esc(e.message) + "</div></div>";
  }
}
function go(route, param) {
  State.route = route; State.param = param;
  location.hash = route + (param ? "/" + param : "");
  render();
}
window.addEventListener("hashchange", () => {
  const parts = location.hash.replace(/^#/, "").split("/");
  const r = parts[0], p = parts[1];
  if (r && (r !== State.route || p !== State.param)) { State.route = r; State.param = p; render(); }
});

/* ------------------------------------------------------------------ actions */
document.addEventListener("click", async e => {
  const navA = e.target.closest("#nav a");
  if (navA) { go(navA.dataset.route); return; }
  const tab = e.target.closest("#scanTabs a");
  if (tab) { renderScanTab(tab.dataset.tab); return; }
  const el = e.target.closest("[data-act]");
  if (!el) return;
  const act = el.dataset.act, id = el.dataset.id;

  if (act === "open-scan") return go("scan", id);
  if (act === "back-scans") return go("scans");

  if (act === "scan") {
    el.disabled = true;
    try {
      await POST("/api/apis/" + id + "/scan", {});
      toast("Scan queued", "Progress appears in the top bar", "ok");
      pollProgress(true);
    } catch (err) { toast("Could not start the scan", err.message, "bad"); }
    setTimeout(() => el.disabled = false, 1500);
    return;
  }
  if (act === "new-api") {
    modal("Add API", apiForm(null),
      '<button class="btn ghost" data-close>Cancel</button>' +
      '<button class="btn primary" id="mSave">Save API</button>');
    $("#mSave").onclick = async () => {
      try { await POST("/api/apis", readApiForm()); closeModal(); toast("API saved", "", "ok"); render(); }
      catch (err) { toast("Save failed", err.message, "bad"); }
    };
    return;
  }
  if (act === "edit-api") {
    const a = await GET("/api/apis/" + id);
    modal("Edit " + a.name, apiForm(a),
      '<button class="btn ghost" data-close>Cancel</button>' +
      '<button class="btn primary" id="mSave">Save changes</button>');
    $("#mSave").onclick = async () => {
      try { await POST("/api/apis", readApiForm()); closeModal(); toast("API updated", "", "ok"); render(); }
      catch (err) { toast("Save failed", err.message, "bad"); }
    };
    return;
  }
  if (act === "clone-api") {
    modal("Clone to another environment",
      '<div class="field"><label>Target environment</label><select id="cloneEnv">' +
      ["dev", "qa", "prod"].map(x => '<option value="' + x + '">' + x + "</option>").join("") +
      "</select></div>" +
      '<div class="banner info"><div>Every response-shape and naming setting is copied. Remember to ' +
      "point the clone at the correct base URL for that environment.</div></div>",
      '<button class="btn ghost" data-close>Cancel</button>' +
      '<button class="btn primary" id="mClone">Clone</button>');
    $("#mClone").onclick = async () => {
      try {
        await POST("/api/apis/" + id + "/clone", { environment: $("#cloneEnv").value });
        closeModal(); toast("Cloned", "", "ok"); render();
      } catch (err) { toast("Clone failed", err.message, "bad"); }
    };
    return;
  }
  if (act === "del-api") {
    modal("Delete API",
      '<div class="banner warn"><div><strong>This removes the API and every scan, column snapshot, ' +
      "drift event and artifact belonging to it.</strong><br>Baseline history will be lost, so a " +
      "re-added API starts from scratch and its first scan reports every column as new. " +
      "This cannot be undone.</div></div>",
      '<button class="btn ghost" data-close>Cancel</button>' +
      '<button class="btn danger" id="mDel">Delete permanently</button>');
    $("#mDel").onclick = async () => {
      try { await POST("/api/apis/" + id + "/delete", {}); closeModal(); toast("API deleted", "", "warn"); render(); }
      catch (err) { toast("Delete failed", err.message, "bad"); }
    };
    return;
  }
  if (act === "seed") {
    try {
      const r = await POST("/api/seed", { prefix: "API", environments: ["dev"] });
      toast("Seeded", r.created + " placeholder APIs created", "ok");
      render();
    } catch (err) { toast("Seed failed", err.message, "bad"); }
    return;
  }
});

$("#btnScanAll").onclick = () => {
  modal("Scan all enabled APIs",
    '<div class="field"><label>Environment <span class="hint">blank means every environment</span></label>' +
    '<select id="allEnv"><option value="">all</option>' +
    ["dev", "qa", "prod"].map(x => '<option value="' + x + '">' + x + "</option>").join("") +
    "</select></div>" +
    '<div class="field"><label>Max pages per API <span class="hint">blank crawls to exhaustion; use 2 or 3 ' +
    'for a smoke test</span></label><input id="allPages" type="number" placeholder="unlimited"></div>' +
    '<div class="banner warn"><div>A full sweep of 13 APIs at several hundred thousand records each is ' +
    "heavy. Consider a page cap for validation runs.</div></div>",
    '<button class="btn ghost" data-close>Cancel</button>' +
    '<button class="btn primary" id="mAll">Start</button>');
  $("#mAll").onclick = async () => {
    const body = { environment: $("#allEnv").value || null };
    if ($("#allPages").value) body.max_pages = Number($("#allPages").value);
    try { await POST("/api/scan_all", body); closeModal(); toast("Sweep started", "", "ok"); pollProgress(true); }
    catch (err) { toast("Could not start", err.message, "bad"); }
  };
};
document.addEventListener("click", e => { if (e.target.id === "btnScanAll2") $("#btnScanAll").click(); });

async function probe() {
  toast("Testing connection", "requesting an OAuth token through the proxy");
  try {
    const r = await POST("/api/probe", {});
    toast(r.ok ? "Connection OK" : "Connection failed", r.detail + " (" + r.ms + "ms)", r.ok ? "ok" : "bad");
  } catch (e) { toast("Probe failed", e.message, "bad"); }
}
$("#btnProbe").onclick = probe;

/* ------------------------------------------------------------------ progress */
let pollTimer = null;
async function pollProgress() {
  clearTimeout(pollTimer);
  try {
    const p = await GET("/api/progress");
    const act = Object.keys(p.active || {}).map(k => p.active[k]);
    const badge = $("#liveBadge");
    if (act.length) {
      badge.hidden = false;
      $("#liveText").textContent = act.map(a => a.api + " / " + a.phase + " / " +
        num(a.records) + " recs / " + num(a.columns) + " cols").join("   |   ");
    } else if (!badge.hidden) {
      badge.hidden = true;
      if (State.route === "dashboard" || State.route === "scans") render();
    }
    if (p.next_run) $("#schedInfo").textContent = "next run " + String(p.next_run).replace("T", " ");
    pollTimer = setTimeout(pollProgress, act.length ? 1500 : 6000);
  } catch (e) {
    pollTimer = setTimeout(pollProgress, 10000);
  }
}

/* ------------------------------------------------------------------ boot */
(async function init() {
  try {
    State.boot = await GET("/api/bootstrap");
  } catch (e) {
    $("#view").innerHTML = '<div class="banner warn"><div><strong>Cannot reach the backend.</strong><br>' +
      esc(e.message) + "</div></div>";
    return;
  }
  const env = State.boot.config.environment || "dev";
  const pill = $("#envPill");
  pill.textContent = env + (State.boot.mock ? " / demo" : "");
  pill.className = "env-pill " + env;
  const parts = location.hash.replace(/^#/, "").split("/");
  if (parts[0] && Views[parts[0]]) { State.route = parts[0]; State.param = parts[1]; }
  await render();
  pollProgress();
})();
