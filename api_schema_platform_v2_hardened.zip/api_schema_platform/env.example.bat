@echo off
REM Copy to env.bat, fill in the real values, then:   call env.bat && python run.py ui
set SS_TOKEN_URL=https://REPLACE_ME/oauth2/token
set SS_CLIENT_ID=REPLACE_ME
set SS_CLIENT_SECRET=REPLACE_ME
set SS_TOKEN_AUTH_STYLE=basic
set SS_API_BASE_URL=https://REPLACE_ME
set SS_EMPLOYEE_ENDPOINT=/REPLACE_ME

set HTTP_PROXY=http://internet.ford.com:83
set HTTPS_PROXY=http://internet.ford.com:83

set SS_ENV=dev
set SS_UI_HOST=127.0.0.1
set SS_UI_PORT=8770
set SS_VERIFY_TLS=true
