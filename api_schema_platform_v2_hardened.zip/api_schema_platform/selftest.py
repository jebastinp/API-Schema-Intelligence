#!/usr/bin/env python3
"""
Offline end-to-end verification. No network, no credentials, no dependencies.

    python selftest.py
"""
import os, shutil, sys, tempfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

TMP = tempfile.mkdtemp(prefix="ss_selftest_")
os.environ["SS_DB_PATH"] = os.path.join(TMP, "test.db")
os.environ["SS_ARTIFACT_DIR"] = os.path.join(TMP, "artifacts")

import config
from core import db
from agents.orchestrator import Orchestrator
from agents.naming_agent import NamingAgent

PASS, FAIL = [], []


def check(label, condition, detail=""):
    (PASS if condition else FAIL).append(label)
    print(("  PASS  " if condition else "  FAIL  ") + label + (("  ->  " + str(detail)) if detail else ""))


def main():
    print("=" * 72)
    print("API Schema Intelligence Agent - self test")
    print("=" * 72)
    print("temp workspace: " + TMP)

    c = db.init(config.DB_PATH)
    db.set_setting(c, "mock_records", "15000")

    # ---------------------------------------------------------- naming rule
    print("\n[1] naming and collision resolution")
    paths = [
        "effectiveDatedInfo[1]/homeAddress/lineOne",
        "jobs[1]/effectiveDatedJobInfo[1]/businessAddress/lineOne",
        "effectiveDatedInfo[1]/hrStatus",
        "jobs[1]/effectiveDatedJobInfo[1]/hrStatus",
        "jobs[1]/effectiveDatedJobInfo[1]/timezone",
    ]
    n = NamingAgent().assign(paths)
    check("homeAddress_lineOne", n[paths[0]] == "homeAddress_lineOne", n[paths[0]])
    check("businessAddress_lineOne", n[paths[1]] == "businessAddress_lineOne", n[paths[1]])
    check("effectiveDatedInfo_hrStatus", n[paths[2]] == "effectiveDatedInfo_hrStatus", n[paths[2]])
    check("effectiveDatedJobInfo_hrStatus", n[paths[3]] == "effectiveDatedJobInfo_hrStatus", n[paths[3]])
    check("uncontested leaf stays bare", n[paths[4]] == "timezone", n[paths[4]])

    forced = NamingAgent(force_depth={"hrStatus": 3}).assign(paths)
    check("force_depth gives jobs_effectiveDatedJobInfo_hrStatus",
          forced[paths[3]] == "jobs_effectiveDatedJobInfo_hrStatus", forced[paths[3]])

    # ---------------------------------------------------------- baseline scan
    print("\n[2] first scan (baseline)")
    api_id = db.upsert_api(c, {"name": "SELFTEST", "environment": "dev",
                               "endpoint": "/mock", "table_name": "stg_selftest"})
    orc = Orchestrator(db_path=config.DB_PATH, mock=True)
    r1 = orc.run_scan(api_id, trigger="selftest")
    check("scan succeeded", r1.get("status") == "success", r1.get("error", ""))
    check("15,000 records profiled", r1.get("records") == 15000, r1.get("records"))
    check("columns discovered", (r1.get("columns") or 0) > 130, r1.get("columns"))

    cols = db.q(c, "SELECT * FROM scan_columns WHERE scan_id=?", (r1["scan_id"],))
    names = {x["column_name"] for x in cols}
    check("homeAddress_lineOne present", "homeAddress_lineOne" in names)
    check("businessAddress_lineOne present", "businessAddress_lineOne" in names)
    check("both hrStatus variants present",
          "effectiveDatedInfo_hrStatus" in names and "effectiveDatedJobInfo_hrStatus" in names)
    check("dynamic customFields key promoted", "C_GPID" in names)

    late = [x for x in cols if x["first_seen_record"] > 10000]
    check("late-appearing fields detected", len(late) > 20, "%s columns" % len(late))
    check("skillCode is one of them", any(x["column_name"] == "skillCode" for x in late))

    arts = {a["kind"] for a in db.q(c, "SELECT kind FROM artifacts WHERE scan_id=?", (r1["scan_id"],))}
    check("all five artifacts generated",
          arts == {"xquery", "create_table", "alter_table", "columns_csv", "report"}, sorted(arts))
    outdir = r1["artifact_dir"]
    check("artifacts written to disk",
          os.path.isfile(os.path.join(outdir, "create_table.sql")), outdir)

    ddl = db.q1(c, "SELECT content FROM artifacts WHERE scan_id=? AND kind='create_table'",
                (r1["scan_id"],))["content"]
    check("reserved word quoted in DDL", '"primary"' in ddl)
    check("run_datetime appended", "run_datetime timestamp without time zone" in ddl)

    xq = db.q1(c, "SELECT content FROM artifacts WHERE scan_id=? AND kind='xquery'",
               (r1["scan_id"],))["content"]
    check("xquery iterates updateSequence", "for $i in $temp.API_Response/updateSequence" in xq)
    check("xquery uses array index [1]", "jobs[1]/effectiveDatedJobInfo[1]" in xq)

    # ---------------------------------------------------------- second scan
    print("\n[3] second scan (identical payload, expect no drift)")
    r2 = orc.run_scan(api_id, trigger="selftest")
    check("scan succeeded", r2.get("status") == "success", r2.get("error", ""))
    check("no new columns", r2.get("added") == 0, r2.get("added"))
    check("no removed columns", r2.get("removed") == 0, r2.get("removed"))
    alter = db.q1(c, "SELECT content FROM artifacts WHERE scan_id=? AND kind='alter_table'",
                  (r2["scan_id"],))["content"]
    check("alter_table reports nothing to apply", "no structural drift detected" in alter)

    # ---------------------------------------------------------- drift injection
    print("\n[4] third scan with a shrunken payload (expect removals)")
    db.set_setting(c, "mock_records", "5000")   # stops before record 12,000
    r3 = orc.run_scan(api_id, trigger="selftest")
    check("scan succeeded", r3.get("status") == "success", r3.get("error", ""))
    check("removals detected", (r3.get("removed") or 0) > 20, r3.get("removed"))
    alter3 = db.q1(c, "SELECT content FROM artifacts WHERE scan_id=? AND kind='alter_table'",
                   (r3["scan_id"],))["content"]
    check("DROP COLUMN only ever commented out",
          "-- ALTER TABLE" in alter3 and not any(
              l.strip().startswith("ALTER TABLE") and "DROP COLUMN" in l
              for l in alter3.splitlines()))

    print("\n" + "=" * 72)
    print(" %s passed, %s failed" % (len(PASS), len(FAIL)))
    print("=" * 72)
    if FAIL:
        for f in FAIL:
            print("  failed: " + f)
    shutil.rmtree(TMP, ignore_errors=True)
    return 1 if FAIL else 0


if __name__ == "__main__":
    sys.exit(main())
