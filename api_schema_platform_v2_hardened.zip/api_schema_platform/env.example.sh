#!/usr/bin/env bash
# Copy to env.sh, fill in the real values, then:   source env.sh && python run.py ui
export SS_TOKEN_URL="https://REPLACE_ME/oauth2/token"
export SS_CLIENT_ID="REPLACE_ME"
export SS_CLIENT_SECRET="REPLACE_ME"
export SS_TOKEN_AUTH_STYLE="basic"        # or "body"
export SS_API_BASE_URL="https://REPLACE_ME"
export SS_EMPLOYEE_ENDPOINT="/REPLACE_ME"

export HTTP_PROXY="http://internet.ford.com:83"
export HTTPS_PROXY="http://internet.ford.com:83"

export SS_ENV="dev"                        # dev | qa | prod
export SS_UI_HOST="127.0.0.1"
export SS_UI_PORT="8770"
export SS_VERIFY_TLS="true"

# ---------------------------------------------------------------- console auth
# generate the hash with:  python tools/hash_password.py
export SS_ADMIN_USER='admin'
export SS_ADMIN_PASSWORD_HASH=''
# optional read-only account
# export SS_VIEWER_USER='viewer'
# export SS_VIEWER_PASSWORD_HASH=''
# set true when the console is served over HTTPS via a reverse proxy
export SS_COOKIE_SECURE='false'

# ---------------------------------------------------------------- politeness
export SS_RATE_LIMIT_RPS='4'      # requests/sec against the source API, 0 = unlimited
export SS_RESUME='true'           # crash-resume for long crawls
export SS_MAX_DYNAMIC_KEYS='300'  # guard against runaway customFields keys
export SS_MAX_COLUMNS='2000'

# ---------------------------------------------------------------- retention
export SS_RETENTION_LOG_DAYS='30'
export SS_RETENTION_PAGE_DAYS='14'
export SS_RETENTION_SCAN_KEEP='60'
