# Production readiness

## What the hardening pass changed

| Area | Before | Now |
|---|---|---|
| Console access | open to anyone reaching the port | login required, PBKDF2 (240k rounds), sessions, 5-strike lockout |
| CSRF | none | double-submit token on every mutating request |
| Roles | none | `admin` (can scan/edit) and optional read-only `viewer` |
| TLS | could be disabled anywhere | `SS_VERIFY_TLS=false` refused when `SS_ENV=prod` |
| Long crawls | restart from record 0 after a crash | checkpoint every 10 pages, resumes cursor + profile |
| Rate limiting | none | `SS_RATE_LIMIT_RPS` |
| `Retry-After` | ignored | honoured (seconds or HTTP date), capped at 300s |
| DB growth | unbounded | retention pass after every scan |
| Runaway keys | unbounded columns | `SS_MAX_DYNAMIC_KEYS`, `SS_MAX_COLUMNS` |
| Concurrency | two scans could collide | one scan per API, enforced by lock |
| Audit | none | append-only `data/audit.jsonl` |
| Health check | none | `GET /healthz`, unauthenticated |
| Headers | nosniff only | + CSP, X-Frame-Options, Referrer-Policy |

## Go-live checklist

1. `cp env.example.sh env.sh` then `chmod 600 env.sh`. Never commit it.
2. `python tools/hash_password.py` and paste the hash into `SS_ADMIN_PASSWORD_HASH`.
   Do not use `SS_ADMIN_PASSWORD` (plaintext) in prod.
3. Leave `SS_UI_HOST=127.0.0.1`. If the console must be reachable from other
   machines, front it with a TLS reverse proxy and set `SS_COOKIE_SECURE=true`.
4. Set `SS_RATE_LIMIT_RPS` to something the API owners have agreed to.
5. Smoke-test: `python run.py scan --api <name> --env prod --max-pages 3`.
6. Confirm `python selftest.py` passes on the target host.
7. Point monitoring at `/healthz` and alert on exit code 3 from `scan_all`.

## Deliberate design decisions

- **The tool only ever issues GET.** A non-GET `http_method` is rejected outright,
  so it cannot mutate the source system.
- **`DROP COLUMN` is always commented out.** A field missing from today's payload
  usually means the source stopped populating it. That is a human decision.
- **No record values are persisted.** Only column names, JSON paths, type
  observations, string lengths and counts. Checkpoints hold the same, plus the
  cursor. Employee data never lands in the database, the audit log or artifacts.

## Known limitations - decide before you rely on them

1. **Sessions are in-process.** Restarting the server logs everyone out, and
   running two instances behind a load balancer will not share sessions.
   Fine for a single-instance internal tool; not fine for an HA deployment.
2. **Local accounts, not SSO.** If Ford policy requires ADFS/Azure AD for an
   internal web app, this needs to sit behind an authenticating proxy instead.
3. **SQLite.** Comfortable for 13 APIs and years of daily scans. If you need
   concurrent writers or central reporting, move to Postgres.
4. **Full daily crawls are expensive.** If the API exposes a `sequence` or
   timestamp filter, scan incrementally daily and sweep fully weekly.
5. **Not penetration-tested, and no threat model has been signed off by Ford
   InfoSec.** Treat this as an internal tool pending that review.
