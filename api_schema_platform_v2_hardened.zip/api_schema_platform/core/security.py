"""Security primitives - stdlib only: sessions, CSRF, PBKDF2, throttling, audit."""
import base64, hashlib, hmac, json, os, secrets, threading, time

_SESSIONS, _FAILS = {}, {}
_LOCK = threading.Lock()
SESSION_TTL = int(os.environ.get("SS_SESSION_TTL", "3600"))
MAX_FAILS = int(os.environ.get("SS_MAX_LOGIN_FAILS", "5"))
LOCKOUT_SEC = int(os.environ.get("SS_LOCKOUT_SEC", "300"))
PBKDF_ROUNDS = 240000


def hash_password(password, salt=None):
    salt = salt or secrets.token_bytes(16)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, PBKDF_ROUNDS)
    return "pbkdf2$%d$%s$%s" % (PBKDF_ROUNDS, base64.b64encode(salt).decode(),
                                base64.b64encode(dk).decode())


def verify_password(password, stored):
    try:
        scheme, rounds, salt_b64, dk_b64 = stored.split("$")
        if scheme != "pbkdf2":
            return False
        dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"),
                                 base64.b64decode(salt_b64), int(rounds))
        return hmac.compare_digest(dk, base64.b64decode(dk_b64))
    except Exception:
        return False


def throttled(ip):
    with _LOCK:
        rec = _FAILS.get(ip)
        if not rec:
            return 0
        _, until = rec
        if until and time.time() < until:
            return int(until - time.time())
        if until:
            _FAILS.pop(ip, None)
        return 0


def record_fail(ip):
    with _LOCK:
        fails, until = _FAILS.get(ip, (0, 0))
        fails += 1
        if fails >= MAX_FAILS:
            until, fails = time.time() + LOCKOUT_SEC, 0
        _FAILS[ip] = (fails, until)


def clear_fails(ip):
    with _LOCK:
        _FAILS.pop(ip, None)


def new_session(user, role, ip):
    sid, csrf = secrets.token_urlsafe(32), secrets.token_urlsafe(32)
    with _LOCK:
        _SESSIONS[sid] = {"user": user, "role": role, "ip": ip, "csrf": csrf,
                          "created": time.time(), "seen": time.time()}
    return sid, csrf


def get_session(sid):
    if not sid:
        return None
    with _LOCK:
        s = _SESSIONS.get(sid)
        if not s:
            return None
        if time.time() - s["seen"] > SESSION_TTL:
            _SESSIONS.pop(sid, None)
            return None
        s["seen"] = time.time()
        return dict(s)


def drop_session(sid):
    with _LOCK:
        _SESSIONS.pop(sid, None)


def check_csrf(sid, token):
    s = get_session(sid)
    return bool(s and token and hmac.compare_digest(s["csrf"], token))


class Audit:
    """Append-only JSONL trail. Never holds secrets or record payloads."""

    def __init__(self, path):
        self.path = path
        d = os.path.dirname(path)
        if d:
            os.makedirs(d, exist_ok=True)
        self._lock = threading.Lock()

    def write(self, actor, action, target="", outcome="ok", detail=""):
        rec = {"ts": time.strftime("%Y-%m-%dT%H:%M:%S"), "actor": actor, "action": action,
               "target": str(target), "outcome": outcome, "detail": str(detail)[:500]}
        with self._lock:
            with open(self.path, "a", encoding="utf-8") as f:
                f.write(json.dumps(rec, sort_keys=True) + chr(10))
        return rec
