"""Crash-resume checkpoints. Stores cursor + accumulated profile, never record payloads."""
import json, os, tempfile


class Checkpoint:
    def __init__(self, directory, key):
        self.dir = directory
        safe = "".join(ch if ch.isalnum() or ch in "-_" else "_" for ch in key)
        self.path = os.path.join(directory, safe + ".ckpt.json")
        os.makedirs(directory, exist_ok=True)

    def exists(self):
        return os.path.isfile(self.path)

    def load(self):
        try:
            with open(self.path, encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return None

    def save(self, cursor, page, total, profile_state):
        payload = {"cursor": cursor, "page": page, "total": total, "profile": profile_state}
        fd, tmp = tempfile.mkstemp(dir=self.dir, suffix=".tmp")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                json.dump(payload, f)
            os.replace(tmp, self.path)
        except Exception:
            if os.path.exists(tmp):
                os.remove(tmp)
            raise

    def clear(self):
        try:
            os.remove(self.path)
        except OSError:
            pass
