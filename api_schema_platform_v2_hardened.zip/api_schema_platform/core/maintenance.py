"""Retention - keeps the SQLite file from growing without bound."""
import datetime
from core import db


def prune(conn, log_days=30, page_days=14, scan_keep=60, vacuum=False):
    def cutoff(d):
        return (datetime.datetime.now() - datetime.timedelta(days=d)).isoformat(timespec="seconds")

    removed = {}
    removed["logs"] = conn.execute("DELETE FROM logs WHERE ts < ?", (cutoff(log_days),)).rowcount
    removed["raw_pages"] = conn.execute("DELETE FROM raw_pages WHERE ts < ?",
                                        (cutoff(page_days),)).rowcount
    keep = set()
    for a in db.q(conn, "SELECT DISTINCT api_id FROM scans"):
        for r in db.q(conn, "SELECT id FROM scans WHERE api_id=? ORDER BY id DESC LIMIT ?",
                      (a["api_id"], scan_keep)):
            keep.add(r["id"])
    n = 0
    marker = "(pruned - artifacts remain on disk)"
    for r in db.q(conn, "SELECT id FROM scans"):
        if r["id"] in keep:
            continue
        conn.execute("DELETE FROM scan_columns WHERE scan_id=?", (r["id"],))
        conn.execute("UPDATE artifacts SET content=? WHERE scan_id=? AND content<>?",
                     (marker, r["id"], marker))
        n += 1
    removed["scans_pruned"] = n
    conn.commit()
    if vacuum:
        conn.execute("VACUUM")
    return removed
