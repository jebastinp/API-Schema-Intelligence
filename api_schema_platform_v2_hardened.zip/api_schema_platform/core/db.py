"""SQLite persistence layer - stdlib sqlite3 only."""
import datetime, os, sqlite3, threading

_local = threading.local()

SCHEMA = """
CREATE TABLE IF NOT EXISTS apis (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    environment TEXT NOT NULL DEFAULT 'dev',
    base_url TEXT NOT NULL DEFAULT '',
    endpoint TEXT NOT NULL DEFAULT '',
    http_method TEXT NOT NULL DEFAULT 'GET',
    records_key TEXT NOT NULL DEFAULT 'updateSequence',
    root_element TEXT NOT NULL DEFAULT 'root',
    cursor_response_key TEXT NOT NULL DEFAULT 'nextCursor',
    cursor_query_param TEXT NOT NULL DEFAULT 'cursor',
    cursor_pre_encoded INTEGER NOT NULL DEFAULT 1,
    page_size_param TEXT NOT NULL DEFAULT 'pageSize',
    page_size INTEGER NOT NULL DEFAULT 1000,
    extra_query TEXT NOT NULL DEFAULT '',
    array_nodes TEXT NOT NULL DEFAULT '',
    force_depth TEXT NOT NULL DEFAULT '{}',
    table_schema TEXT NOT NULL DEFAULT 'dbo',
    table_name TEXT NOT NULL DEFAULT '',
    enabled INTEGER NOT NULL DEFAULT 1,
    notes TEXT NOT NULL DEFAULT '',
    created_at TEXT, updated_at TEXT,
    UNIQUE(name, environment)
);
CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY, value TEXT NOT NULL, updated_at TEXT
);
CREATE TABLE IF NOT EXISTS scans (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    api_id INTEGER NOT NULL,
    environment TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'running',
    trigger TEXT NOT NULL DEFAULT 'manual',
    started_at TEXT, finished_at TEXT, duration_sec REAL,
    pages INTEGER DEFAULT 0, records INTEGER DEFAULT 0,
    columns_total INTEGER DEFAULT 0,
    added_count INTEGER DEFAULT 0, removed_count INTEGER DEFAULT 0, changed_count INTEGER DEFAULT 0,
    message TEXT DEFAULT '',
    FOREIGN KEY(api_id) REFERENCES apis(id)
);
CREATE TABLE IF NOT EXISTS scan_columns (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    scan_id INTEGER NOT NULL,
    column_name TEXT NOT NULL,
    json_path TEXT NOT NULL,
    xpath TEXT NOT NULL DEFAULT '',
    leaf TEXT NOT NULL DEFAULT '',
    parent_path TEXT NOT NULL DEFAULT '',
    types TEXT NOT NULL DEFAULT '',
    non_null_count INTEGER DEFAULT 0,
    seen_count INTEGER DEFAULT 0,
    max_len INTEGER DEFAULT 0,
    first_seen_record INTEGER DEFAULT 0,
    is_dynamic INTEGER DEFAULT 0,
    FOREIGN KEY(scan_id) REFERENCES scans(id)
);
CREATE INDEX IF NOT EXISTS ix_scancol ON scan_columns(scan_id, column_name);
CREATE TABLE IF NOT EXISTS schema_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    scan_id INTEGER NOT NULL, api_id INTEGER NOT NULL,
    event_type TEXT NOT NULL, column_name TEXT NOT NULL,
    json_path TEXT DEFAULT '', details TEXT DEFAULT '',
    first_seen_record INTEGER DEFAULT 0, detected_at TEXT
);
CREATE TABLE IF NOT EXISTS artifacts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    scan_id INTEGER NOT NULL, api_id INTEGER NOT NULL,
    kind TEXT NOT NULL, filename TEXT NOT NULL,
    content TEXT NOT NULL, bytes INTEGER DEFAULT 0, created_at TEXT
);
CREATE TABLE IF NOT EXISTS logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    scan_id INTEGER, api_id INTEGER, level TEXT, message TEXT, ts TEXT
);
CREATE TABLE IF NOT EXISTS raw_pages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    scan_id INTEGER NOT NULL, page_no INTEGER, http_status INTEGER,
    record_count INTEGER, next_cursor TEXT, elapsed_ms INTEGER, ts TEXT
);
"""

DEFAULT_SETTINGS = {
    "naming_strategy": "leaf_then_parent",
    "array_index_mode": "first_only",
    "varchar_size": "255",
    "add_run_datetime": "1",
    "keep_removed_columns": "1",
    "daily_schedule_time": "02:00",
    "sample_limit": "0",
    "store_page_metrics": "1",
    "alert_on_drift": "1",
    "mock_records": "15000",
}


def _now():
    return datetime.datetime.now().isoformat(timespec="seconds")


def connect(db_path):
    if getattr(_local, "conn", None) is None or getattr(_local, "path", None) != db_path:
        d = os.path.dirname(db_path)
        if d:
            os.makedirs(d, exist_ok=True)
        c = sqlite3.connect(db_path, timeout=30, check_same_thread=False)
        c.row_factory = sqlite3.Row
        c.execute("PRAGMA journal_mode=WAL")
        c.execute("PRAGMA foreign_keys=ON")
        _local.conn = c
        _local.path = db_path
    return _local.conn


def init(db_path):
    c = connect(db_path)
    c.executescript(SCHEMA)
    for k, v in DEFAULT_SETTINGS.items():
        c.execute("INSERT OR IGNORE INTO settings(key,value,updated_at) VALUES(?,?,?)", (k, v, _now()))
    c.commit()
    return c


def q(c, sql, args=()):
    return [dict(r) for r in c.execute(sql, args).fetchall()]


def q1(c, sql, args=()):
    r = c.execute(sql, args).fetchone()
    return dict(r) if r else None


def ex(c, sql, args=()):
    cur = c.execute(sql, args)
    c.commit()
    return cur.lastrowid


def get_settings(c):
    return {r["key"]: r["value"] for r in c.execute("SELECT key,value FROM settings")}


def set_setting(c, k, v):
    ex(c, "INSERT INTO settings(key,value,updated_at) VALUES(?,?,?) "
          "ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at",
       (k, str(v), _now()))


def log(c, scan_id, api_id, level, message):
    try:
        ex(c, "INSERT INTO logs(scan_id,api_id,level,message,ts) VALUES(?,?,?,?,?)",
           (scan_id, api_id, level, str(message)[:4000], _now()))
    except Exception:
        pass


API_FIELDS = ["name", "environment", "base_url", "endpoint", "http_method", "records_key",
              "root_element", "cursor_response_key", "cursor_query_param", "cursor_pre_encoded",
              "page_size_param", "page_size", "extra_query", "array_nodes", "force_depth",
              "table_schema", "table_name", "enabled", "notes"]


def upsert_api(c, data):
    aid = data.get("id")
    vals = {k: data.get(k) for k in API_FIELDS if k in data and data.get(k) is not None}
    if aid:
        sets = ",".join(k + "=?" for k in vals)
        ex(c, "UPDATE apis SET " + sets + ", updated_at=? WHERE id=?",
           tuple(vals.values()) + (_now(), aid))
        return int(aid)
    cols = ",".join(vals.keys())
    ph = ",".join("?" * len(vals))
    return ex(c, "INSERT INTO apis(" + cols + ",created_at,updated_at) VALUES(" + ph + ",?,?)",
              tuple(vals.values()) + (_now(), _now()))
