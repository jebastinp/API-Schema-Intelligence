
import os, sys, json
sys.path.insert(0, ".")
os.environ["SS_ENV"] = "dev"
from core.security import hash_password, verify_password, new_session, check_csrf, Audit
from core.checkpoint import Checkpoint
from agents.profiler_agent import ProfilerAgent
from agents.crawler_agent import CrawlerAgent
import config

P, F = 0, []
def t(name, cond):
    global P
    if cond: P += 1
    else: F.append(name)

h = hash_password("correct horse battery staple")
t("pbkdf2 accepts right password", verify_password("correct horse battery staple", h))
t("pbkdf2 rejects wrong password", not verify_password("wrong", h))
t("pbkdf2 rejects junk hash", not verify_password("x", "garbage"))
sid, csrf = new_session("admin", "admin", "127.0.0.1")
t("csrf accepts real token", check_csrf(sid, csrf))
t("csrf rejects bad token", not check_csrf(sid, "nope"))
t("csrf rejects empty token", not check_csrf(sid, ""))

class E:
    def __init__(self, v): self.headers = {"Retry-After": v}
t("Retry-After seconds", CrawlerAgent._retry_after(E("42")) == 42)
t("Retry-After junk -> None", CrawlerAgent._retry_after(E("soon")) is None)
t("Retry-After absent -> None", CrawlerAgent._retry_after(E(None)) is None)

p = ProfilerAgent(max_dynamic_keys=2, max_columns=500, logger=lambda a, b: None)
for i in range(5):
    p.observe({"customFields": {("K%d" % i): i}}, i + 1)
keys = [k for k in p.profile if k.startswith("customFields/")]
t("dynamic-key cap holds", len(keys) == 2 and p.suppressed["dynamic"] == 3)

p2 = ProfilerAgent(max_columns=3, logger=lambda a, b: None)
p2.observe({"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}, 1)
t("column cap holds", len(p2.profile) == 3 and p2.suppressed["columns"] == 2)

src = ProfilerAgent(logger=lambda a, b: None)
src.observe({"name": {"firstName": "Martin"}, "jobs": [{"timezone": "Europe/London"}]}, 1)
ck = Checkpoint("data/_t", "unit")
ck.save("CUR123", 7, 700, src.export_state())
dst = ProfilerAgent(logger=lambda a, b: None)
st = ck.load()
t("checkpoint round-trips cursor", st["cursor"] == "CUR123" and st["page"] == 7)
t("checkpoint restores profile", dst.import_state(st["profile"])
  and set(dst.profile) == set(src.profile) and dst.records == 1)
t("checkpoint types survive", isinstance(list(dst.profile.values())[0]["types"], set))
t("checkpoint holds no record values", "Martin" not in json.dumps(st))
ck.clear()
t("checkpoint clears", not ck.exists())

try:
    CrawlerAgent(config, None).crawl({"http_method": "POST"}, lambda r, n: None)
    t("non-GET refused", False)
except Exception as e:
    t("non-GET refused", "read-only" in str(e))

os.environ["SS_ENV"] = "prod"
import importlib
importlib.reload(config)
config.VERIFY_TLS = False
try:
    config.validate()
    t("prod refuses TLS off", False)
except config.ConfigError as e:
    t("prod refuses TLS off", "SS_VERIFY_TLS" in str(e))
config.VERIFY_TLS = True
config.AUTH_DISABLED = True
try:
    config.validate()
    t("prod refuses auth off", False)
except config.ConfigError:
    t("prod refuses auth off", True)
config.AUTH_DISABLED = False
config.ADMIN_PASSWORD_HASH = ""
config.ADMIN_PASSWORD = ""
try:
    config.validate(for_server=True)
    t("prod demands admin hash", False)
except config.ConfigError:
    t("prod demands admin hash", True)

a = Audit("data/_t/audit.jsonl")
r = a.write("tester", "unit.test", "target", detail="x")
t("audit writes a line", os.path.getsize("data/_t/audit.jsonl") > 0 and r["actor"] == "tester")

print("HARDENING SELF-TEST: %d passed, %d failed" % (P, len(F)))
for f in F: print("  FAIL:", f)
sys.exit(1 if F else 0)
