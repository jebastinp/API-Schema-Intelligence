"""
Central configuration. Everything is overridable by environment variable.
Nothing secret is ever written to disk or into the SQLite database.
"""
import os

_HERE = os.path.dirname(os.path.abspath(__file__))

# ---------------------------------------------------------------- OAuth2
TOKEN_URL     = os.environ.get("SS_TOKEN_URL",     "REPLACE_ME")
CLIENT_ID     = os.environ.get("SS_CLIENT_ID",     "REPLACE_ME")
CLIENT_SECRET = os.environ.get("SS_CLIENT_SECRET", "REPLACE_ME")

# "basic" -> credentials in the Authorization header (RFC 6749 preferred)
# "body"  -> credentials as form fields
TOKEN_AUTH_STYLE = os.environ.get("SS_TOKEN_AUTH_STYLE", "basic")
TOKEN_SCOPE      = os.environ.get("SS_TOKEN_SCOPE", "")

# ---------------------------------------------------------------- Proxy
HTTP_PROXY  = os.environ.get("HTTP_PROXY",  os.environ.get("SS_HTTP_PROXY",  "http://internet.ford.com:83"))
HTTPS_PROXY = os.environ.get("HTTPS_PROXY", os.environ.get("SS_HTTPS_PROXY", "http://internet.ford.com:83"))
NO_PROXY    = os.environ.get("NO_PROXY",    os.environ.get("SS_NO_PROXY", ""))

# ---------------------------------------------------------------- API
API_BASE_URL      = os.environ.get("SS_API_BASE_URL", "REPLACE_ME")
EMPLOYEE_ENDPOINT = os.environ.get("SS_EMPLOYEE_ENDPOINT", "REPLACE_ME")

# ---------------------------------------------------------------- Runtime
ENVIRONMENT   = os.environ.get("SS_ENV", "dev")            # dev | qa | prod
DB_PATH       = os.environ.get("SS_DB_PATH", os.path.join(_HERE, "data", "ss_schema.db"))
ARTIFACT_DIR  = os.environ.get("SS_ARTIFACT_DIR", os.path.join(_HERE, "data", "artifacts"))
HTTP_TIMEOUT  = int(os.environ.get("SS_HTTP_TIMEOUT", "120"))
MAX_RETRIES   = int(os.environ.get("SS_MAX_RETRIES", "4"))
RETRY_BACKOFF = float(os.environ.get("SS_RETRY_BACKOFF", "2.0"))
VERIFY_TLS    = os.environ.get("SS_VERIFY_TLS", "true").lower() != "false"
RATE_LIMIT_RPS = float(os.environ.get("SS_RATE_LIMIT_RPS", "0"))   # 0 = unlimited
RESUME_ENABLED = os.environ.get("SS_RESUME", "true").lower() != "false"
CHECKPOINT_DIR = os.environ.get("SS_CHECKPOINT_DIR", os.path.join(_HERE, "data", "checkpoints"))
MAX_DYNAMIC_KEYS = int(os.environ.get("SS_MAX_DYNAMIC_KEYS", "300"))
MAX_COLUMNS      = int(os.environ.get("SS_MAX_COLUMNS", "2000"))
RETENTION_LOG_DAYS  = int(os.environ.get("SS_RETENTION_LOG_DAYS", "30"))
RETENTION_PAGE_DAYS = int(os.environ.get("SS_RETENTION_PAGE_DAYS", "14"))
RETENTION_SCAN_KEEP = int(os.environ.get("SS_RETENTION_SCAN_KEEP", "60"))

# ---------------------------------------------------------------- Console auth
AUTH_DISABLED        = os.environ.get("SS_AUTH_DISABLED", "false").lower() == "true"
ADMIN_USER           = os.environ.get("SS_ADMIN_USER", "admin")
ADMIN_PASSWORD_HASH  = os.environ.get("SS_ADMIN_PASSWORD_HASH", "")
ADMIN_PASSWORD       = os.environ.get("SS_ADMIN_PASSWORD", "")
VIEWER_USER          = os.environ.get("SS_VIEWER_USER", "")
VIEWER_PASSWORD_HASH = os.environ.get("SS_VIEWER_PASSWORD_HASH", "")
COOKIE_SECURE        = os.environ.get("SS_COOKIE_SECURE", "false").lower() == "true"
AUDIT_LOG            = os.environ.get("SS_AUDIT_LOG", os.path.join(_HERE, "data", "audit.jsonl"))

# ---------------------------------------------------------------- UI
UI_HOST = os.environ.get("SS_UI_HOST", "127.0.0.1")
UI_PORT = int(os.environ.get("SS_UI_PORT", "8770"))


def redacted():
    def mask(v):
        if not v or v == "REPLACE_ME":
            return "(not set)"
        return v[:3] + "*" * 6 + v[-2:] if len(v) > 6 else "*" * len(v)
    return {
        "token_url": TOKEN_URL,
        "client_id": mask(CLIENT_ID),
        "client_secret": mask(CLIENT_SECRET),
        "token_auth_style": TOKEN_AUTH_STYLE,
        "api_base_url": API_BASE_URL,
        "employee_endpoint": EMPLOYEE_ENDPOINT,
        "http_proxy": HTTP_PROXY,
        "https_proxy": HTTPS_PROXY,
        "environment": ENVIRONMENT,
        "verify_tls": VERIFY_TLS,
        "db_path": DB_PATH,
    }


class ConfigError(Exception):
    pass


def is_prod():
    return str(ENVIRONMENT).lower().startswith("prod")


def validate(for_server=False):
    """Fail fast on an unsafe configuration."""
    problems, warnings = [], []
    if TOKEN_URL == "REPLACE_ME" or CLIENT_ID == "REPLACE_ME" or CLIENT_SECRET == "REPLACE_ME":
        warnings.append("OAuth credentials are not set - only demo/mock mode will work")
    if is_prod():
        if not VERIFY_TLS:
            problems.append("SS_VERIFY_TLS=false is refused when SS_ENV=prod")
        if AUTH_DISABLED:
            problems.append("SS_AUTH_DISABLED=true is refused when SS_ENV=prod")
        if for_server and not (ADMIN_PASSWORD_HASH or ADMIN_PASSWORD):
            problems.append("set SS_ADMIN_PASSWORD_HASH before serving the console in prod")
        if ADMIN_PASSWORD and not ADMIN_PASSWORD_HASH:
            warnings.append("SS_ADMIN_PASSWORD is plaintext - prefer SS_ADMIN_PASSWORD_HASH")
        if for_server and UI_HOST not in ("127.0.0.1", "localhost", "::1") and not COOKIE_SECURE:
            warnings.append("console bound off-loopback without SS_COOKIE_SECURE=true - "
                            "put it behind a TLS reverse proxy")
    if not VERIFY_TLS:
        warnings.append("TLS verification is OFF - never do this outside a lab")
    if problems:
        raise ConfigError("; ".join(problems))
    return warnings
