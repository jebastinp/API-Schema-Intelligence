#!/usr/bin/env python3
"""
Entry point for the API Schema Intelligence Agent.

    python run.py ui                    start the web console (default)
    python run.py ui --demo             start with the offline mock crawler
    python run.py scan --api 1          scan one API and exit
    python run.py scan-all              scan every enabled API and exit
    python run.py scan-all --env qa     restrict to one environment
    python run.py list                  list registered APIs
    python run.py add --json cfg.json   register APIs from a JSON file
    python run.py probe                 test OAuth + proxy connectivity

Exit codes for the non-interactive commands:
    0  success, no structural drift
    3  success, but new or removed columns were detected
    1  failure
"""
import argparse, json, os, sys, webbrowser

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import config
from core import db
from agents.orchestrator import Orchestrator
from agents.scheduler_agent import SchedulerAgent


def _print_table(rows, cols):
    if not rows:
        print("  (nothing)")
        return
    widths = [max(len(c), max(len(str(r.get(c, ""))) for r in rows)) for c in cols]
    print("  " + "  ".join(c.ljust(w) for c, w in zip(cols, widths)))
    print("  " + "  ".join("-" * w for w in widths))
    for r in rows:
        print("  " + "  ".join(str(r.get(c, "")).ljust(w) for c, w in zip(cols, widths)))


def cmd_ui(args):
    from web import server
    orc = Orchestrator(db_path=config.DB_PATH, mock=args.demo)
    sched = SchedulerAgent(orc, config.DB_PATH)
    if not args.no_schedule:
        sched.start()
    srv = server.serve(orc, sched, config.DB_PATH, mock=args.demo,
                       host=args.host, port=args.port)
    url = "http://%s:%s/" % (args.host or config.UI_HOST, args.port or config.UI_PORT)
    print("=" * 66)
    print(" API Schema Intelligence Console")
    print("=" * 66)
    print(" URL          : " + url)
    print(" Database     : " + config.DB_PATH)
    print(" Artifacts    : " + config.ARTIFACT_DIR)
    print(" Environment  : " + config.ENVIRONMENT)
    print(" Mode         : " + ("DEMO (offline mock crawler)" if args.demo else "LIVE"))
    print(" Scheduler    : " + ("off" if args.no_schedule else "on, daily at " +
          db.get_settings(db.connect(config.DB_PATH)).get("daily_schedule_time", "02:00")))
    print(" Proxy        : " + str(config.HTTPS_PROXY))
    print("=" * 66)
    print(" Press Ctrl+C to stop.")
    if args.open:
        try:
            webbrowser.open(url)
        except Exception:
            pass
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\nshutting down")
        sched.stop()
        srv.shutdown()
    return 0


def _drift_exit(results):
    c = db.connect(config.DB_PATH)
    alert = db.get_settings(c).get("alert_on_drift", "1") == "1"
    if any(r.get("status") == "failed" for r in results):
        return 1
    if alert and any((r.get("added") or 0) + (r.get("removed") or 0) for r in results):
        return 3
    return 0


def cmd_scan(args):
    orc = Orchestrator(db_path=config.DB_PATH, mock=args.demo)
    r = orc.run_scan(args.api, trigger="cli", max_pages=args.max_pages, max_records=args.max_records)
    print(json.dumps(r, indent=2, default=str))
    return _drift_exit([r])


def cmd_scan_all(args):
    orc = Orchestrator(db_path=config.DB_PATH, mock=args.demo)
    results = orc.run_all(environment=args.env, trigger="cli-all", max_pages=args.max_pages)
    print(json.dumps(results, indent=2, default=str))
    total_added = sum(r.get("added") or 0 for r in results)
    total_removed = sum(r.get("removed") or 0 for r in results)
    print("\n%s APIs scanned, +%s new columns, -%s removed columns"
          % (len(results), total_added, total_removed))
    return _drift_exit(results)


def cmd_list(args):
    c = db.init(config.DB_PATH)
    rows = db.q(c, "SELECT id,name,environment,endpoint,table_name,page_size,enabled FROM apis "
                   "ORDER BY environment,name")
    _print_table(rows, ["id", "name", "environment", "endpoint", "table_name", "page_size", "enabled"])
    return 0


def cmd_add(args):
    c = db.init(config.DB_PATH)
    with open(args.json, "r", encoding="utf-8") as f:
        payload = json.load(f)
    items = payload if isinstance(payload, list) else [payload]
    n = 0
    for it in items:
        it.setdefault("environment", config.ENVIRONMENT)
        if not it.get("table_name"):
            it["table_name"] = "stg_" + str(it.get("name", "api")).lower()
        try:
            db.upsert_api(c, it)
            n += 1
        except Exception as e:
            print("  skipped %s: %s" % (it.get("name"), e))
    print("registered/updated %s APIs" % n)
    return 0


def cmd_probe(args):
    from agents.auth_agent import AuthAgent
    r = AuthAgent(config).probe()
    print(json.dumps(r, indent=2))
    return 0 if r["ok"] else 1


def main():
    ap = argparse.ArgumentParser(prog="run.py", description="API Schema Intelligence Agent")
    sub = ap.add_subparsers(dest="cmd")

    p = sub.add_parser("ui", help="start the web console")
    p.add_argument("--host", default=None)
    p.add_argument("--port", type=int, default=None)
    p.add_argument("--demo", action="store_true", help="use the offline mock crawler")
    p.add_argument("--no-schedule", action="store_true", help="do not start the daily scheduler")
    p.add_argument("--open", action="store_true", help="open a browser window")
    p.set_defaults(fn=cmd_ui)

    p = sub.add_parser("scan", help="scan one API")
    p.add_argument("--api", type=int, required=True, help="api id (see: run.py list)")
    p.add_argument("--max-pages", type=int, default=None)
    p.add_argument("--max-records", type=int, default=None)
    p.add_argument("--demo", action="store_true")
    p.set_defaults(fn=cmd_scan)

    p = sub.add_parser("scan-all", help="scan every enabled API")
    p.add_argument("--env", default=None, choices=["dev", "qa", "prod"])
    p.add_argument("--max-pages", type=int, default=None)
    p.add_argument("--demo", action="store_true")
    p.set_defaults(fn=cmd_scan_all)

    p = sub.add_parser("list", help="list registered APIs")
    p.set_defaults(fn=cmd_list)

    p = sub.add_parser("add", help="register APIs from a JSON file")
    p.add_argument("--json", required=True)
    p.set_defaults(fn=cmd_add)

    p = sub.add_parser("probe", help="test OAuth and proxy connectivity")
    p.set_defaults(fn=cmd_probe)

    args = ap.parse_args()
    if not getattr(args, "fn", None):
        args = ap.parse_args(["ui"])
    db.init(config.DB_PATH)
    sys.exit(args.fn(args))


if __name__ == "__main__":
    main()
