@echo off
REM Windows Task Scheduler entry point for the daily sweep.
REM Exit code 3 means schema drift was detected.
cd /d "%~dp0"
if exist env.bat call env.bat
if not exist logs mkdir logs
python run.py scan-all >> logs\daily.log 2>&1
exit /b %ERRORLEVEL%
