#!/usr/bin/env bash
cd "$(dirname "$0")"
if [ -f env.sh ]; then . ./env.sh; fi
exec python3 run.py ui "$@"
