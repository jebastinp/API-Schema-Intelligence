# API Schema Intelligence Agent

Daily schema-discovery, drift detection and code generation for cursor-paginated
JSON APIs.

**Zero third-party packages.** Standard library only: `urllib` for HTTP,
`sqlite3` for storage, `http.server` for the web console, hand-written CSS/JS
for the UI. Nothing to `pip install`, nothing to get through a proxy whitelist.

---

## 1. What it does

For every registered API, once per day:

1. **Crawl** every page by following `nextCursor` until the cursor is exhausted.
   Records are streamed, so a 600k-record API never sits in memory.
2. **Profile** each record into leaf JSON paths and build the *union* of all
   paths. This is the key point: if the first 10,000 records expose 140 fields
   and record 12,001 suddenly carries a populated `wtaTemplateJobFields` block,
   the extra 30 columns are still discovered.
3. **Name** each path as a SQL/XML column using the same convention as the
   existing hand-written IICS mapping (see section 5).
4. **Diff** today's column set against the previous successful scan of the same
   API *and the same environment*, recording NEW, REMOVED, TYPE_CHANGED,
   WIDENED, NOW_ALWAYS_NULL and NOW_POPULATED events.
5. **Generate** five artifacts per scan:
   - `transform.xquery` - the IICS mapping expression
   - `create_table.sql` - full `CREATE TABLE ... _stg` DDL
   - `alter_table.sql` - incremental `ADD COLUMN` for the delta
   - `columns.csv` - the column catalogue
   - `drift_report.txt` - the human-readable daily report
6. **Store** everything in SQLite: API settings, every scan, every column
   snapshot, every drift event, per-page latency metrics, the full execution log
   and the generated artifacts. Nothing is thrown away, so any past scan can be
   reopened and compared.

---

## 2. Install and run

Requires Python 3.8 or newer. No virtualenv needed, though one does no harm.

```bash
unzip ss_schema_agent.zip
cd ss_schema_agent
python run.py ui --demo          # offline demo, no credentials required
```

Open <http://127.0.0.1:8770>.

`--demo` uses a built-in mock crawler that replays a realistic 15,000-record
payload, including fields that only appear after record 12,000. Use it to learn
the tool and to validate the pipeline before pointing at anything real.

### Running against the real APIs

Set the environment variables, then start without `--demo`:

**Linux / macOS**
```bash
export SS_TOKEN_URL="https://.../oauth2/token"
export SS_CLIENT_ID="..."
export SS_CLIENT_SECRET="..."
export SS_API_BASE_URL="https://..."
export SS_EMPLOYEE_ENDPOINT="/v1/employees/updates"
export HTTPS_PROXY="http://internet.ford.com:83"
export HTTP_PROXY="http://internet.ford.com:83"
export SS_ENV="dev"
python run.py ui
```

**Windows (cmd)**
```bat
set SS_TOKEN_URL=https://.../oauth2/token
set SS_CLIENT_ID=...
set SS_CLIENT_SECRET=...
set SS_API_BASE_URL=https://...
set SS_EMPLOYEE_ENDPOINT=/v1/employees/updates
set HTTPS_PROXY=http://internet.ford.com:83
set HTTP_PROXY=http://internet.ford.com:83
set SS_ENV=dev
python run.py ui
```

Copy `env.example.sh` / `env.example.bat` and edit, or use the provided
`start_ui.sh` / `start_ui.bat` wrappers.

Click **Test connection** in the top bar to confirm the token endpoint is
reachable through the proxy before you attempt a crawl.

---

## 3. First run, step by step

1. `python run.py ui --demo`
2. Go to **API Registry** and click **Add API**. Fill in name, endpoint,
   records key (`updateSequence`), cursor field (`nextCursor`) and the target
   staging table. Or click **Seed 13 placeholders** and edit them one by one.
3. Click **Scan** on that row. Watch progress in the top bar.
4. Open the scan. Tab through **Columns**, **Drift events**, **Artifacts**,
   **Pages** and **Logs**.
5. Copy the generated XQuery into IICS and the DDL into your Postgres client.
6. Scan again tomorrow. The second scan diffs against the first and
   `alter_table.sql` will contain only the delta.

Smoke-test a real API cheaply: use **Scan all APIs** with *Max pages* set to 2.

---

## 4. Command line

```bash
python run.py ui                     # web console (default command)
python run.py ui --demo --open       # demo mode, open a browser
python run.py ui --no-schedule       # console without the daily trigger
python run.py list                   # list registered APIs with their ids
python run.py scan --api 3           # scan one API, print JSON, exit
python run.py scan --api 3 --max-pages 2
python run.py scan-all               # scan every enabled API
python run.py scan-all --env qa      # restrict to one environment
python run.py add --json apis.example.json
python run.py probe                  # test OAuth + proxy only
```

Exit codes: `0` clean, `3` drift detected, `1` failure. That makes the daily job
trivial to wire into any scheduler:

```
0 2 * * *  cd /opt/ss_schema_agent && python run.py scan-all >> logs/daily.log 2>&1 || \
           mail -s "API schema drift detected" you@ford.com < data/artifacts/latest/drift_report.txt
```

On Windows use Task Scheduler and point it at `scan_all.bat`.

The console has its own built-in scheduler, so if you leave `run.py ui` running
as a service you do not need cron at all. Set the time under **Settings**.

---

## 5. Column naming

The rule reproduces the existing production mapping:

1. start with the bare leaf name - `timezone`, `department`
2. on collision, prefix the **immediate parent only**
   - `homeAddress/lineOne` and `businessAddress/lineOne`
     become `homeAddress_lineOne` and `businessAddress_lineOne`
3. if still ambiguous, keep prepending ancestors until unique
4. arrays project index `[1]` only, matching `$i/jobs[1]/...` in the XQuery
5. `customFields` keys are promoted to their own columns, and the container
   itself is kept as a column too

**One deliberate difference to confirm.** Your existing table has
`jobs_effectiveDatedJobInfo_hrStatus`, which is three segments. Two segments
(`effectiveDatedJobInfo_hrStatus`) are already unique, so the automatic rule
stops there. If you want to match the existing table exactly, set `force_depth`
on that API:

```json
{"hrStatus": 3, "customFields": 3, "importedBadgeId": 3}
```

`force_depth` pins a leaf name to a fixed number of path segments. Edit it in
the API form; it is validated as JSON before saving.

---

## 6. Environments

dev, QA and prod are modelled as **separate API rows** that share a name.
Use **Clone** to copy a fully configured API into another environment, then
change the base URL.

Diffs are always scoped to the same API *and* environment, so a QA schema change
never shows up as prod drift. Nothing is ever written back to any API - every
request is a `GET`.

---

## 7. Removed columns are never dropped automatically

When a field disappears from the payload, `alter_table.sql` emits the
`DROP COLUMN` as a **comment**. A field missing from today's response usually
means the source stopped populating it, not that the column should go. Dropping
it destroys history irreversibly, so that stays a human decision. New columns,
being additive and safe, are emitted ready to run inside a transaction.

---

## 8. Layout

```
ss_schema_agent/
  run.py                     CLI entry point
  config.py                  all configuration, env-var driven
  core/db.py                 SQLite schema and helpers
  agents/
    auth_agent.py            OAuth2 client_credentials + proxy
    crawler_agent.py         cursor pagination, retry, backoff
    profiler_agent.py        JSON flattening and union profiling
    naming_agent.py          collision-resolving column names
    diff_agent.py            day-over-day schema comparison
    generator_agent.py       XQuery, DDL, CSV, report generation
    scheduler_agent.py       daily trigger thread
    mock_agent.py            offline crawler for demo mode
    orchestrator.py          wires the agents together per scan
  web/
    server.py                stdlib JSON API + static file server
    static/{index.html,app.css,app.js}
  data/                      created on first run
    ss_schema.db             SQLite database
    artifacts/<api>_<env>/scan_<id>/...
  selftest.py                offline end-to-end verification
```

Each agent is a standalone class with one job and no hidden global state, so any
of them can be imported and unit-tested on its own.

---

## 9. Verify the install

```bash
python selftest.py
```

Runs the whole pipeline twice against the mock provider in a temporary database
and asserts that: the collision rule produces `homeAddress_lineOne` and
`businessAddress_lineOne`; late-appearing fields are discovered; the second scan
reports zero drift against an identical first scan; and all five artifacts are
generated.

---

## 10. Operational notes

- **Cost of a full sweep.** 13 APIs at up to 600k records each is a lot of HTTP.
  If the APIs accept a `sequence` or timestamp filter, put it in *Extra query
  string* and scan incrementally, running a full sweep weekly. Otherwise cap
  pages on weekdays and go unlimited at the weekend.
- **Secrets** are read from the environment and never written to the database,
  the artifacts or the log. The Settings page shows masked values only.
- **Bind address** defaults to `127.0.0.1`. Set `SS_UI_HOST=0.0.0.0` to expose
  it, but note there is **no authentication layer** - put it behind a reverse
  proxy with SSO if more than one person needs access.
- **TLS.** Set `SS_VERIFY_TLS=false` only if the corporate proxy re-signs
  certificates and you understand what you are giving up.
- **Concurrency.** Scans run in background threads; SQLite is in WAL mode.
  Sequential scans are intentional - hammering 13 APIs in parallel through one
  proxy tends to produce 429s.

---

## 11. Environment variables

| Variable | Default | Purpose |
|---|---|---|
| `SS_TOKEN_URL` | REPLACE_ME | OAuth2 token endpoint |
| `SS_CLIENT_ID` | REPLACE_ME | client id |
| `SS_CLIENT_SECRET` | REPLACE_ME | client secret |
| `SS_TOKEN_AUTH_STYLE` | `basic` | `basic` header or `body` form fields |
| `SS_TOKEN_SCOPE` | empty | optional scope |
| `SS_API_BASE_URL` | REPLACE_ME | default base URL for APIs |
| `SS_EMPLOYEE_ENDPOINT` | REPLACE_ME | default endpoint path |
| `HTTP_PROXY` / `SS_HTTP_PROXY` | `http://internet.ford.com:83` | proxy |
| `HTTPS_PROXY` / `SS_HTTPS_PROXY` | `http://internet.ford.com:83` | proxy |
| `SS_ENV` | `dev` | label shown in the UI |
| `SS_DB_PATH` | `data/ss_schema.db` | SQLite location |
| `SS_ARTIFACT_DIR` | `data/artifacts` | artifact output root |
| `SS_HTTP_TIMEOUT` | `120` | per-request timeout, seconds |
| `SS_MAX_RETRIES` | `4` | retry attempts |
| `SS_RETRY_BACKOFF` | `2.0` | exponential backoff base |
| `SS_VERIFY_TLS` | `true` | set `false` to skip verification |
| `SS_UI_HOST` | `127.0.0.1` | UI bind address |
| `SS_UI_PORT` | `8770` | UI port |

---

## 12. Still to confirm with you

1. `force_depth` - do you want three-segment names like
   `jobs_effectiveDatedJobInfo_hrStatus` as the standard, or the shorter
   automatic form?
2. Are all 13 responses shaped the same way, with `updateSequence` and
   `nextCursor`? If some differ, each one is just a different registry row.
3. Do the APIs support an incremental filter, so a daily run does not need a
   full crawl?
4. Should prod be read-only in practice, or is a prod scan acceptable given
   every request is a `GET`?

---

See **PRODUCTION.md** for the hardening summary, the go-live checklist and the
remaining limitations before this is pointed at production.
