"""
AuthAgent - OAuth2 client_credentials token acquisition through the Ford proxy.
urllib only. Caches the token until shortly before expiry.
"""
import base64, json, ssl, threading, time, urllib.error, urllib.parse, urllib.request


class AuthError(Exception):
    pass


class AuthAgent:
    NAME = "auth"

    def __init__(self, cfg, logger=None):
        self.cfg = cfg
        self.log = logger or (lambda lvl, msg: None)
        self._token = None
        self._expires_at = 0.0
        self._lock = threading.Lock()
        self._opener = self._build_opener()

    # ------------------------------------------------------------------ proxy
    def _build_opener(self):
        handlers = []
        proxies = {}
        if self.cfg.HTTP_PROXY:
            proxies["http"] = self.cfg.HTTP_PROXY
        if self.cfg.HTTPS_PROXY:
            proxies["https"] = self.cfg.HTTPS_PROXY
        handlers.append(urllib.request.ProxyHandler(proxies if proxies else {}))
        ctx = ssl.create_default_context()
        if not self.cfg.VERIFY_TLS and getattr(self.cfg, "is_prod", lambda: False)():
            raise AuthError("refusing to disable TLS verification while SS_ENV=prod")
        if not self.cfg.VERIFY_TLS:
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
        handlers.append(urllib.request.HTTPSHandler(context=ctx))
        return urllib.request.build_opener(*handlers)

    @property
    def opener(self):
        return self._opener

    # ------------------------------------------------------------------ token
    def token(self, force=False):
        with self._lock:
            if not force and self._token and time.time() < self._expires_at - 60:
                return self._token
            return self._fetch()

    def _fetch(self):
        cfg = self.cfg
        if not cfg.TOKEN_URL or cfg.TOKEN_URL == "REPLACE_ME":
            raise AuthError("SS_TOKEN_URL is not configured")
        form = {"grant_type": "client_credentials"}
        if cfg.TOKEN_SCOPE:
            form["scope"] = cfg.TOKEN_SCOPE
        headers = {"Content-Type": "application/x-www-form-urlencoded", "Accept": "application/json"}
        if cfg.TOKEN_AUTH_STYLE == "basic":
            raw = (cfg.CLIENT_ID + ":" + cfg.CLIENT_SECRET).encode("utf-8")
            headers["Authorization"] = "Basic " + base64.b64encode(raw).decode("ascii")
        else:
            form["client_id"] = cfg.CLIENT_ID
            form["client_secret"] = cfg.CLIENT_SECRET

        req = urllib.request.Request(cfg.TOKEN_URL,
                                    data=urllib.parse.urlencode(form).encode("utf-8"),
                                    headers=headers, method="POST")
        try:
            with self._opener.open(req, timeout=cfg.HTTP_TIMEOUT) as resp:
                payload = json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            detail = e.read().decode("utf-8", "replace")[:400]
            raise AuthError("token endpoint returned HTTP %s: %s" % (e.code, detail))
        except urllib.error.URLError as e:
            raise AuthError("cannot reach token endpoint (check proxy): %s" % e.reason)

        tok = payload.get("access_token")
        if not tok:
            raise AuthError("no access_token in response, keys=%s" % list(payload.keys()))
        ttl = int(payload.get("expires_in", 3300))
        self._token = tok
        self._expires_at = time.time() + ttl
        self.log("INFO", "obtained access token, ttl=%ss" % ttl)
        return tok

    def auth_header(self, force=False):
        return {"Authorization": "Bearer " + self.token(force=force)}

    def probe(self):
        """Connectivity self-test used by the UI."""
        t0 = time.time()
        try:
            self.token(force=True)
            return {"ok": True, "ms": int((time.time() - t0) * 1000), "detail": "token acquired"}
        except Exception as e:
            return {"ok": False, "ms": int((time.time() - t0) * 1000), "detail": str(e)}
