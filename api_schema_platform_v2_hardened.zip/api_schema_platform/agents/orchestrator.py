"""
Orchestrator - drives one scan of one API end to end and persists everything.

    auth -> crawl -> profile -> name -> diff -> generate -> store
"""
import datetime, json, os, threading, traceback

import config
from core import db
from agents.auth_agent import AuthAgent
from agents.crawler_agent import CrawlerAgent
from agents.diff_agent import DiffAgent
from agents.generator_agent import GeneratorAgent
from agents.naming_agent import NamingAgent
from agents.profiler_agent import ProfilerAgent
from core import maintenance
from core.checkpoint import Checkpoint
from core.security import Audit

_ACTIVE = {}
_ACTIVE_LOCK = threading.Lock()
_API_LOCKS = {}


def _api_lock(api_id):
    """One concurrent scan per API - parallel crawls would corrupt the
    checkpoint and double the load on the source system."""
    with _ACTIVE_LOCK:
        return _API_LOCKS.setdefault(int(api_id), threading.Lock())


def active_snapshot():
    with _ACTIVE_LOCK:
        return {k: dict(v["progress"]) for k, v in _ACTIVE.items()}


def cancel(scan_id):
    with _ACTIVE_LOCK:
        if scan_id in _ACTIVE:
            _ACTIVE[scan_id]["cancel"] = True
            return True
    return False


class Orchestrator:
    def __init__(self, db_path=None, mock=False):
        self.db_path = db_path or config.DB_PATH
        self.mock = mock
        self.audit = Audit(getattr(config, "AUDIT_LOG", "audit.jsonl"))
        db.init(self.db_path)

    # ------------------------------------------------------------------
    def run_scan(self, api_id, trigger="manual", max_pages=None, max_records=None, actor="system"):
        lock = _api_lock(api_id)
        if not lock.acquire(blocking=False):
            return {"status": "skipped", "error": "a scan is already running for this API"}
        try:
            return self._run_scan(api_id, trigger, max_pages, max_records, actor)
        finally:
            lock.release()

    def _run_scan(self, api_id, trigger="manual", max_pages=None, max_records=None, actor="system"):
        c = db.connect(self.db_path)
        api = db.q1(c, "SELECT * FROM apis WHERE id=?", (api_id,))
        if not api:
            raise ValueError("no api with id %s" % api_id)
        settings = db.get_settings(c)
        started = datetime.datetime.now()
        scan_id = db.ex(c, "INSERT INTO scans(api_id,environment,status,trigger,started_at) "
                           "VALUES(?,?,?,?,?)",
                        (api_id, api["environment"], "running", trigger,
                         started.isoformat(timespec="seconds")))
        progress = {"scan_id": scan_id, "api_id": api_id, "api": api["name"], "phase": "starting",
                    "pages": 0, "records": 0, "columns": 0,
                    "started_at": started.isoformat(timespec="seconds")}
        with _ACTIVE_LOCK:
            _ACTIVE[scan_id] = {"cancel": False, "progress": progress}

        def L(level, msg):
            db.log(c, scan_id, api_id, level, msg)

        def stop_flag():
            with _ACTIVE_LOCK:
                return _ACTIVE.get(scan_id, {}).get("cancel", False)

        try:
            L("INFO", "scan %s started (trigger=%s, env=%s, mock=%s)"
              % (scan_id, trigger, api["environment"], self.mock))
            progress["phase"] = "authenticating"
            auth = AuthAgent(config, logger=L)
            if self.mock:
                from agents.mock_agent import MockCrawlerAgent
                crawler = MockCrawlerAgent(config, auth, logger=L,
                                           total=int(settings.get("mock_records", "15000")),
                                           page_size=api["page_size"] or 1000)
            else:
                auth.token()
                crawler = CrawlerAgent(config, auth, logger=L)

            arr = [a.strip() for a in (api["array_nodes"] or "").split(",") if a.strip()]
            profiler = ProfilerAgent(array_nodes=arr, auto_detect_arrays=True, logger=L,
                                     max_dynamic_keys=getattr(config, "MAX_DYNAMIC_KEYS", 300),
                                     max_columns=getattr(config, "MAX_COLUMNS", 2000))

            ckpt = Checkpoint(getattr(config, "CHECKPOINT_DIR", "data/checkpoints"),
                              "%s_%s" % (api["name"], api["environment"]))
            start_cursor, start_page, start_total = None, 0, 0
            if getattr(config, "RESUME_ENABLED", True) and ckpt.exists() and not self.mock:
                st = ckpt.load() or {}
                if st.get("cursor") and profiler.import_state(st.get("profile")):
                    start_cursor = st["cursor"]
                    start_page = int(st.get("page") or 0)
                    start_total = int(st.get("total") or 0)
                    L("INFO", "checkpoint found - resuming at page %s" % start_page)
                else:
                    ckpt.clear()

            progress["phase"] = "crawling"
            store_pages = settings.get("store_page_metrics", "1") == "1"

            def on_record(rec, n):
                profiler.observe(rec, n)
                if n % 500 == 0:
                    progress["records"] = n
                    progress["columns"] = len(profiler.profile)

            def on_page(page, status, count, nxt, ms):
                progress["pages"] = page
                progress["records"] = profiler.records
                progress["columns"] = len(profiler.profile)
                if store_pages:
                    db.ex(c, "INSERT INTO raw_pages(scan_id,page_no,http_status,record_count,"
                             "next_cursor,elapsed_ms,ts) VALUES(?,?,?,?,?,?,?)",
                          (scan_id, page, status, count, (nxt or "")[:200], ms,
                           datetime.datetime.now().isoformat(timespec="seconds")))

            cap = int(settings.get("sample_limit", "0")) or None
            crawl_kw = {}
            if not self.mock:
                crawl_kw = {"checkpoint": ckpt, "start_cursor": start_cursor,
                            "start_page": start_page, "start_total": start_total,
                            "profile_state": profiler.export_state}
            crawl = crawler.crawl(api, on_record, on_page, max_pages=max_pages,
                                  max_records=max_records or cap, stop_flag=stop_flag, **crawl_kw)
            if not (max_pages or max_records or cap):
                ckpt.clear()   # a complete sweep invalidates any resume point

            progress["phase"] = "profiling"
            raw = profiler.result()
            try:
                fd = json.loads(api["force_depth"] or "{}")
            except Exception:
                fd = {}
                L("WARN", "force_depth is not valid JSON - ignoring")
            names = NamingAgent(force_depth=fd, logger=L).assign([r["json_path"] for r in raw])
            columns = []
            for r in raw:
                p = r["json_path"]
                columns.append(dict(r, column_name=names[p], leaf=p.split("/")[-1],
                                    parent_path="/".join(p.split("/")[:-1]), xpath=p))
            columns.sort(key=lambda x: x["column_name"])
            progress["columns"] = len(columns)

            for col in columns:
                db.ex(c, "INSERT INTO scan_columns(scan_id,column_name,json_path,xpath,leaf,"
                         "parent_path,types,non_null_count,seen_count,max_len,first_seen_record,"
                         "is_dynamic) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                      (scan_id, col["column_name"], col["json_path"], col["xpath"], col["leaf"],
                       col["parent_path"], col["types"], col["non_null_count"], col["seen_count"],
                       col["max_len"], col["first_seen_record"], col["is_dynamic"]))

            progress["phase"] = "diffing"
            summary = DiffAgent(c, logger=L).compare(api_id, api["environment"], scan_id, columns)

            finished = datetime.datetime.now()
            duration = (finished - started).total_seconds()
            db.ex(c, "UPDATE scans SET status=?,finished_at=?,duration_sec=?,pages=?,records=?,"
                     "columns_total=?,added_count=?,removed_count=?,changed_count=?,message=? WHERE id=?",
                  ("success", finished.isoformat(timespec="seconds"), duration, crawl["pages"],
                   crawl["records"], len(columns), len(summary["added"]), len(summary["removed"]),
                   len(summary["changed"]), "baseline" if summary["baseline"] else "ok", scan_id))
            scan = db.q1(c, "SELECT * FROM scans WHERE id=?", (scan_id,))

            progress["phase"] = "generating"
            gen = GeneratorAgent(settings, logger=L)
            arrays = profiler.detected_arrays()
            artifacts = {
                "xquery": ("transform.xquery", gen.xquery(api, columns)),
                "create_table": ("create_table.sql", gen.create_table(api, columns)),
                "alter_table": ("alter_table.sql", gen.alter_table(api, summary)),
                "columns_csv": ("columns.csv", gen.columns_csv(columns)),
                "report": ("drift_report.txt", gen.drift_report(api, scan, columns, summary, arrays)),
            }
            safe = "".join(ch if ch.isalnum() or ch in "-_" else "_" for ch in api["name"])
            outdir = os.path.join(config.ARTIFACT_DIR, "%s_%s" % (safe, api["environment"]),
                                  "scan_%s" % scan_id)
            os.makedirs(outdir, exist_ok=True)
            for kind, (fn, content) in artifacts.items():
                db.ex(c, "INSERT INTO artifacts(scan_id,api_id,kind,filename,content,bytes,created_at) "
                         "VALUES(?,?,?,?,?,?,?)",
                      (scan_id, api_id, kind, fn, content, len(content.encode("utf-8")),
                       datetime.datetime.now().isoformat(timespec="seconds")))
                with open(os.path.join(outdir, fn), "w", encoding="utf-8") as f:
                    f.write(content)
            if arrays and not api["array_nodes"]:
                db.ex(c, "UPDATE apis SET array_nodes=? WHERE id=?", (",".join(arrays), api_id))
                L("INFO", "auto-detected repeating groups saved: %s" % ",".join(arrays))

            L("INFO", "scan %s finished: %s columns, +%s -%s ~%s in %.1fs"
              % (scan_id, len(columns), len(summary["added"]), len(summary["removed"]),
                 len(summary["changed"]), duration))
            try:
                maintenance.prune(c, getattr(config, "RETENTION_LOG_DAYS", 30),
                                  getattr(config, "RETENTION_PAGE_DAYS", 14),
                                  getattr(config, "RETENTION_SCAN_KEEP", 60))
            except Exception as pe:
                L("WARN", "retention pass failed: %s" % pe)
            self.audit.write(actor, "scan.success", "%s/%s" % (api["name"], api["environment"]),
                             detail="cols=%s +%s -%s" % (len(columns), len(summary["added"]),
                                                         len(summary["removed"])))
            progress["phase"] = "done"
            return {"scan_id": scan_id, "status": "success", "columns": len(columns),
                    "added": len(summary["added"]), "removed": len(summary["removed"]),
                    "changed": len(summary["changed"]), "pages": crawl["pages"],
                    "records": crawl["records"], "artifact_dir": outdir}

        except Exception as e:
            db.log(c, scan_id, api_id, "ERROR", str(e) + "\n" + traceback.format_exc(limit=6))
            db.ex(c, "UPDATE scans SET status=?,finished_at=?,duration_sec=?,message=? WHERE id=?",
                  ("failed", datetime.datetime.now().isoformat(timespec="seconds"),
                   (datetime.datetime.now() - started).total_seconds(), str(e)[:900], scan_id))
            self.audit.write(actor, "scan.failed", "%s/%s" % (api["name"], api["environment"]),
                             outcome="error", detail=str(e))
            return {"scan_id": scan_id, "status": "failed", "error": str(e)}
        finally:
            with _ACTIVE_LOCK:
                _ACTIVE.pop(scan_id, None)

    # ------------------------------------------------------------------
    def run_all(self, environment=None, trigger="scheduled", max_pages=None, actor="system"):
        c = db.connect(self.db_path)
        sql = "SELECT id,name FROM apis WHERE enabled=1"
        args = ()
        if environment:
            sql += " AND environment=?"
            args = (environment,)
        results = []
        for a in db.q(c, sql + " ORDER BY name", args):
            results.append(dict(self.run_scan(a["id"], trigger=trigger, max_pages=max_pages,
                                              actor=actor), api=a["name"]))
        return results
