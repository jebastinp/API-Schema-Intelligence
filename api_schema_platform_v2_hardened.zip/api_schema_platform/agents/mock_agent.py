"""
MockCrawlerAgent - offline stand-in for CrawlerAgent so the whole pipeline and
the UI can be demonstrated without network, proxy or credentials.

It deliberately introduces late-appearing fields after record 12,000 and
sparse dynamic customFields keys, to exercise the drift detector.
"""
import copy, random

BASE = {
    "recordId": "dWtmb3JkX3RyYWluLTM5MmRkYTA1", "sequence": 6990, "dataChange": "MERGE",
    "employeeId": "392dda05-cfeb-42bf-b53e-da765ca668f1",
    "externalMatchId": "100000110884761", "displayId": "123755-ME17JV25",
    "emailAddress": "uktktest@ford.com",
    "name": {"displayName": "Martin Coker", "firstName": "Martin", "lastName": "Coker",
             "legalName": None, "middleNames": None, "prefix": None, "suffix": None},
    "effectiveDatedInfo": [{
        "accrualDate": None, "creditedServiceDate": None,
        "customFields": {"C_GPID": "ME17JV25", "C_FIN": "123755", "C_CDSID": "MCOKER1"},
        "effectiveDate": "1900-01-01", "endEffectiveDate": "1989-09-10",
        "expectedTerminationDate": None, "gender": None, "governmentId": None,
        "homeAddress": {"city": None, "lineOne": None, "lineThree": None, "lineTwo": None,
                        "postalCode": None},
        "hrStatus": None, "importedBadgeId": None, "latestHireDate": "1989-09-11",
        "leaveCode": None, "leaveOfAbsenceReturnDate": None, "leaveStartDate": None,
        "leaveType": None, "managedJobsMatchValue": None, "managerIndicator": False,
        "seniorityDate": None, "shiftCode": None, "splitBillingCode": None, "terminationDate": None,
        "wtaTemplateEmployeeFields": {
            "accrualBand": None, "actCaseApproverMatchId": None, "actCompany": "UKFORD_ACT_FMC",
            "actEmployeeGroup": None, "actHireDate": None, "actLocationCode": "GBR",
            "aggregateFtePct": "0", "aggregatePeriodHours": None, "aggregateStdDailyHours": "0",
            "aggregateStdWeeklyHours": None, "assignmentType": None,
            "columbiaVacationAccrualDate": None, "contractType": None, "geoFenceLocation": None,
            "homeCountry": None, "hostCountry": None, "isBreak1Waived": False,
            "isBreak2Waived": False, "isCoveredAmericanPetroleum": False,
            "isEmployeeDisabled": False, "isHolidayExempt": False, "isNightShiftWorker": False,
            "isStudent": False, "isUnder18": False, "jobFamily": None, "jobProfile": None,
            "longServiceLeaveReferenceDate": None, "programOfSocialIntegrationId": None,
            "sickLeaveCode": None, "supervisoryOrganization": None, "workerSubtype": None,
            "workerType": None},
        "country": "null", "stateOrProvince": "null"}],
    "jobs": [{
        "description": "ESAP / Engineer",
        "effectiveDatedJobInfo": [{
            "accrualStartDate": None, "actionReasonCode": None, "bargainingUnitCode": None,
            "businessAddress": {"city": "Dunton", "lineOne": "Arterial Road", "lineTwo": None,
                                "lineThree": None, "postalCode": "SS15 6EE"},
            "businessUnit": None, "company": None, "competencies": None, "contractEndDate": None,
            "costCenter": None, "costNumberCode": None,
            "customFields": {"C_EMPLOYER_CODE": "PV", "C_GRADE_CODE": "SG8"},
            "department": "1000005283", "district": None, "division": None,
            "effectiveDate": "2025-08-01", "employmentType": None, "endDate": None,
            "endEffectiveDate": "3000-12-31", "flsaStatus": None, "ftePercent": None,
            "gradeLadder": None, "hrStatus": None, "importedBadgeId": None,
            "industryClassificationCode": None, "isActive": True, "isFullTime": False,
            "jobClassCode": None, "jobCode": None, "jobFamilyCode": None, "jobFunctionCode": None,
            "jobLevel": None, "jobTitle": None, "latestStartDate": "1989-09-11",
            "locationId": None, "managersMatchValue": "300000273793219", "payCurrency": None,
            "payFrequencyCode": None, "payFrequencyName": None, "payGrade": None, "payRates": None,
            "payType": "S", "payrollId": None, "payrollSystemId": None,
            "policyProfile": "USERONLY_PPM", "positionId": None, "primary": True, "rateType": None,
            "region": None, "scheduleTemplateId": None, "schedulingUnits": None, "shiftCode": None,
            "shiftIndicator": None, "staffingType": None, "standardDailyHours": None,
            "standardPeriodHours": None, "standardWeeklyHours": None,
            "timeOffApproverMatchId": None, "timeSheetApproverMatchId": None,
            "timezone": "Europe/London", "unionCode": None, "wfandsJobFields": None,
            "workShiftCode": None, "wtaTemplateJobFields": None}],
        "externalJobId": "300000281510290", "id": "a57a9b73-395e-43fa-858a-d555d7fb83cc",
        "jobCode": None, "originalStartDate": None,
        "employeeJob": "100000110884761|300000281510290"}],
}

LATE_WTA_JOB = {
    "applicableMinimumWage": "11.44", "assignmentMonthlyContractHours": "151.67",
    "branch": "DUN", "brazilEmployerId": None, "daysPerMonth": "21", "daysPerWeek": "5",
    "daysPerWeekFuture": None, "daysPerWeekFutureEffDt": None, "employerName": "FMC",
    "facilityIdentifier": "GBR-DUN", "holidayCalendarMappingKey": "UK_STD",
    "hourlyBaseRate": "0", "isAlternativeSchedule": False, "isCasual": False,
    "isExcludedFromOtc": False, "isExemptFromOTCap": False, "isPunchingForBreaks": False,
    "isQualifiedForSickLeaveAccrual": True, "isQualifiedForVacationAccrual": True,
    "isRehire": False, "isShiftWorker": False, "isTaking30MinuteBreaks": True,
    "isUsingFlexiTime": True, "isWeekendsOnly": False, "isWorkingIrregularSchedule": False,
    "miniJobberMidiJobber": None, "nationalRegistryOfLegalEntitiesId": None,
    "policyProfileMappingKey": "UK_PPM", "programOfSocialIntegrationId": None,
    "salariedBaseRate": "4200", "skillCode": "ENG",
}


class MockCrawlerAgent:
    NAME = "crawler(mock)"

    def __init__(self, cfg, auth=None, logger=None, total=15000, page_size=1000, drift=True):
        self.log = logger or (lambda lvl, msg: None)
        self.total = total
        self.page_size = page_size or 1000
        self.drift = drift

    def crawl(self, api, on_record, on_page=None, max_pages=None, max_records=None, stop_flag=None):
        rnd = random.Random(42)
        total = min(self.total, max_records or self.total)
        n, page = 0, 0
        while n < total:
            if stop_flag is not None and stop_flag():
                break
            page += 1
            batch = min(self.page_size, total - n)
            for _ in range(batch):
                n += 1
                r = copy.deepcopy(BASE)
                r["sequence"] = 6990 + n
                r["name"]["displayName"] = "Employee %05d" % n
                if self.drift and n > 12000:
                    r["jobs"][0]["effectiveDatedJobInfo"][0]["wtaTemplateJobFields"] = \
                        copy.deepcopy(LATE_WTA_JOB)
                if n % 997 == 0:
                    r["effectiveDatedInfo"][0]["customFields"]["C_GID"] = "G%07d" % n
                if n % 1499 == 0:
                    r["jobs"][0]["effectiveDatedJobInfo"][0]["customFields"]["C_SALARY_BASIS"] = "MONTHLY"
                if n % 1801 == 0:
                    r["jobs"][0]["effectiveDatedJobInfo"][0]["customFields"]["C_BUSINESS_UNIT"] = "PD"
                if n % 5 == 0:
                    r["originalHireDate"] = "1989-09-11"
                on_record(r, n)
            nxt = None if n >= total else "cursor-%s" % page
            if on_page:
                on_page(page, 200, batch, nxt, rnd.randint(120, 900))
            self.log("INFO", "[mock] page %s -> %s records, cumulative %s" % (page, batch, n))
            if max_pages and page >= max_pages:
                break
        return {"pages": page, "records": n}
