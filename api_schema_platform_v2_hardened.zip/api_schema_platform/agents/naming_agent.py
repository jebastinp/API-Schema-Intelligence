"""
NamingAgent - turns JSON leaf paths into SQL / XML column names.

Rule (matches the hand-written IICS mapping already in production):
  1. start with the bare leaf name
  2. on collision, prefix the IMMEDIATE parent only
       homeAddress_lineOne  /  businessAddress_lineOne
  3. if still colliding, keep prepending ancestors until unique
  4. force_depth pins a leaf to a fixed number of segments, e.g.
       {"hrStatus": 2} -> effectiveDatedInfo_hrStatus
       {"hrStatus": 3} -> jobs_effectiveDatedJobInfo_hrStatus
"""
import re

RESERVED = {"primary", "user", "order", "group", "table", "select", "from", "where",
            "default", "check", "column", "constraint", "references", "all", "end",
            "limit", "offset", "using", "natural", "unique", "authorization"}


def strip_index(seg):
    return re.sub(r"\[\d+\]$", "", seg)


class NamingAgent:
    NAME = "naming"

    def __init__(self, force_depth=None, logger=None):
        self.force_depth = force_depth or {}
        self.log = logger or (lambda lvl, msg: None)

    def assign(self, paths):
        segs = {p: [strip_index(s) for s in p.split("/")] for p in paths}
        depth = {p: int(self.force_depth.get(segs[p][-1], 1)) for p in paths}

        for _ in range(12):
            buckets = {}
            for p in paths:
                buckets.setdefault(self._name(segs[p], depth[p]), []).append(p)
            clashes = [ps for ps in buckets.values() if len(ps) > 1]
            if not clashes:
                break
            for ps in clashes:
                for p in ps:
                    if depth[p] < len(segs[p]):
                        depth[p] += 1

        result, used = {}, {}
        for p in sorted(paths):
            nm = self._name(segs[p], depth[p])
            if nm in used:
                n = 2
                while nm + "_" + str(n) in used:
                    n += 1
                self.log("WARN", "unresolvable collision, suffixing: %s -> %s_%s" % (p, nm, n))
                nm = nm + "_" + str(n)
            used[nm] = p
            result[p] = nm
        return result

    def _name(self, seglist, d):
        d = max(1, min(d, len(seglist)))
        return "_".join(seglist[len(seglist) - d:])

    @staticmethod
    def sql_name(name):
        s = re.sub(r"[^0-9a-zA-Z_]", "_", name).lower()
        if s and s[0].isdigit():
            s = "c_" + s
        return s

    @staticmethod
    def quote_if_reserved(sqlname):
        return '"' + sqlname + '"' if sqlname in RESERVED else sqlname
