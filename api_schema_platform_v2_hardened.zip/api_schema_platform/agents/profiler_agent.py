"""
ProfilerAgent - flattens JSON records into leaf paths and accumulates a union
profile across every record in the crawl.

Array handling follows the IICS XQuery convention already in production: only
index [1] of a repeating group is projected into the flat row, so the recorded
path looks like  jobs[1]/effectiveDatedJobInfo[1]/timezone .

Dynamic maps (customFields) are detected and their keys promoted to columns,
while the container itself is also kept - mirroring the existing
effectiveDatedInfo_customFields behaviour.
"""


class ProfilerAgent:
    NAME = "profiler"

    def __init__(self, array_nodes=None, dynamic_nodes=None, auto_detect_arrays=True, logger=None,
                 max_dynamic_keys=300, max_columns=2000):
        self.array_nodes = set(array_nodes or [])
        self.dynamic_nodes = set(dynamic_nodes or ["customFields"])
        self.auto_detect_arrays = auto_detect_arrays
        self.log = logger or (lambda lvl, msg: None)
        self.profile = {}
        self.records = 0
        self.max_dynamic_keys = int(max_dynamic_keys or 0)
        self.max_columns = int(max_columns or 0)
        self.dynamic_keys = {}
        self.suppressed = {"dynamic": 0, "columns": 0}
        self._warned = set()

    # ------------------------------------------------------------------
    def observe(self, record, record_no):
        self.records = record_no
        self._walk(record, [], record_no)

    def _warn_once(self, key, msg):
        if key not in self._warned:
            self._warned.add(key)
            self.log("WARN", msg)

    def _touch(self, path, value, record_no, is_dynamic=False):
        st = self.profile.get(path)
        if st is None:
            if self.max_columns and len(self.profile) >= self.max_columns:
                self.suppressed["columns"] += 1
                self._warn_once("cols", "column cap %s reached at record %s - new paths are "
                                        "counted but not profiled (raise SS_MAX_COLUMNS)"
                                % (self.max_columns, record_no))
                return
            st = {"json_path": path, "seen_count": 0, "non_null_count": 0, "types": set(),
                  "max_len": 0, "first_seen_record": record_no, "is_dynamic": 1 if is_dynamic else 0}
            self.profile[path] = st
        st["seen_count"] += 1
        if value is None:
            st["types"].add("null")
            return
        if isinstance(value, str) and value == "null":
            # the source sends a literal "null" string in places
            st["types"].add("null")
            st["non_null_count"] += 1
            return
        st["non_null_count"] += 1
        if isinstance(value, bool):
            st["types"].add("boolean")
        elif isinstance(value, int):
            st["types"].add("integer")
        elif isinstance(value, float):
            st["types"].add("number")
        else:
            s = str(value)
            st["types"].add("string")
            if len(s) > st["max_len"]:
                st["max_len"] = len(s)

    def _walk(self, node, trail, record_no):
        if isinstance(node, dict):
            for k, v in node.items():
                self._walk_key(k, v, trail, record_no)
        elif isinstance(node, list) and node:
            self._walk(node[0], trail, record_no)

    def _walk_key(self, key, value, trail, record_no):
        path_parts = trail + [key]
        if isinstance(value, dict):
            if key in self.dynamic_nodes:
                container = "/".join(path_parts)
                self._touch(container, None, record_no)
                seen = self.dynamic_keys.setdefault(container, set())
                for dk, dv in value.items():
                    if dk not in seen and self.max_dynamic_keys and len(seen) >= self.max_dynamic_keys:
                        self.suppressed["dynamic"] += 1
                        self._warn_once("dyn:" + container,
                                        "dynamic-key cap %s hit on %s at record %s - extra keys "
                                        "ignored (raise SS_MAX_DYNAMIC_KEYS if legitimate)"
                                        % (self.max_dynamic_keys, container, record_no))
                        continue
                    seen.add(dk)
                    self._touch("/".join(path_parts + [dk]), dv, record_no, is_dynamic=True)
                return
            if not value:
                self._touch("/".join(path_parts), None, record_no)
                return
            for k2, v2 in value.items():
                self._walk_key(k2, v2, path_parts, record_no)
            return
        if isinstance(value, list):
            if self.auto_detect_arrays:
                self.array_nodes.add(key)
            marked = trail + [key + "[1]"]
            if not value:
                self._touch("/".join(path_parts), None, record_no)
                return
            first = value[0]
            if isinstance(first, dict):
                for k2, v2 in first.items():
                    self._walk_key(k2, v2, marked, record_no)
            else:
                self._touch("/".join(marked), first, record_no)
            return
        self._touch("/".join(path_parts), value, record_no)

    # ------------------------------------------------------------------
    def result(self):
        out = []
        for path, st in self.profile.items():
            types = sorted(t for t in st["types"] if t != "null") or ["null"]
            out.append({"json_path": path, "seen_count": st["seen_count"],
                        "non_null_count": st["non_null_count"], "types": ",".join(types),
                        "max_len": st["max_len"], "first_seen_record": st["first_seen_record"],
                        "is_dynamic": st["is_dynamic"]})
        out.sort(key=lambda r: r["json_path"])
        return out

    def export_state(self):
        """Serialisable snapshot used for crash-resume."""
        return {"records": self.records,
                "array_nodes": sorted(self.array_nodes),
                "dynamic_keys": {k: sorted(v) for k, v in self.dynamic_keys.items()},
                "suppressed": dict(self.suppressed),
                "profile": {p: dict(st, types=sorted(st["types"])) for p, st in self.profile.items()}}

    def import_state(self, state):
        if not state:
            return False
        self.records = int(state.get("records") or 0)
        self.array_nodes |= set(state.get("array_nodes") or [])
        self.dynamic_keys = {k: set(v) for k, v in (state.get("dynamic_keys") or {}).items()}
        self.suppressed.update(state.get("suppressed") or {})
        self.profile = {p: dict(st, types=set(st.get("types") or []))
                        for p, st in (state.get("profile") or {}).items()}
        return True

    def detected_arrays(self):
        return sorted(self.array_nodes)
