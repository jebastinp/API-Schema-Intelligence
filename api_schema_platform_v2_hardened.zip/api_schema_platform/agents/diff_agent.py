"""
DiffAgent - compares today's column set against the previous successful scan of
the same API + environment and records drift events.

Event types: NEW_COLUMN, REMOVED_COLUMN, TYPE_CHANGED, WIDENED,
             NOW_ALWAYS_NULL, NOW_POPULATED, BASELINE
"""
import datetime
from core import db


class DiffAgent:
    NAME = "diff"

    def __init__(self, conn, logger=None):
        self.c = conn
        self.log = logger or (lambda lvl, msg: None)

    def previous_scan(self, api_id, environment, before_scan_id):
        return db.q1(self.c, "SELECT * FROM scans WHERE api_id=? AND environment=? "
                             "AND status='success' AND id<>? ORDER BY id DESC LIMIT 1",
                     (api_id, environment, before_scan_id))

    def compare(self, api_id, environment, scan_id, columns):
        prev = self.previous_scan(api_id, environment, scan_id)
        events = []
        now = datetime.datetime.now().isoformat(timespec="seconds")
        cur = {r["column_name"]: r for r in columns}

        if not prev:
            for name, r in sorted(cur.items()):
                events.append(("BASELINE", name, r["json_path"], "first ever scan", r["first_seen_record"]))
        else:
            old = {r["column_name"]: r for r in
                   db.q(self.c, "SELECT * FROM scan_columns WHERE scan_id=?", (prev["id"],))}
            for name in sorted(set(cur) - set(old)):
                r = cur[name]
                events.append(("NEW_COLUMN", name, r["json_path"],
                               "appeared at record #%s; types=%s" % (r["first_seen_record"], r["types"]),
                               r["first_seen_record"]))
            for name in sorted(set(old) - set(cur)):
                r = old[name]
                events.append(("REMOVED_COLUMN", name, r["json_path"],
                               "present in scan #%s, absent today" % prev["id"], 0))
            for name in sorted(set(cur) & set(old)):
                a, b = old[name], cur[name]
                if (a["types"] or "") != (b["types"] or ""):
                    events.append(("TYPE_CHANGED", name, b["json_path"],
                                   "%s -> %s" % (a["types"] or "-", b["types"] or "-"), 0))
                if (b["max_len"] or 0) > (a["max_len"] or 0):
                    events.append(("WIDENED", name, b["json_path"],
                                   "max length %s -> %s" % (a["max_len"], b["max_len"]), 0))
                if (a["non_null_count"] or 0) > 0 and (b["non_null_count"] or 0) == 0:
                    events.append(("NOW_ALWAYS_NULL", name, b["json_path"],
                                   "was populated, now 100 percent null", 0))
                if (a["non_null_count"] or 0) == 0 and (b["non_null_count"] or 0) > 0:
                    events.append(("NOW_POPULATED", name, b["json_path"],
                                   "was always null, now %s non-null" % b["non_null_count"], 0))

        for et, name, path, detail, fsr in events:
            db.ex(self.c, "INSERT INTO schema_events(scan_id,api_id,event_type,column_name,"
                          "json_path,details,first_seen_record,detected_at) VALUES(?,?,?,?,?,?,?,?)",
                  (scan_id, api_id, et, name, path, detail, fsr, now))

        return {
            "previous_scan_id": prev["id"] if prev else None,
            "added": [e for e in events if e[0] == "NEW_COLUMN"],
            "removed": [e for e in events if e[0] == "REMOVED_COLUMN"],
            "changed": [e for e in events if e[0] in ("TYPE_CHANGED", "WIDENED",
                                                      "NOW_ALWAYS_NULL", "NOW_POPULATED")],
            "baseline": bool(not prev),
            "events": events,
        }
