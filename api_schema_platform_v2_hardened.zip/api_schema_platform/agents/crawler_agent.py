"""
CrawlerAgent - walks a cursor-paginated API to exhaustion.

Streams pages and hands each record to a callback, so a 600k-record API is
never held in memory.
"""
import json, threading, time, urllib.error, urllib.parse, urllib.request


class _RateLimiter:
    """Minimum-interval limiter; rps<=0 disables it."""

    def __init__(self, rps):
        self.min_interval = (1.0 / rps) if rps and rps > 0 else 0.0
        self._last = 0.0
        self._lock = threading.Lock()

    def wait(self):
        if not self.min_interval:
            return
        with self._lock:
            gap = time.time() - self._last
            if gap < self.min_interval:
                time.sleep(self.min_interval - gap)
            self._last = time.time()


class CrawlError(Exception):
    pass


class CrawlerAgent:
    NAME = "crawler"

    def __init__(self, cfg, auth, logger=None):
        self.cfg = cfg
        self.auth = auth
        self.log = logger or (lambda lvl, msg: None)
        self.limiter = _RateLimiter(getattr(cfg, "RATE_LIMIT_RPS", 0))

    def _url(self, api, cursor):
        base = (api.get("base_url") or self.cfg.API_BASE_URL).rstrip("/")
        ep = api.get("endpoint") or self.cfg.EMPLOYEE_ENDPOINT
        url = base + "/" + ep.lstrip("/")
        parts = []
        if api.get("page_size_param") and api.get("page_size"):
            parts.append("%s=%s" % (api["page_size_param"], api["page_size"]))
        if api.get("extra_query"):
            parts.append(api["extra_query"].lstrip("?&"))
        if cursor:
            if int(api.get("cursor_pre_encoded", 1)):
                # the server hands the cursor back already percent-encoded
                parts.append("%s=%s" % (api.get("cursor_query_param", "cursor"), cursor))
            else:
                parts.append(urllib.parse.urlencode({api.get("cursor_query_param", "cursor"): cursor}))
        return url + ("?" + "&".join(parts) if parts else "")

    def _get(self, url):
        last = None
        for attempt in range(1, self.cfg.MAX_RETRIES + 1):
            try:
                headers = {"Accept": "application/json", "User-Agent": "ford-schema-agent/1.0"}
                headers.update(self.auth.auth_header(force=(attempt > 1 and last in (401, 403))))
                req = urllib.request.Request(url, headers=headers, method="GET")
                self.limiter.wait()
                t0 = time.time()
                with self.auth.opener.open(req, timeout=self.cfg.HTTP_TIMEOUT) as resp:
                    raw = resp.read().decode("utf-8")
                    return json.loads(raw), resp.status, int((time.time() - t0) * 1000)
            except urllib.error.HTTPError as e:
                last = e.code
                body = e.read().decode("utf-8", "replace")[:300]
                if e.code in (401, 403):
                    self.log("WARN", "HTTP %s - refreshing token (attempt %s)" % (e.code, attempt))
                elif e.code in (408, 429, 500, 502, 503, 504):
                    ra = self._retry_after(e)
                    self.log("WARN", "HTTP %s - retrying (attempt %s, wait %s): %s"
                             % (e.code, attempt, ("%ss" % ra) if ra is not None else "backoff", body))
                    if ra is not None and attempt < self.cfg.MAX_RETRIES:
                        time.sleep(min(ra, 300))
                        continue
                else:
                    raise CrawlError("HTTP %s on %s :: %s" % (e.code, url, body))
            except urllib.error.URLError as e:
                last = "url"
                self.log("WARN", "network error attempt %s: %s" % (attempt, e.reason))
            except ValueError as e:
                raise CrawlError("response was not valid JSON: %s" % e)
            if attempt < self.cfg.MAX_RETRIES:
                time.sleep(self.cfg.RETRY_BACKOFF ** attempt)
        raise CrawlError("exhausted %s retries on %s (last=%s)" % (self.cfg.MAX_RETRIES, url, last))

    @staticmethod
    def _retry_after(err):
        """Honour Retry-After, given either as seconds or an HTTP date."""
        try:
            raw = err.headers.get("Retry-After")
        except Exception:
            return None
        if not raw:
            return None
        raw = raw.strip()
        if raw.isdigit():
            return max(0, int(raw))
        try:
            import email.utils
            when = email.utils.parsedate_to_datetime(raw)
            return max(0, int(when.timestamp() - time.time()))
        except Exception:
            return None

    def crawl(self, api, on_record, on_page=None, max_pages=None, max_records=None,
              stop_flag=None, checkpoint=None, start_cursor=None, start_page=0, start_total=0,
              profile_state=None, checkpoint_every=10):
        if (api.get("http_method") or "GET").upper() != "GET":
            raise CrawlError("this tool is read-only; http_method must be GET, got %s"
                             % api.get("http_method"))
        cursor, page, total = start_cursor, int(start_page or 0), int(start_total or 0)
        seen_cursors = set()
        if cursor:
            seen_cursors.add(cursor)
            self.log("INFO", "resuming from checkpoint at page %s (%s records already profiled)"
                     % (page, total))
        while True:
            if stop_flag is not None and stop_flag():
                self.log("WARN", "crawl cancelled by operator at page %s" % page)
                break
            url = self._url(api, cursor)
            payload, status, ms = self._get(url)
            page += 1
            recs = payload.get(api.get("records_key") or "updateSequence") or []
            if isinstance(recs, dict):
                recs = [recs]
            for r in recs:
                total += 1
                on_record(r, total)
                if max_records and total >= max_records:
                    break
            nxt = payload.get(api.get("cursor_response_key") or "nextCursor")
            if on_page:
                on_page(page, status, len(recs), nxt, ms)
            for w in (payload.get("errors") or []):
                self.log("ERROR", "api errors[]: %s" % json.dumps(w)[:500])
            for w in (payload.get("warnings") or []):
                self.log("WARN", "api warnings[]: %s" % json.dumps(w)[:500])
            self.log("INFO", "page %s -> %s records (%sms), cumulative %s" % (page, len(recs), ms, total))
            if max_records and total >= max_records:
                break
            if max_pages and page >= max_pages:
                self.log("INFO", "stopping: max_pages=%s reached" % max_pages)
                break
            if not nxt or not recs:
                break
            if checkpoint is not None and nxt and page % max(1, checkpoint_every) == 0:
                try:
                    checkpoint.save(nxt, page, total,
                                    profile_state() if callable(profile_state) else None)
                except Exception as ce:
                    self.log("WARN", "could not write checkpoint: %s" % ce)
            if nxt in seen_cursors:
                self.log("WARN", "cursor repeated - breaking to avoid an infinite loop")
                break
            seen_cursors.add(nxt)
            cursor = nxt
        return {"pages": page, "records": total}
