"""
SchedulerAgent - stdlib-only daily trigger. A background thread wakes every 30
seconds and fires run_all() once per day at the configured HH:MM.
"""
import datetime, threading
from core import db


class SchedulerAgent:
    NAME = "scheduler"

    def __init__(self, orchestrator, db_path, logger=None):
        self.orc = orchestrator
        self.db_path = db_path
        self.log = logger or (lambda lvl, msg: print("[scheduler]", lvl, msg))
        self._stop = threading.Event()
        self._thread = None
        self._last_fired_date = None
        self.next_run = None

    def start(self):
        if self._thread and self._thread.is_alive():
            return
        self._thread = threading.Thread(target=self._loop, name="scheduler", daemon=True)
        self._thread.start()
        self.log("INFO", "scheduler thread started")

    def stop(self):
        self._stop.set()

    def _target_time(self):
        hhmm = db.get_settings(db.connect(self.db_path)).get("daily_schedule_time", "02:00")
        try:
            h, m = [int(x) for x in hhmm.split(":")]
        except Exception:
            h, m = 2, 0
        return h, m

    def _loop(self):
        while not self._stop.is_set():
            try:
                h, m = self._target_time()
                now = datetime.datetime.now()
                target = now.replace(hour=h, minute=m, second=0, microsecond=0)
                if target <= now:
                    target += datetime.timedelta(days=1)
                self.next_run = target.isoformat(timespec="seconds")
                if now.hour == h and now.minute == m and self._last_fired_date != now.date():
                    self._last_fired_date = now.date()
                    self.log("INFO", "daily window reached - scanning all enabled APIs")
                    try:
                        self.orc.run_all(trigger="scheduled")
                    except Exception as e:
                        self.log("ERROR", "scheduled run failed: %s" % e)
            except Exception as e:
                self.log("ERROR", "scheduler loop error: %s" % e)
            self._stop.wait(30)
