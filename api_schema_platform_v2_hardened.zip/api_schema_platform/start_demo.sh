#!/usr/bin/env bash
cd "$(dirname "$0")"
exec python3 run.py ui --demo --open
