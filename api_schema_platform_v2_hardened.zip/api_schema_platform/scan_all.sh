#!/usr/bin/env bash
# cron entry point for the daily sweep. Exit code 3 means drift was detected.
cd "$(dirname "$0")"
if [ -f env.sh ]; then . ./env.sh; fi
mkdir -p logs
python3 run.py scan-all >> logs/daily.log 2>&1
exit $?
