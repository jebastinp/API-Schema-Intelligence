#!/usr/bin/env python3
"""Generate a PBKDF2 hash for SS_ADMIN_PASSWORD_HASH / SS_VIEWER_PASSWORD_HASH.

    python tools/hash_password.py

The password is read from the terminal, never from argv, so it never lands in
your shell history or in the process list.
"""
import getpass, os, sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from core.security import hash_password  # noqa: E402

if __name__ == "__main__":
    p1 = getpass.getpass("Password: ")
    p2 = getpass.getpass("Confirm : ")
    if p1 != p2:
        sys.exit("passwords do not match")
    if len(p1) < 12:
        sys.exit("use at least 12 characters")
    print()
    print("export SS_ADMIN_PASSWORD_HASH='%s'" % hash_password(p1))
