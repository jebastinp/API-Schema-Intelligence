"""
Schema Studio - main CLI entry point.

Usage examples:
    python main.py scan --demo                 # demo data, no network
    python main.py scan                        # legacy single-API env-based scan
    python main.py scan --api MyAPI            # scan one registered API
    python main.py scan --all                  # scan every registered API
    python main.py gui                          # launch the Tkinter UI
"""
import sys
import time
import argparse

from agents.auth_agent import AuthAgent
from agents.live_scanner_agent import LiveScannerAgent
from agents.sql_generator_agent import SQLGeneratorAgent
from agents.xquery_generator_agent import XQueryGeneratorAgent
from agents.compare_agent import CompareAgent
from agents.export_agent import ExportAgent
from storage import db
import registry
from config import OUTPUT_DIR


DEMO_EMPLOYEES = [
    {
        "employeeId": "E001",
        "name": {"firstName": "Jane", "lastName": "Doe"},
        "effectiveDatedInfo": {"homeAddress": {"city": "Dearborn", "state": "MI"}},
        "jobs": {
            "effectiveDatedJobInfo": {
                "department": "Engineering",
                "customFields": {"C_GRADE_CODE": "G7"},
            }
        },
        "businessAddress": {"city": "Detroit"},
    },
    {
        "employeeId": "E002",
        "name": {"firstName": "John", "lastName": "Smith"},
        "effectiveDatedInfo": {"homeAddress": {"city": "Austin", "state": "TX"}},
        "jobs": {
            "effectiveDatedJobInfo": {
                "department": "Finance",
                "customFields": {"C_GRADE_CODE": "G5"},
            }
        },
        "businessAddress": {"city": "Austin"},
        "bonusPercent": 12.5,
        "hireDate": "2021-05-01",
        "lastLogin": "2024-01-02T10:15:00",
        "isActive": True,
    },
]


def progress_printer(**kw):
    print(
        f"Page {kw['page']:>5} | Employees {kw['employees']:>8} | "
        f"Columns {kw['columns']:>4} | Elapsed {kw['elapsed']:.1f}s | "
        f"New Columns {kw['new_columns']}"
    )


def _postprocess(mapping, total_records, table_name, start, api_name="default"):
    db.save_mapping(mapping, api_name=api_name)

    sql_agent = SQLGeneratorAgent(table_name=table_name)
    sql_text = sql_agent.generate(mapping)

    xq_agent = XQueryGeneratorAgent(root_element=table_name)
    xquery_text = xq_agent.generate(mapping)

    compare_agent = CompareAgent()
    compare_result = compare_agent.compare_schema_vs_xquery(mapping, xquery_text)
    history_diff = compare_agent.compare_with_history(mapping)

    export_agent = ExportAgent()
    export_agent.export_schema(mapping)
    export_agent.snapshot_history(mapping)
    export_agent.write_summary(
        total_records=total_records,
        total_columns=len(mapping),
        duration_sec=time.time() - start,
        compare_result=compare_result,
        history_diff=history_diff,
    )

    print(f"\n=== DONE: {api_name} ===")
    print(f"Employees scanned: {total_records}")
    print(f"Columns discovered: {len(mapping)}")
    print(f"Match %: {compare_result['match_percentage']}")


def run_scan(demo=False, table_name="employee"):
    start = time.time()

    if demo:
        scanner = LiveScannerAgent(auth_agent=None, progress_cb=progress_printer)
        mapping = scanner.scan_offline(DEMO_EMPLOYEES)
        total_records = scanner.total_records
    else:
        auth = AuthAgent()
        scanner = LiveScannerAgent(auth, progress_cb=progress_printer)
        mapping = scanner.scan(resume=True)
        total_records = scanner.total_records

    _postprocess(mapping, total_records, table_name, start, api_name="default")
    print("See the 'output' directory for master_schema.json, create_table.sql, "
          "employee.xquery, compare_report.csv and summary.txt")


def run_registered_scan(api_entry, settings):
    start = time.time()
    auth = AuthAgent(
        token_url=settings.get("token_url"),
        client_id=settings.get("client_id"),
        client_secret=settings.get("client_secret"),
        scope=settings.get("scope"),
        http_proxy=settings.get("http_proxy"),
        https_proxy=settings.get("https_proxy"),
    )
    cp_path = OUTPUT_DIR / f"checkpoint_{api_entry['name']}.json"
    schema_path = OUTPUT_DIR / f"master_schema_{api_entry['name']}.json"

    print(f"\n=== Scanning API: {api_entry['name']} ===")
    scanner = LiveScannerAgent(
        auth,
        base_url=api_entry["base_url"],
        endpoint=api_entry["endpoint"],
        page_count=int(settings.get("page_count", 1000) or 1000),
        progress_cb=progress_printer,
        checkpoint_path=cp_path,
        master_schema_path=schema_path,
    )
    mapping = scanner.scan(resume=True)
    _postprocess(mapping, scanner.total_records, api_entry.get("table_name", "employee"),
                 start, api_name=api_entry["name"])


def main():
    parser = argparse.ArgumentParser(description="Schema Studio")
    sub = parser.add_subparsers(dest="command")

    scan_p = sub.add_parser("scan", help="Run a scan")
    scan_p.add_argument("--demo", action="store_true", help="Use built-in demo data (no network calls)")
    scan_p.add_argument("--table", default="employee", help="Target table / root element name")
    scan_p.add_argument("--api", default=None, help="Name of a single registered API to scan")
    scan_p.add_argument("--all", action="store_true", help="Scan every registered API sequentially")

    sub.add_parser("gui", help="Launch the Tkinter desktop UI")

    args = parser.parse_args()

    if args.command == "scan":
        if args.api or args.all:
            apis = registry.load_apis()
            settings = registry.load_settings()
            if args.all:
                targets = apis
            else:
                targets = [a for a in apis if a["name"] == args.api]
                if not targets:
                    print(f"No registered API named '{args.api}'. Use 'python main.py gui' to add one.")
                    sys.exit(1)
            for api_entry in targets:
                run_registered_scan(api_entry, settings)
        else:
            run_scan(demo=args.demo, table_name=args.table)
    elif args.command == "gui":
        import gui
        gui.launch()
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
