"""
Registry
--------
Persists the list of registered APIs (all sharing the same auth/token
settings) and the shared auth settings themselves, so both survive
across GUI restarts. Stored as plain JSON files under the output/ dir.
"""
import json
from config import OUTPUT_DIR

REGISTRY_PATH = OUTPUT_DIR / "api_registry.json"
SETTINGS_PATH = OUTPUT_DIR / "auth_settings.json"

DEFAULT_SETTINGS = {
    "token_url": "",
    "client_id": "",
    "client_secret": "",
    "scope": "",
    "http_proxy": "",
    "https_proxy": "",
    "page_count": 1000,
}


def load_apis():
    if REGISTRY_PATH.exists():
        try:
            return json.loads(REGISTRY_PATH.read_text(encoding="utf-8"))
        except Exception:
            return []
    return []


def save_apis(apis):
    REGISTRY_PATH.write_text(json.dumps(apis, indent=2), encoding="utf-8")


def add_api(api):
    apis = load_apis()
    apis.append(api)
    save_apis(apis)
    return apis


def update_api(index, api):
    apis = load_apis()
    apis[index] = api
    save_apis(apis)
    return apis


def delete_api(index):
    apis = load_apis()
    del apis[index]
    save_apis(apis)
    return apis


def load_settings():
    if SETTINGS_PATH.exists():
        try:
            data = json.loads(SETTINGS_PATH.read_text(encoding="utf-8"))
            merged = DEFAULT_SETTINGS.copy()
            merged.update(data)
            return merged
        except Exception:
            return DEFAULT_SETTINGS.copy()
    return DEFAULT_SETTINGS.copy()


def save_settings(settings):
    merged = DEFAULT_SETTINGS.copy()
    merged.update(settings)
    SETTINGS_PATH.write_text(json.dumps(merged, indent=2), encoding="utf-8")
    return merged
