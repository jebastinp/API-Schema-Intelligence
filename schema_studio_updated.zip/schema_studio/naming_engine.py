"""
Naming Engine
-------------
Recursively discovers schema (dicts, arrays, nested arrays/objects) and
derives unique, deterministic SQL-safe column names from JSON paths.
"""
import re
from config import WRAPPER_NODES

_SAFE_RE = re.compile(r"[^0-9a-zA-Z]+")


def sql_safe(token: str) -> str:
    token = _SAFE_RE.sub("_", token).strip("_")
    return token.lower()


class SchemaNode:
    __slots__ = ("path", "types", "count")

    def __init__(self, path):
        self.path = path
        self.types = set()
        self.count = 0


class NamingEngine:
    def __init__(self):
        self.nodes = {}

    def _clean_path(self, path):
        return tuple(p for p in path if p not in WRAPPER_NODES)

    def scan_record(self, record, path=()):
        if isinstance(record, dict):
            for k, v in record.items():
                self.scan_record(v, path + (k,))
        elif isinstance(record, list):
            for item in record:
                self.scan_record(item, path)
        else:
            clean = self._clean_path(path)
            if not clean:
                return
            node = self.nodes.setdefault(clean, SchemaNode(clean))
            node.count += 1
            node.types.add(infer_type(record))

    def build_column_mapping(self):
        leaf_to_paths = {}
        for path in self.nodes:
            leaf = path[-1]
            leaf_to_paths.setdefault(leaf, []).append(path)

        mapping = []
        for path, node in self.nodes.items():
            leaf = path[-1]
            duplicates = leaf_to_paths[leaf]
            if len(duplicates) == 1:
                col_name = sql_safe(leaf)
            else:
                if len(path) >= 2:
                    col_name = sql_safe(f"{path[-2]}_{leaf}")
                else:
                    col_name = sql_safe(leaf)

            sql_type = resolve_sql_type(node.types)
            mapping.append({
                "json_path": ".".join(path),
                "column_name": col_name,
                "sql_type": sql_type,
                "occurrences": node.count,
            })

        seen = {}
        for m in mapping:
            seen.setdefault(m["column_name"], []).append(m)
        for name, entries in seen.items():
            if len(entries) > 1:
                for i, e in enumerate(entries, start=1):
                    e["column_name"] = f"{name}_{i}"

        mapping.sort(key=lambda m: m["json_path"])
        return mapping


_DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
_DATETIME_RE = re.compile(r"^\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}")


def infer_type(value):
    if value is None:
        return "Null"
    if isinstance(value, bool):
        return "Boolean"
    if isinstance(value, int):
        return "Integer"
    if isinstance(value, float):
        return "Decimal"
    if isinstance(value, str):
        if _DATETIME_RE.match(value):
            return "Datetime"
        if _DATE_RE.match(value):
            return "Date"
        return "String"
    return "String"


_PRIORITY = ["String", "Datetime", "Date", "Decimal", "Integer", "Boolean", "Null"]

_TYPE_MAP = {
    "String": "VARCHAR",
    "Integer": "INTEGER",
    "Boolean": "BOOLEAN",
    "Date": "DATE",
    "Datetime": "TIMESTAMP",
    "Decimal": "DECIMAL",
    "Null": "VARCHAR",
}


def resolve_sql_type(type_set):
    types = {t for t in type_set if t != "Null"}
    if not types:
        return "VARCHAR"
    if len(types) == 1:
        return _TYPE_MAP[next(iter(types))]
    for t in _PRIORITY:
        if t in types:
            return _TYPE_MAP[t]
    return "VARCHAR"
