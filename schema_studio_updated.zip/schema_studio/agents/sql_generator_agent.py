"""
SQL Generator Agent
-------------------
Turns the master schema (column mapping) into a CREATE TABLE statement.
"""
from config import CREATE_TABLE_SQL

PK_CANDIDATES = ("employeeid", "employee_id", "id")


class SQLGeneratorAgent:
    def __init__(self, table_name="employee"):
        self.table_name = table_name

    def generate(self, column_mapping):
        pk_col = None
        for m in column_mapping:
            if m["column_name"].lower() in PK_CANDIDATES:
                pk_col = m["column_name"]
                break

        lines = [f"CREATE TABLE {self.table_name} ("]
        col_defs = []
        for m in column_mapping:
            col_defs.append(f"    {m['column_name']} {m['sql_type']}")
        if pk_col:
            col_defs.append(f"    PRIMARY KEY ({pk_col})")
        lines.append(",\n".join(col_defs))
        lines.append(");")

        sql = "\n".join(lines)
        CREATE_TABLE_SQL.write_text(sql, encoding="utf-8")
        return sql
