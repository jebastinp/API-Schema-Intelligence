"""
Live Scanner Agent
------------------
Pages through <endpoint>?count=N&cursor=xxxxx, scans every record via the
Naming Engine, supports resume-after-interruption via a checkpoint file,
per-API isolated checkpoint/schema paths, graceful stop via threading.Event,
and reports newly-discovered JSON paths per page for live UI updates.
"""
import json
import time
import urllib.request
import urllib.error
import urllib.parse

from config import (
    API_BASE_URL, EMPLOYEE_ENDPOINT, PAGE_COUNT,
    CHECKPOINT_PATH, MASTER_SCHEMA_JSON,
)
from naming_engine import NamingEngine
from agents.auth_agent import common_headers


class LiveScannerAgent:
    def __init__(self, auth_agent, base_url=None, endpoint=None,
                 page_count=None, progress_cb=None,
                 checkpoint_path=None, master_schema_path=None,
                 stop_event=None):
        self.auth = auth_agent
        self.base_url = base_url or API_BASE_URL
        self.endpoint = endpoint or EMPLOYEE_ENDPOINT
        self.page_count = page_count or PAGE_COUNT
        self.progress_cb = progress_cb or (lambda **kw: None)
        self.checkpoint_path = checkpoint_path or CHECKPOINT_PATH
        self.master_schema_path = master_schema_path or MASTER_SCHEMA_JSON
        self.stop_event = stop_event

        self.naming = NamingEngine()
        self.total_records = 0
        self.page_num = 0
        self.start_time = None
        self.stopped = False

    def _load_checkpoint(self):
        if self.checkpoint_path.exists():
            try:
                return json.loads(self.checkpoint_path.read_text(encoding="utf-8"))
            except Exception:
                return None
        return None

    def _save_checkpoint(self, cursor, page, record_count):
        self.checkpoint_path.write_text(json.dumps({
            "cursor": cursor,
            "page": page,
            "record_count": record_count,
            "timestamp": time.time(),
        }, indent=2), encoding="utf-8")

    def _fetch_page(self, cursor):
        opener = self.auth.get_opener()
        params = {"count": self.page_count}
        if cursor:
            params["cursor"] = cursor
        url = self.base_url.rstrip("/") + self.endpoint + "?" + urllib.parse.urlencode(params)

        req = urllib.request.Request(
            url, method="GET",
            headers=common_headers({**self.auth.auth_header()}),
        )
        try:
            with opener.open(req, timeout=60) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            raise RuntimeError(f"GET {url} failed: {e.code} {e.reason} - {e.read()}")
        except urllib.error.URLError as e:
            raise RuntimeError(f"GET {url} network error: {e.reason}")

    def _should_stop(self):
        return bool(self.stop_event and self.stop_event.is_set())

    def scan(self, resume=True, max_pages=None):
        cursor = None
        if resume:
            cp = self._load_checkpoint()
            if cp:
                cursor = cp.get("cursor") or None
                self.page_num = cp.get("page", 0)
                self.total_records = cp.get("record_count", 0)

        self.start_time = time.time()

        while True:
            if self._should_stop():
                self.stopped = True
                break

            self.page_num += 1

            attempts = 0
            page = None
            while True:
                try:
                    page = self._fetch_page(cursor)
                    break
                except RuntimeError:
                    attempts += 1
                    if attempts >= 3 or self._should_stop():
                        raise
                    time.sleep(min(2 ** attempts, 15))

            employees = page.get("updateSequence", [])

            before_keys = set(self.naming.nodes.keys())
            cols_before = len(before_keys)
            for emp in employees:
                self.naming.scan_record(emp)
            after_keys = set(self.naming.nodes.keys())
            cols_after = len(after_keys)

            new_paths = sorted(".".join(p) for p in (after_keys - before_keys))

            self.total_records += len(employees)
            cursor = page.get("nextCursor") or ""

            elapsed = time.time() - self.start_time
            self.progress_cb(
                page=self.page_num,
                employees=self.total_records,
                columns=cols_after,
                elapsed=elapsed,
                new_columns=cols_after - cols_before,
                new_paths=new_paths,
            )

            self._save_checkpoint(cursor, self.page_num, self.total_records)

            if not cursor:
                break
            if max_pages and self.page_num >= max_pages:
                break

        mapping = self.naming.build_column_mapping()
        self.master_schema_path.write_text(json.dumps(mapping, indent=2), encoding="utf-8")
        return mapping

    def scan_offline(self, employee_iterable):
        self.start_time = time.time()
        for emp in employee_iterable:
            before_keys = set(self.naming.nodes.keys())
            self.naming.scan_record(emp)
            after_keys = set(self.naming.nodes.keys())
            new_paths = sorted(".".join(p) for p in (after_keys - before_keys))
            self.total_records += 1
            self.progress_cb(
                page=1,
                employees=self.total_records,
                columns=len(after_keys),
                elapsed=time.time() - self.start_time,
                new_columns=len(after_keys) - len(before_keys),
                new_paths=new_paths,
            )
        mapping = self.naming.build_column_mapping()
        self.master_schema_path.write_text(json.dumps(mapping, indent=2), encoding="utf-8")
        return mapping
