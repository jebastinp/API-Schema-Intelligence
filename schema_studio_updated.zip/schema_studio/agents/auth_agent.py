"""
Auth Agent - OAuth2 Client Credentials flow (stdlib only, urllib).
Supports corporate proxy and automatic token refresh.
"""
import json
import time
import threading
import urllib.request
import urllib.error
import urllib.parse

from config import TOKEN_URL, CLIENT_ID, CLIENT_SECRET, SCOPE, HTTP_PROXY, HTTPS_PROXY

DEFAULT_USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
)

def common_headers(extra=None):
    headers = {
        "User-Agent": DEFAULT_USER_AGENT,
        "Accept": "application/json",
        "Accept-Language": "en-US,en;q=0.9",
    }
    if extra:
        headers.update(extra)
    return headers


class AuthAgent:
    def __init__(self, token_url=None, client_id=None, client_secret=None,
                 scope=None, http_proxy=None, https_proxy=None):
        self.token_url = token_url or TOKEN_URL
        self.client_id = client_id or CLIENT_ID
        self.client_secret = client_secret or CLIENT_SECRET
        self.scope = scope or SCOPE
        self.http_proxy = http_proxy if http_proxy is not None else HTTP_PROXY
        self.https_proxy = https_proxy if https_proxy is not None else HTTPS_PROXY

        self._access_token = None
        self._expires_at = 0
        self._lock = threading.Lock()

    def _build_opener(self):
        handlers = []
        proxies = {}
        if self.http_proxy:
            proxies["http"] = self.http_proxy
        if self.https_proxy:
            proxies["https"] = self.https_proxy
        if proxies:
            handlers.append(urllib.request.ProxyHandler(proxies))
        return urllib.request.build_opener(*handlers)

    def _fetch_token(self):
        opener = self._build_opener()
        data = {
            "grant_type": "client_credentials",
            "client_id": self.client_id,
            "client_secret": self.client_secret,
        }
        if self.scope:
            data["scope"] = self.scope

        body = urllib.parse.urlencode(data).encode("utf-8")
        req = urllib.request.Request(
            self.token_url,
            data=body,
            method="POST",
            headers=common_headers({
                "Content-Type": "application/x-www-form-urlencoded",
            }),
        )
        try:
            with opener.open(req, timeout=30) as resp:
                payload = json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            raise RuntimeError(f"Token request failed: {e.code} {e.reason} - {e.read()}")
        except urllib.error.URLError as e:
            raise RuntimeError(f"Token request network error: {e.reason}")

        access_token = payload.get("access_token")
        expires_in = int(payload.get("expires_in", 3600))
        if not access_token:
            raise RuntimeError(f"No access_token in response: {payload}")

        self._access_token = access_token
        self._expires_at = time.time() + max(expires_in - 60, 30)
        return access_token

    def get_token(self):
        with self._lock:
            if self._access_token is None or time.time() >= self._expires_at:
                self._fetch_token()
            return self._access_token

    def get_opener(self):
        return self._build_opener()

    def auth_header(self):
        return {"Authorization": f"Bearer {self.get_token()}"}
