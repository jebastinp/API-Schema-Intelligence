"""
Compare Agent
-------------
Compares the live API schema (master_schema.json) against an existing
XQuery file's field list. Reports Matched / Missing / Extra and a
match percentage. Also compares against prior schema versions in
history/ to report Added/Removed columns.
"""
import csv
import re
import json
from config import COMPARE_REPORT_CSV, HISTORY_DIR

_TAG_RE = re.compile(r"<([a-zA-Z0-9_]+)>\{")


class CompareAgent:
    def compare_schema_vs_xquery(self, column_mapping, xquery_text):
        api_columns = {m["column_name"] for m in column_mapping}
        xquery_columns = set(_TAG_RE.findall(xquery_text))

        matched = sorted(api_columns & xquery_columns)
        missing = sorted(api_columns - xquery_columns)
        extra = sorted(xquery_columns - api_columns)

        total = len(api_columns) if api_columns else 1
        pct = round(len(matched) / total * 100, 2)

        rows = []
        for c in matched:
            rows.append({"column": c, "status": "MATCHED"})
        for c in missing:
            rows.append({"column": c, "status": "MISSING"})
        for c in extra:
            rows.append({"column": c, "status": "EXTRA"})

        with open(COMPARE_REPORT_CSV, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=["column", "status"])
            writer.writeheader()
            writer.writerows(rows)

        return {
            "matched": matched,
            "missing": missing,
            "extra": extra,
            "match_percentage": pct,
        }

    def compare_with_history(self, column_mapping):
        history_files = sorted(HISTORY_DIR.glob("schema_*.json"))
        if not history_files:
            return {"added": [], "removed": [], "note": "No prior history found."}

        prev = json.loads(history_files[-1].read_text(encoding="utf-8"))
        prev_cols = {m["column_name"] for m in prev}
        curr_cols = {m["column_name"] for m in column_mapping}

        added = sorted(curr_cols - prev_cols)
        removed = sorted(prev_cols - curr_cols)
        return {"added": added, "removed": removed}
