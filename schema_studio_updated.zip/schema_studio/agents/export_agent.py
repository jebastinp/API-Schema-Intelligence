"""
Export Agent
------------
Writes all deliverables: master_schema.json/csv, column_mapping.csv,
create_table.sql, employee.xquery, compare_report.csv, summary.txt.
Also snapshots the schema into history/ for version tracking.
"""
import csv
import json
from datetime import datetime

from config import (
    MASTER_SCHEMA_JSON, MASTER_SCHEMA_CSV, COLUMN_MAPPING_CSV,
    HISTORY_DIR, SUMMARY_TXT,
)


class ExportAgent:
    def export_schema(self, column_mapping):
        MASTER_SCHEMA_JSON.write_text(json.dumps(column_mapping, indent=2), encoding="utf-8")

        with open(MASTER_SCHEMA_CSV, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=["json_path", "column_name", "sql_type", "occurrences"])
            writer.writeheader()
            writer.writerows(column_mapping)

        with open(COLUMN_MAPPING_CSV, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=["json_path", "column_name", "sql_type", "occurrences"])
            writer.writeheader()
            writer.writerows(column_mapping)

    def snapshot_history(self, column_mapping):
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        path = HISTORY_DIR / f"schema_{ts}.json"
        path.write_text(json.dumps(column_mapping, indent=2), encoding="utf-8")
        return path

    def write_summary(self, *, total_records, total_columns, duration_sec,
                       compare_result=None, history_diff=None):
        lines = [
            "Schema Studio - Scan Summary",
            "=============================",
            f"Generated: {datetime.now().isoformat()}",
            f"Total Employees Scanned: {total_records}",
            f"Total Columns Discovered: {total_columns}",
            f"Duration: {duration_sec:.2f} sec",
            "",
        ]
        if compare_result:
            lines += [
                "Compare Result",
                "---------------",
                f"Matched: {len(compare_result.get('matched', []))}",
                f"Missing: {len(compare_result.get('missing', []))}",
                f"Extra: {len(compare_result.get('extra', []))}",
                f"Match %: {compare_result.get('match_percentage', 0)}",
                "",
            ]
        if history_diff:
            lines += [
                "History Diff",
                "-------------",
                f"Added Columns: {history_diff.get('added', [])}",
                f"Removed Columns: {history_diff.get('removed', [])}",
                "",
            ]
        SUMMARY_TXT.write_text("\n".join(lines), encoding="utf-8")
