"""
Central configuration for Schema Studio.
Edit these values or override with environment variables.
"""
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
OUTPUT_DIR = BASE_DIR / "output"
HISTORY_DIR = OUTPUT_DIR / "history"
REPORTS_DIR = OUTPUT_DIR / "reports"
STORAGE_DIR = BASE_DIR / "storage"
DB_PATH = STORAGE_DIR / "schema.db"
CHECKPOINT_PATH = OUTPUT_DIR / "checkpoint.json"
MASTER_SCHEMA_JSON = OUTPUT_DIR / "master_schema.json"
MASTER_SCHEMA_CSV = OUTPUT_DIR / "master_schema.csv"
COLUMN_MAPPING_CSV = OUTPUT_DIR / "column_mapping.csv"
CREATE_TABLE_SQL = OUTPUT_DIR / "create_table.sql"
XQUERY_FILE = OUTPUT_DIR / "employee.xquery"
COMPARE_REPORT_CSV = OUTPUT_DIR / "compare_report.csv"
SUMMARY_TXT = OUTPUT_DIR / "summary.txt"

for d in (OUTPUT_DIR, HISTORY_DIR, REPORTS_DIR, STORAGE_DIR):
    d.mkdir(parents=True, exist_ok=True)

TOKEN_URL = os.environ.get("SS_TOKEN_URL", "")
CLIENT_ID = os.environ.get("SS_CLIENT_ID", "")
CLIENT_SECRET = os.environ.get("SS_CLIENT_SECRET", "")
SCOPE = os.environ.get("SS_SCOPE", "")

HTTP_PROXY = os.environ.get("HTTP_PROXY", os.environ.get("SS_HTTP_PROXY", "http://internet.ford.com:83"))
HTTPS_PROXY = os.environ.get("HTTPS_PROXY", os.environ.get("SS_HTTPS_PROXY", "http://internet.ford.com:83"))

API_BASE_URL = os.environ.get("SS_API_BASE_URL", "")
EMPLOYEE_ENDPOINT = os.environ.get("SS_EMPLOYEE_ENDPOINT", "/employee/v1")
PAGE_COUNT = int(os.environ.get("SS_PAGE_COUNT", "1000"))

WRAPPER_NODES = {
    "updateSequence", "results", "item", "items",
    "payload", "response", "records", "root", "data",
}

MAX_WORKERS = int(os.environ.get("SS_MAX_WORKERS", "4"))
