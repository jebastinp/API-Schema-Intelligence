"""
SQLite-backed storage helper (stdlib sqlite3).
Each row is tagged with an api_name so multiple APIs' schemas can be
stored side by side without overwriting each other.
"""
import sqlite3
from config import DB_PATH


def get_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS schema_columns (
            api_name TEXT,
            json_path TEXT,
            column_name TEXT,
            sql_type TEXT,
            occurrences INTEGER,
            PRIMARY KEY (api_name, json_path)
        )
    """)
    conn.commit()
    return conn


def save_mapping(column_mapping, api_name="default"):
    conn = get_connection()
    conn.execute("DELETE FROM schema_columns WHERE api_name = ?", (api_name,))
    conn.executemany(
        "INSERT INTO schema_columns (api_name, json_path, column_name, sql_type, occurrences) "
        "VALUES (?, ?, ?, ?, ?)",
        [(api_name, m["json_path"], m["column_name"], m["sql_type"], m["occurrences"])
         for m in column_mapping],
    )
    conn.commit()
    conn.close()


def load_mapping(api_name=None):
    conn = get_connection()
    if api_name:
        cur = conn.execute(
            "SELECT json_path, column_name, sql_type, occurrences FROM schema_columns "
            "WHERE api_name = ? ORDER BY json_path", (api_name,)
        )
    else:
        cur = conn.execute(
            "SELECT json_path, column_name, sql_type, occurrences FROM schema_columns "
            "ORDER BY json_path"
        )
    rows = [
        {"json_path": r[0], "column_name": r[1], "sql_type": r[2], "occurrences": r[3]}
        for r in cur.fetchall()
    ]
    conn.close()
    return rows


def list_api_names():
    conn = get_connection()
    cur = conn.execute("SELECT DISTINCT api_name FROM schema_columns ORDER BY api_name")
    names = [r[0] for r in cur.fetchall()]
    conn.close()
    return names
