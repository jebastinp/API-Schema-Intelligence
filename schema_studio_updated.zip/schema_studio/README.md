# Schema Studio

Pure Python standard-library toolkit to scan live paginated employee APIs,
recursively discover schemas, and generate SQL / Informatica IICS XQuery,
schema comparisons, and reports.

No third-party packages. No `requests`. Only: `urllib`, `json`, `sqlite3`,
`csv`, `xml.etree.ElementTree`, `pathlib`, `os`, `re`, `threading`,
`concurrent.futures`, `tkinter`.

## Quick Start

```bash
# Run against built-in demo data (no network / no credentials needed)
python main.py scan --demo

# Run a real live scan (requires env vars below)
python main.py scan

# Launch the VS Code style desktop UI
python main.py gui
```

## Configuration (environment variables)

| Variable            | Purpose                                   |
|---------------------|--------------------------------------------|
| SS_TOKEN_URL         | OAuth2 token endpoint                      |
| SS_CLIENT_ID         | OAuth2 client id                           |
| SS_CLIENT_SECRET     | OAuth2 client secret                       |
| SS_SCOPE             | OAuth2 scope (optional)                    |
| SS_API_BASE_URL      | Base URL of the employee API                |
| SS_HTTP_PROXY        | Corporate proxy for HTTP (e.g. http://internet.ford.com:83) |
| SS_HTTPS_PROXY       | Corporate proxy for HTTPS                  |
| SS_PAGE_COUNT        | Page size (default 1000)                   |
| SS_MAX_WORKERS       | Thread pool size (default 4)               |

On Windows PowerShell:
```powershell
$env:SS_TOKEN_URL="https://auth.example.com/oauth/token"
$env:SS_CLIENT_ID="your-client-id"
$env:SS_CLIENT_SECRET="your-client-secret"
$env:SS_API_BASE_URL="https://api.example.com"
$env:SS_HTTP_PROXY="http://internet.ford.com:83"
$env:SS_HTTPS_PROXY="http://internet.ford.com:83"
python main.py scan
```

## Architecture

```
Auth Agent -> Live Scanner Agent -> Naming Engine
                                        |
                          -------------------------------
                          |                             |
                     SQL Agent                    XQuery Agent
                          |                             |
                          -------------- Compare Agent --
                                        |
                                  Export Agent
```

## Project Structure

```
schema_studio/
  main.py                 CLI entry point
  gui.py                  Tkinter VS Code-style desktop UI (light theme)
  config.py                Central configuration
  naming_engine.py          Recursive schema discovery + naming rules
  agents/
    auth_agent.py            OAuth2 client credentials + proxy + refresh
    live_scanner_agent.py    Cursor-paginated scanning, resume support
    sql_generator_agent.py   CREATE TABLE generator
    xquery_generator_agent.py Informatica IICS XQuery generator
    compare_agent.py         Schema vs XQuery + history diff
    export_agent.py          Writes all output files + history snapshots
  storage/
    db.py                    SQLite persistence for the Schema Explorer
    schema.db                (created at runtime)
  output/
    master_schema.json / .csv
    column_mapping.csv
    create_table.sql
    employee.xquery
    compare_report.csv
    summary.txt
    checkpoint.json          Resume state (cursor, page, record count)
    history/                 Timestamped schema snapshots
    reports/
```

## Key Behaviors

- **Resume**: every page saves `checkpoint.json` with cursor/page/record
  count. If the process is interrupted, `python main.py scan` resumes
  automatically from the last cursor.
- **Recursive scanning**: every employee is walked recursively through
  nested dicts and arrays (e.g. `jobs.effectiveDatedJobInfo.customFields.C_GRADE_CODE`).
  No assumption is made that the first employee record contains every
  possible column — the schema is the union across *all* scanned records.
- **Naming Engine**: wrapper nodes (`updateSequence`, `results`, `item`,
  `items`, `payload`, `response`, `records`, `root`, `data`) are stripped.
  Unique leaf names are used as-is (`employeeid`); duplicate leaves are
  disambiguated with their parent (`homeaddress_city`, `businessaddress_city`).
- **XQuery**: always uses complete, non-shortened XPath expressions.
- **History & version diff**: every scan snapshots the discovered schema
  into `output/history/schema_YYYYMMDD_HHMMSS.json`; the Compare Agent can
  report Added/Removed columns versus the prior snapshot.

## Notes for corporate networks

If you're behind a corporate proxy (e.g. Ford's `http://internet.ford.com:83`),
set `SS_HTTP_PROXY` / `SS_HTTPS_PROXY` (or the standard `HTTP_PROXY` /
`HTTPS_PROXY` env vars) — `AuthAgent` and `LiveScannerAgent` both honor them
automatically via `urllib.request.ProxyHandler`.
