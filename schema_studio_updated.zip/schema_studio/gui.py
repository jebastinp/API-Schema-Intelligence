"""
Schema Studio - Tkinter Desktop UI
-----------------------------------
Modules: Dashboard, Live Scanner, Schema Explorer, SQL Generator,
XQuery Generator, Compare Reports, History, Settings.

Live Scanner module supports:
  - Managing a registry of APIs (add / edit / delete) from the UI,
    all sharing one set of auth/token settings (configured in Settings).
  - Running a REAL live scan (not just the demo) against a selected
    API, or against ALL registered APIs sequentially.
  - Live progress: page / employee / column counters update in real
    time, and a table of discovered columns grows live as new columns
    are found while the scan is running.
  - Stop button to cleanly halt a running scan (checkpoint is saved,
    so it can be resumed later).

Pure stdlib (tkinter) - no third-party dependencies.
"""
import threading
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

from agents.auth_agent import AuthAgent
from agents.live_scanner_agent import LiveScannerAgent
from agents.sql_generator_agent import SQLGeneratorAgent
from agents.xquery_generator_agent import XQueryGeneratorAgent
from agents.compare_agent import CompareAgent
from agents.export_agent import ExportAgent
from storage import db
import registry
from config import OUTPUT_DIR

BG = "#ffffff"
PANEL = "#f3f3f3"
ACCENT = "#007acc"
TEXT = "#1e1e1e"
GREEN = "#2e7d32"
YELLOW = "#f9a825"
RED = "#c62828"

MODULES = [
    "Dashboard", "Live Scanner", "Schema Explorer", "SQL Generator",
    "XQuery Generator", "Compare Reports", "History", "Settings",
]


class SchemaStudioApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Schema Studio")
        self.root.geometry("1300x760")
        self.root.configure(bg=BG)

        self.mapping = []
        self.sql_text = ""
        self.xquery_text = ""
        self.compare_result = None

        self.stop_event = None
        self.scan_running = False
        self.seen_paths = set()

        self._build_layout()
        self.show_module("Dashboard")

    def _build_layout(self):
        self.nav = tk.Frame(self.root, bg=PANEL, width=190)
        self.nav.pack(side="left", fill="y")

        title = tk.Label(self.nav, text="SCHEMA STUDIO", bg=PANEL, fg=ACCENT,
                          font=("Segoe UI", 11, "bold"), pady=14)
        title.pack(fill="x")

        self.nav_buttons = {}
        for m in MODULES:
            b = tk.Button(self.nav, text=m, anchor="w", relief="flat",
                          bg=PANEL, fg=TEXT, font=("Segoe UI", 10),
                          activebackground="#e0e0e0", bd=0, padx=16, pady=8,
                          command=lambda m=m: self.show_module(m))
            b.pack(fill="x")
            self.nav_buttons[m] = b

        self.content = tk.Frame(self.root, bg=BG)
        self.content.pack(side="left", fill="both", expand=True)

    def _clear_content(self):
        for w in self.content.winfo_children():
            w.destroy()

    def show_module(self, name):
        self._clear_content()
        for m, b in self.nav_buttons.items():
            b.configure(bg="#dcdcdc" if m == name else PANEL)

        method = getattr(self, f"_render_{name.lower().replace(' ', '_')}", None)
        if method:
            method()
        else:
            tk.Label(self.content, text=f"{name} (coming soon)", bg=BG).pack(pady=20)

    def _card(self, parent, title, value):
        f = tk.Frame(parent, bg="#fafafa", highlightbackground="#ddd",
                     highlightthickness=1, width=180, height=90)
        f.pack_propagate(False)
        tk.Label(f, text=title, bg="#fafafa", fg="#555",
                 font=("Segoe UI", 9)).pack(anchor="w", padx=10, pady=(10, 0))
        tk.Label(f, text=str(value), bg="#fafafa", fg=ACCENT,
                 font=("Segoe UI", 18, "bold")).pack(anchor="w", padx=10)
        return f

    def _render_dashboard(self):
        tk.Label(self.content, text="Dashboard", bg=BG, fg=TEXT,
                 font=("Segoe UI", 14, "bold")).pack(anchor="w", padx=20, pady=15)

        grid = tk.Frame(self.content, bg=BG)
        grid.pack(fill="x", padx=20)

        apis = registry.load_apis()
        cards = [
            ("Registered APIs", len(apis)),
            ("Columns (last run)", len(self.mapping)),
            ("Tables", 1 if self.mapping else 0),
            ("XQueries", 1 if self.xquery_text else 0),
            ("Reports", 1 if self.compare_result else 0),
            ("Scan Running", "Yes" if self.scan_running else "No"),
        ]
        for i, (t, v) in enumerate(cards):
            c = self._card(grid, t, v)
            c.grid(row=i // 3, column=i % 3, padx=10, pady=10)

    def _render_live_scanner(self):
        tk.Label(self.content, text="Live Scanner", bg=BG, fg=TEXT,
                 font=("Segoe UI", 14, "bold")).pack(anchor="w", padx=20, pady=(15, 5))

        api_frame = tk.LabelFrame(self.content, text="Registered APIs (shared auth settings)",
                                   bg=BG, fg=TEXT, padx=8, pady=8)
        api_frame.pack(fill="x", padx=20, pady=(0, 8))

        list_row = tk.Frame(api_frame, bg=BG)
        list_row.pack(fill="x")

        self.api_listbox = tk.Listbox(list_row, height=5, bg="#fafafa")
        self.api_listbox.pack(side="left", fill="both", expand=True)

        btns = tk.Frame(list_row, bg=BG)
        btns.pack(side="left", padx=8)
        tk.Button(btns, text="Add API", width=14, command=self._add_api_dialog).pack(pady=2)
        tk.Button(btns, text="Edit API", width=14, command=self._edit_api_dialog).pack(pady=2)
        tk.Button(btns, text="Delete API", width=14, command=self._delete_api).pack(pady=2)
        tk.Button(btns, text="Refresh", width=14, command=self._refresh_api_list).pack(pady=2)

        run_frame = tk.Frame(self.content, bg=BG)
        run_frame.pack(fill="x", padx=20, pady=(0, 8))

        tk.Label(run_frame, text="Select API:", bg=BG).pack(side="left")
        self.api_choice = tk.StringVar()
        self.api_combo = ttk.Combobox(run_frame, textvariable=self.api_choice,
                                       width=30, state="readonly")
        self.api_combo.pack(side="left", padx=6)

        self.run_btn = tk.Button(run_frame, text="Run Live Scan", command=self._run_live_scan,
                                  bg=ACCENT, fg="white", relief="flat", padx=10, pady=6)
        self.run_btn.pack(side="left", padx=4)

        self.stop_btn = tk.Button(run_frame, text="Stop", command=self._stop_scan,
                                   bg=RED, fg="white", relief="flat", padx=10, pady=6,
                                   state="disabled")
        self.stop_btn.pack(side="left", padx=4)

        tk.Button(run_frame, text="Run Demo Scan", command=self._run_demo_scan,
                  padx=10, pady=6).pack(side="left", padx=4)

        stats_frame = tk.Frame(self.content, bg=BG)
        stats_frame.pack(fill="x", padx=20, pady=(0, 8))

        self.stat_vars = {
            "api": tk.StringVar(value="API: -"),
            "page": tk.StringVar(value="Page: 0"),
            "employees": tk.StringVar(value="Employees: 0"),
            "columns": tk.StringVar(value="Columns: 0"),
            "elapsed": tk.StringVar(value="Elapsed: 0.0s"),
        }
        for key in ("api", "page", "employees", "columns", "elapsed"):
            tk.Label(stats_frame, textvariable=self.stat_vars[key], bg=BG, fg=ACCENT,
                     font=("Segoe UI", 10, "bold")).pack(side="left", padx=12)

        split = tk.Frame(self.content, bg=BG)
        split.pack(fill="both", expand=True, padx=20, pady=(0, 15))

        left = tk.Frame(split, bg=BG)
        left.pack(side="left", fill="both", expand=True)
        tk.Label(left, text="Log", bg=BG, fg=TEXT, font=("Segoe UI", 10, "bold")).pack(anchor="w")
        self.log_box = tk.Text(left, height=25, bg="#fafafa", fg=TEXT)
        self.log_box.pack(fill="both", expand=True)

        right = tk.Frame(split, bg=BG, width=380)
        right.pack(side="left", fill="both", padx=(10, 0))
        tk.Label(right, text="Columns discovered (live)", bg=BG, fg=TEXT,
                 font=("Segoe UI", 10, "bold")).pack(anchor="w")
        self.live_columns_tree = ttk.Treeview(
            right, columns=("type",), show="tree headings", height=25
        )
        self.live_columns_tree.heading("#0", text="JSON Path")
        self.live_columns_tree.heading("type", text="Type")
        self.live_columns_tree.column("type", width=90)
        self.live_columns_tree.pack(fill="both", expand=True)

        self._refresh_api_list()

    def _refresh_api_list(self):
        apis = registry.load_apis()
        self.api_listbox.delete(0, "end")
        for a in apis:
            self.api_listbox.insert(
                "end", f"{a['name']}  ->  {a['base_url'].rstrip('/')}{a['endpoint']}"
            )
        names = [a["name"] for a in apis]
        combo_values = names + (["ALL APIs"] if names else [])
        self.api_combo["values"] = combo_values
        if combo_values and not self.api_choice.get():
            self.api_choice.set(combo_values[0])

    def _api_dialog(self, existing=None, index=None):
        dlg = tk.Toplevel(self.root)
        dlg.title("API" if existing is None else "Edit API")
        dlg.geometry("420x260")
        dlg.configure(bg=BG)

        fields = {}
        labels = [
            ("name", "Name (unique)"),
            ("base_url", "Base URL (e.g. https://api-eu3.wfs.cloud)"),
            ("endpoint", "Endpoint path (e.g. /employee/v1)"),
            ("table_name", "Table / root element name"),
        ]
        for key, label in labels:
            tk.Label(dlg, text=label, bg=BG, anchor="w").pack(fill="x", padx=12, pady=(8, 0))
            var = tk.StringVar(value=(existing or {}).get(key, "" if key != "table_name" else "employee"))
            entry = tk.Entry(dlg, textvariable=var)
            entry.pack(fill="x", padx=12)
            fields[key] = var

        def save():
            name = fields["name"].get().strip()
            base_url = fields["base_url"].get().strip()
            endpoint = fields["endpoint"].get().strip() or "/employee/v1"
            table_name = fields["table_name"].get().strip() or "employee"
            if not name or not base_url:
                messagebox.showerror("Missing fields", "Name and Base URL are required.")
                return
            api = {"name": name, "base_url": base_url, "endpoint": endpoint, "table_name": table_name}
            if index is None:
                registry.add_api(api)
            else:
                registry.update_api(index, api)
            dlg.destroy()
            self._refresh_api_list()

        tk.Button(dlg, text="Save", command=save, bg=ACCENT, fg="white",
                  relief="flat", padx=10, pady=6).pack(pady=14)

    def _add_api_dialog(self):
        self._api_dialog()

    def _edit_api_dialog(self):
        sel = self.api_listbox.curselection()
        if not sel:
            messagebox.showinfo("Select API", "Select an API from the list first.")
            return
        idx = sel[0]
        apis = registry.load_apis()
        self._api_dialog(existing=apis[idx], index=idx)

    def _delete_api(self):
        sel = self.api_listbox.curselection()
        if not sel:
            messagebox.showinfo("Select API", "Select an API from the list first.")
            return
        idx = sel[0]
        if messagebox.askyesno("Delete API", "Delete the selected API registration?"):
            registry.delete_api(idx)
            self._refresh_api_list()

    def _log(self, msg):
        self.log_box.insert("end", msg + "\n")
        self.log_box.see("end")

    def _set_running_state(self, running):
        self.scan_running = running
        self.run_btn.config(state="disabled" if running else "normal")
        self.stop_btn.config(state="normal" if running else "disabled")

    def _on_progress(self, api_name, kw):
        self.stat_vars["api"].set(f"API: {api_name}")
        self.stat_vars["page"].set(f"Page: {kw['page']}")
        self.stat_vars["employees"].set(f"Employees: {kw['employees']}")
        self.stat_vars["columns"].set(f"Columns: {kw['columns']}")
        self.stat_vars["elapsed"].set(f"Elapsed: {kw['elapsed']:.1f}s")

        self._log(
            f"[{api_name}] Page {kw['page']} | Employees {kw['employees']} | "
            f"Columns {kw['columns']} | Elapsed {kw['elapsed']:.1f}s | New {kw['new_columns']}"
        )

        for p in kw.get("new_paths", []):
            key = (api_name, p)
            if key in self.seen_paths:
                continue
            self.seen_paths.add(key)
            self.live_columns_tree.insert("", "end", text=p, values=("...",))

    def _run_demo_scan(self):
        def worker():
            from main import DEMO_EMPLOYEES

            def progress(**kw):
                self.root.after(0, lambda kw=kw: self._on_progress("DEMO", kw))

            self.root.after(0, lambda: self._set_running_state(True))
            self.seen_paths = set()
            self.root.after(0, lambda: self.live_columns_tree.delete(*self.live_columns_tree.get_children()))

            scanner = LiveScannerAgent(auth_agent=None, progress_cb=progress)
            mapping = scanner.scan_offline(DEMO_EMPLOYEES)
            self.mapping = mapping
            db.save_mapping(mapping, api_name="DEMO")
            self.root.after(0, lambda: self._log(f"Demo scan complete. {len(mapping)} columns discovered."))
            self.root.after(0, lambda: self._set_running_state(False))

        threading.Thread(target=worker, daemon=True).start()

    def _run_live_scan(self):
        selected = self.api_choice.get()
        apis = registry.load_apis()
        if not apis:
            messagebox.showwarning("No APIs", "Add at least one API first.")
            return

        if selected == "ALL APIs":
            targets = apis
        else:
            targets = [a for a in apis if a["name"] == selected]
            if not targets:
                messagebox.showwarning("Select API", "Select a valid API to run.")
                return

        settings = registry.load_settings()
        if not settings.get("token_url") or not settings.get("client_id"):
            if not messagebox.askyesno(
                "Auth not configured",
                "Token URL / Client ID are empty in Settings. Continue anyway?"
            ):
                return

        self.stop_event = threading.Event()
        self.seen_paths = set()
        self.live_columns_tree.delete(*self.live_columns_tree.get_children())
        self._set_running_state(True)

        def worker():
            for api in targets:
                if self.stop_event.is_set():
                    break
                self.root.after(0, lambda n=api["name"]: self._log(f"=== Starting scan: {n} ==="))
                try:
                    auth = AuthAgent(
                        token_url=settings.get("token_url"),
                        client_id=settings.get("client_id"),
                        client_secret=settings.get("client_secret"),
                        scope=settings.get("scope"),
                        http_proxy=settings.get("http_proxy"),
                        https_proxy=settings.get("https_proxy"),
                    )
                    cp_path = OUTPUT_DIR / f"checkpoint_{api['name']}.json"
                    schema_path = OUTPUT_DIR / f"master_schema_{api['name']}.json"

                    def progress(api_name=api["name"], **kw):
                        self.root.after(0, lambda kw=kw: self._on_progress(api_name, kw))

                    scanner = LiveScannerAgent(
                        auth,
                        base_url=api["base_url"],
                        endpoint=api["endpoint"],
                        page_count=int(settings.get("page_count", 1000) or 1000),
                        progress_cb=progress,
                        checkpoint_path=cp_path,
                        master_schema_path=schema_path,
                        stop_event=self.stop_event,
                    )
                    mapping = scanner.scan(resume=True)
                    self.mapping = mapping
                    db.save_mapping(mapping, api_name=api["name"])
                    status = "stopped" if scanner.stopped else "complete"
                    self.root.after(0, lambda n=api["name"], m=len(mapping), s=status:
                                     self._log(f"[{n}] scan {s}. {m} columns discovered."))
                except Exception as e:
                    self.root.after(0, lambda e=e: self._log(f"ERROR: {e}"))

            self.root.after(0, lambda: self._log("=== All scans finished ==="))
            self.root.after(0, lambda: self._set_running_state(False))

        threading.Thread(target=worker, daemon=True).start()

    def _stop_scan(self):
        if self.stop_event:
            self.stop_event.set()
            self._log("Stop requested... will halt after current page and save checkpoint.")

    def _render_schema_explorer(self):
        tk.Label(self.content, text="Schema Explorer", bg=BG, fg=TEXT,
                 font=("Segoe UI", 14, "bold")).pack(anchor="w", padx=20, pady=15)

        top = tk.Frame(self.content, bg=BG)
        top.pack(fill="x", padx=20)
        tk.Label(top, text="Search:", bg=BG).pack(side="left")
        search_var = tk.StringVar()
        tk.Entry(top, textvariable=search_var, width=40).pack(side="left", padx=5)

        tk.Label(top, text="  API:", bg=BG).pack(side="left")
        api_names = ["(current run)"] + db.list_api_names()
        api_var = tk.StringVar(value=api_names[0])
        api_pick = ttk.Combobox(top, textvariable=api_var, values=api_names,
                                 state="readonly", width=20)
        api_pick.pack(side="left", padx=5)

        tree = ttk.Treeview(self.content, columns=("type", "occ"), show="tree headings")
        tree.heading("#0", text="Path")
        tree.heading("type", text="SQL Type")
        tree.heading("occ", text="Occurrences")
        tree.pack(fill="both", expand=True, padx=20, pady=10)

        def current_source():
            if api_var.get() == "(current run)":
                return self.mapping
            return db.load_mapping(api_var.get())

        def populate(filter_text=""):
            tree.delete(*tree.get_children())
            for m in current_source():
                if filter_text.lower() in m["json_path"].lower():
                    tree.insert("", "end", text=m["json_path"],
                                values=(m["sql_type"], m["occurrences"]))

        populate()
        search_var.trace_add("write", lambda *a: populate(search_var.get()))
        api_pick.bind("<<ComboboxSelected>>", lambda e: populate(search_var.get()))

    def _render_sql_generator(self):
        tk.Label(self.content, text="SQL Generator", bg=BG, fg=TEXT,
                 font=("Segoe UI", 14, "bold")).pack(anchor="w", padx=20, pady=15)

        btn_frame = tk.Frame(self.content, bg=BG)
        btn_frame.pack(anchor="w", padx=20)

        text_box = tk.Text(self.content, bg="#fafafa", fg=TEXT)
        text_box.pack(fill="both", expand=True, padx=20, pady=10)

        def generate():
            agent = SQLGeneratorAgent()
            self.sql_text = agent.generate(self.mapping)
            text_box.delete("1.0", "end")
            text_box.insert("1.0", self.sql_text)

        def copy():
            self.root.clipboard_clear()
            self.root.clipboard_append(text_box.get("1.0", "end"))

        def save():
            path = filedialog.asksaveasfilename(defaultextension=".sql")
            if path:
                with open(path, "w", encoding="utf-8") as f:
                    f.write(text_box.get("1.0", "end"))

        tk.Button(btn_frame, text="Generate", command=generate, bg=ACCENT, fg="white",
                  relief="flat", padx=10, pady=6).pack(side="left", padx=3)
        tk.Button(btn_frame, text="Copy", command=copy, padx=10, pady=6).pack(side="left", padx=3)
        tk.Button(btn_frame, text="Save", command=save, padx=10, pady=6).pack(side="left", padx=3)

    def _render_xquery_generator(self):
        tk.Label(self.content, text="XQuery Generator", bg=BG, fg=TEXT,
                 font=("Segoe UI", 14, "bold")).pack(anchor="w", padx=20, pady=15)

        btn_frame = tk.Frame(self.content, bg=BG)
        btn_frame.pack(anchor="w", padx=20)

        text_box = tk.Text(self.content, bg="#fafafa", fg=TEXT)
        text_box.pack(fill="both", expand=True, padx=20, pady=10)

        def generate():
            agent = XQueryGeneratorAgent()
            self.xquery_text = agent.generate(self.mapping)
            text_box.delete("1.0", "end")
            text_box.insert("1.0", self.xquery_text)

        def copy():
            self.root.clipboard_clear()
            self.root.clipboard_append(text_box.get("1.0", "end"))

        def download():
            path = filedialog.asksaveasfilename(defaultextension=".xquery")
            if path:
                with open(path, "w", encoding="utf-8") as f:
                    f.write(text_box.get("1.0", "end"))

        tk.Button(btn_frame, text="Generate", command=generate, bg=ACCENT, fg="white",
                  relief="flat", padx=10, pady=6).pack(side="left", padx=3)
        tk.Button(btn_frame, text="Copy", command=copy, padx=10, pady=6).pack(side="left", padx=3)
        tk.Button(btn_frame, text="Download", command=download, padx=10, pady=6).pack(side="left", padx=3)

    def _render_compare_reports(self):
        tk.Label(self.content, text="Compare Reports", bg=BG, fg=TEXT,
                 font=("Segoe UI", 14, "bold")).pack(anchor="w", padx=20, pady=15)

        btn_frame = tk.Frame(self.content, bg=BG)
        btn_frame.pack(anchor="w", padx=20)

        tree = ttk.Treeview(self.content, columns=("status",), show="tree headings")
        tree.heading("#0", text="Column")
        tree.heading("status", text="Status")
        tree.tag_configure("MATCHED", background="#c8e6c9")
        tree.tag_configure("MISSING", background="#fff9c4")
        tree.tag_configure("EXTRA", background="#ffcdd2")
        tree.pack(fill="both", expand=True, padx=20, pady=10)

        def run_compare():
            if not self.xquery_text:
                agent = XQueryGeneratorAgent()
                self.xquery_text = agent.generate(self.mapping)
            agent = CompareAgent()
            self.compare_result = agent.compare_schema_vs_xquery(self.mapping, self.xquery_text)
            tree.delete(*tree.get_children())
            for c in self.compare_result["matched"]:
                tree.insert("", "end", text=c, values=("MATCHED",), tags=("MATCHED",))
            for c in self.compare_result["missing"]:
                tree.insert("", "end", text=c, values=("MISSING",), tags=("MISSING",))
            for c in self.compare_result["extra"]:
                tree.insert("", "end", text=c, values=("EXTRA",), tags=("EXTRA",))

        tk.Button(btn_frame, text="Run Compare", command=run_compare, bg=ACCENT, fg="white",
                  relief="flat", padx=10, pady=6).pack(side="left")

    def _render_history(self):
        tk.Label(self.content, text="History", bg=BG, fg=TEXT,
                 font=("Segoe UI", 14, "bold")).pack(anchor="w", padx=20, pady=15)
        from config import HISTORY_DIR
        files_ = sorted(HISTORY_DIR.glob("schema_*.json"))
        box = tk.Listbox(self.content, bg="#fafafa")
        box.pack(fill="both", expand=True, padx=20, pady=10)
        for f in files_:
            box.insert("end", f.name)
        if not files_:
            box.insert("end", "No history snapshots yet. Run a scan first.")

    def _render_settings(self):
        tk.Label(self.content, text="Settings", bg=BG, fg=TEXT,
                 font=("Segoe UI", 14, "bold")).pack(anchor="w", padx=20, pady=15)

        tk.Label(self.content,
                 text="These settings are shared by every registered API (same auth/token).",
                 bg=BG, fg="#555").pack(anchor="w", padx=20)

        form = tk.Frame(self.content, bg=BG)
        form.pack(fill="x", padx=20, pady=10)

        settings = registry.load_settings()
        keys = [
            ("token_url", "Token URL"),
            ("client_id", "Client ID"),
            ("client_secret", "Client Secret"),
            ("scope", "Scope (optional)"),
            ("http_proxy", "HTTP Proxy"),
            ("https_proxy", "HTTPS Proxy"),
            ("page_count", "Page Count (records per page)"),
        ]
        self.settings_vars = {}
        for i, (key, label) in enumerate(keys):
            tk.Label(form, text=label, bg=BG, width=28, anchor="w").grid(row=i, column=0, sticky="w", pady=4)
            var = tk.StringVar(value=str(settings.get(key, "")))
            show = "*" if key == "client_secret" else None
            entry = tk.Entry(form, textvariable=var, width=55, show=show)
            entry.grid(row=i, column=1, sticky="w", pady=4)
            self.settings_vars[key] = var

        def save():
            new_settings = {k: v.get().strip() for k, v in self.settings_vars.items()}
            try:
                new_settings["page_count"] = int(new_settings.get("page_count") or 1000)
            except ValueError:
                new_settings["page_count"] = 1000
            registry.save_settings(new_settings)
            messagebox.showinfo("Saved", "Settings saved. They apply to the next scan you run.")

        tk.Button(self.content, text="Save Settings", command=save, bg=ACCENT, fg="white",
                  relief="flat", padx=10, pady=6).pack(anchor="w", padx=20, pady=10)


def launch():
    root = tk.Tk()
    app = SchemaStudioApp(root)
    root.mainloop()


if __name__ == "__main__":
    launch()
